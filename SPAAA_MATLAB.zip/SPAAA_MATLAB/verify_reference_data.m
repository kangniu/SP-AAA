function report = verify_reference_data(data)
% Check the numerical records supplied with the examples.
root = fileparts(mfilename('fullpath'));
assert(nargin>=1 && ~isempty(data),'Provide the experiment output folder.');
report.scalar_and_counts = verify_saved_results(data);
report.band_calculations = verify_band_results(fullfile(data,'bandcost'));
summary = readtable(fullfile(data,'maxwell','band_validation','summary.csv'), ...
    'TextType','string');
assert(height(summary)==2 && all(summary.band_values_checked==176));
assert(all(summary.enclosed_values==176) && all(summary.unresolved_endpoints==0));
for kind = ["rod","defect"]
    saved = load(fullfile(data,'maxwell',kind+"_results.mat"),'result');
    result = saved.result;
    assert(strcmp(result.kind,kind));
    assert(isequal(size(result.band_values),[8 22]));
    assert(isequal(size(result.band_reference),[8 22]));
    rows = readtable(fullfile(data,'maxwell','band_validation', ...
        kind+"_final_band_enclosures.csv"),'TextType','string');
    assert(height(rows)==176 && all(rows.band_index_enclosed));
    assert(all(rows.lower_pivots_resolved) && all(rows.upper_pivots_resolved));
    index = sub2ind([8 22],rows.band,rows.path_index);
    assert(max(abs(result.band_values(index)-rows.spaaa_lambda))<1e-11);
    assert(max(abs(result.band_reference(index)-rows.reference_lambda))<1e-11);
end
report.maxwell_band_values = sum(summary.band_values_checked);
report.status = 'passed';
fprintf('All supplied reference-data checks passed.\n');
end
