function generate_strip(mode,base)
% Compare sampling strategies for the strip model.
if nargin<1, mode='screen'; end
root=fileparts(mfilename('fullpath')); addpath(genpath(fullfile(root,'src')));
if nargin<2, base=fullfile(root,'runs','selection'); end
outdir=fullfile(base,'strip');
maxNumCompThreads(2); %#ok<MAXNCT>
cfg=struct('Nx',64,'Ny',8,'indices',[24 48],'guards',.01, ...
    'budgets',[2 3 4 5 6 8 10 12],'seed',17,'svd_tol',1e-10,'sketch',4);
if strcmp(mode,'holdout')
    cfg.Nx=96; cfg.indices=[24 48]; cfg.guards=.01; cfg.seed=37;
    cfg.budgets=2:8; outdir=fullfile(base,'strip_holdout_N96');
end
if ~exist(outdir,'dir'), mkdir(outdir); end
assert(~exist(fullfile(outdir,'rows.csv'),'file'),'Choose a fresh output directory for a rerun.');
write_protocol(outdir,cfg);
[A0,U,boundary]=strip_problem(cfg.Nx,cfg.Ny);
[Q,lambda]=eig(full((A0+A0')/2),'vector'); [lambda,ix]=sort(real(lambda)); Q=Q(:,ix);
F=Q'*U;
assert(norm(Q'*Q-eye(size(Q)),'fro')<1e-9,'Spectral basis is not unitary.');
rows=struct([]); cases=struct([]);
for p=cfg.indices
    for guard_fraction=cfg.guards
        width=max(1,lambda(p)-lambda(1));
        interval=[lambda(1)-.1*width,lambda(p)+.05*width];
        guard=guard_fraction*diff(interval);
        near=lambda>=interval(1)-guard & lambda<=interval(2)+guard;
        s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near),'F_near',F(near,:), ...
            'lambda_far',lambda(~near),'F_far',F(~near,:));
        assert(min(s.lambda_far)>interval(2),'Expected one-sided far spectrum.');
        tag=sprintf('strip_n%d_p%d_g%03d',numel(lambda),p,round(1000*guard_fraction));
        train=linspace(interval(1),interval(2),401);
        normalized=unique([(.5+.5*cos(pi*((1:161)-.5)/161)), ...
            logspace(-9,-1,40),1-logspace(-9,-1,40),0,1]);
        test=interval(1)+diff(interval)*normalized;
        rng(cfg.seed,'twister'); raw=sketch_samples(s.lambda_far,s.F_far,train,cfg.sketch);
        scale=max(vecnorm(raw,2,1));
        allsupport=setvalued_aaa_support(train,raw/scale,0,max(cfg.budgets));
        exact=cell(size(test)); refnorm=zeros(size(test));
        for j=1:numel(test)
            R=s.F_far'*(s.F_far./(s.lambda_far-test(j))); R=(R+R')/2;
            exact{j}=R; refnorm(j)=norm(R,2);
        end
        models=cell(0,1); specs=struct([]); jmodel=0;
        for method={'aaa_sketch','lobatto','uniform'}
            name=method{1};
            for m=cfg.budgets
                if strcmp(name,'aaa_sketch')
                    support=allsupport(1:min(m,numel(allsupport)));
                elseif strcmp(name,'lobatto')
                    support=sort(mean(interval)+.5*diff(interval)*cos(linspace(0,pi,m)));
                else
                    support=linspace(interval(1),interval(2),m);
                end
                row=struct('case_id',string(tag),'N',numel(lambda),'r',size(F,2),'p',p, ...
                    'guard_fraction',guard_fraction,'near_count',sum(near), ...
                    'normalized_far_gap',(min(s.lambda_far)-interval(2))/diff(interval), ...
                    'method',string(name),'seed',cfg.seed,'budget',m,'actual_m',numel(support), ...
                    'q',NaN,'max_relative_error',Inf,'max_absolute_error',Inf, ...
                    'global_relative_error',Inf,'ritz_poles_inside',NaN,'success',false,'message',"");
                model=[]; errors=nan(size(test));
                try
                    model=build_projection_model(s.lambda_far,s.F_far,support,cfg.svd_tol);
                    row.q=numel(model.theta);
                    row.ritz_poles_inside=sum(model.theta>=interval(1)&model.theta<=interval(2));
                    for j=1:numel(test)
                        errors(j)=norm(exact{j}-eval_projection(model,test(j)),2);
                    end
                    row.max_relative_error=max(errors./refnorm);
                    row.max_absolute_error=max(errors);
                    row.global_relative_error=max(errors)/max(refnorm);
                    row.success=all(isfinite(errors)) && row.ritz_poles_inside==0;
                catch ME
                    row.message=string(ME.message);
                end
                if isempty(rows), rows=row; else, rows(end+1)=row; end %#ok<AGROW>
                jmodel=jmodel+1; models{jmodel}=model; %#ok<AGROW>
                spec=struct('method',name,'budget',m,'support',support,'row',row,'errors',errors);
                if isempty(specs), specs=spec; else, specs(end+1)=spec; end %#ok<AGROW>
            end
        end
        save(fullfile(outdir,[tag '.mat']),'s','A0','U','boundary','interval','guard', ...
            'cfg','p','train','test','exact','refnorm','allsupport','models','specs','-v7.3');
        meta=struct('case_id',string(tag),'p',p,'guard_fraction',guard_fraction);
        if isempty(cases), cases=meta; else, cases(end+1)=meta; end %#ok<AGROW>
        writetable(struct2table(rows),fullfile(outdir,'rows.csv'));
        fprintf('[Strip accuracy] %s complete (%d models total).\n',tag,numel(rows));
    end
end
tbl=struct2table(rows); thresholds=struct([]);
for c=1:numel(cases)
    for target=[1e-6 1e-8 1e-10]
        for method={'aaa_sketch','lobatto','uniform'}
            sub=tbl(tbl.case_id==cases(c).case_id & tbl.method==method{1},:);
            ok=sub.success & sub.max_relative_error<=target;
            best_m=NaN; best_q=NaN; error_at_min=NaN;
            if any(ok)
                feasible=sortrows(sub(ok,:),{'actual_m','q'});
                best_m=feasible.actual_m(1); best_q=feasible.q(1);
                error_at_min=feasible.max_relative_error(1);
            end
            row=struct('case_id',cases(c).case_id,'target',target,'method',string(method{1}), ...
                'attained',any(ok),'minimum_tested_m',best_m,'q_at_minimum_m',best_q, ...
                'error_at_minimum_m',error_at_min);
            if isempty(thresholds), thresholds=row; else, thresholds(end+1)=row; end %#ok<AGROW>
        end
    end
end
writetable(struct2table(thresholds),fullfile(outdir,'thresholds.csv'));
save(fullfile(outdir,'summary.mat'),'cfg','rows','thresholds','cases');
fprintf('Strip screening complete: %d cases, %d model budgets.\n',numel(cases),height(tbl));
end

function write_protocol(outdir,cfg)
text=sprintf(['# Strip sampling experiment\n\n' ...
    'Self-contained strip geometry, Nx=%d, Ny=%d on [0,1]x[0,1]. ' ...
    'Nx specifies discretization resolution, not supercell length.\n\n' ...
    'The saved config.json declares the complete case grid, node budgets and seed for this run. ' ...
    'For w=max(1,lambda_p-lambda_1), interval=[lambda_1-.1w,lambda_p+.05w]. ' ...
    'Same interval and near/far split for all strategies.\n\n' ...
    'SVD tolerance 1e-10. AAA uses an ' ...
    'orthonormal two-sided sketch, s=4, 401 uniform training points, ' ...
    'one global normalization and tolerance0 for a fixed-budget ablation. Actual m is recorded. ' ...
    'All three strategies use same Galerkin projection.\n\n' ...
    'Held-out validation uses 161 Chebyshev-Gauss points plus 40 log-spaced points ' ...
    'near each endpoint and exact endpoints; no validation-driven node adjustment. ' ...
    'Primary metric is maximum pointwise spectral-norm relative error, with absolute/global-scaled error also saved. ' ...
    'Thresholds 1e-6,1e-8,1e-10 use first TESTED actual budget, not extrapolated minimum.\n\n' ...
    'The calculations use two MATLAB computational threads.\n'],cfg.Nx,cfg.Ny);
fid=fopen(fullfile(outdir,'PROTOCOL.md'),'w'); fprintf(fid,'%s',text); fclose(fid);
fid=fopen(fullfile(outdir,'config.json'),'w'); fprintf(fid,'%s',jsonencode(cfg,PrettyPrint=true)); fclose(fid);
end

function [A0,U,b]=strip_problem(Nx,Ny)
hx=1/Nx; hy=1/(Ny+1); [x,y]=ndgrid((0:Nx-1)/Nx,(1:Ny)/(Ny+1));
v=2.5*cos(2*pi*x).*cos(pi*y); centers=[.20,.30;.45,.70;.70,.32;.88,.68];
for j=1:4
    dx=min(abs(x-centers(j,1)),1-abs(x-centers(j,1)));
    mask=dx.^2+(y-centers(j,2)).^2<=.085^2;
    v(mask)=v(mask)-45*(1+.08*j);
end
ex=ones(Nx,1); ey=ones(Ny,1);
Lx=spdiags([-ex 2*ex -ex],-1:1,Nx,Nx)/hx^2;
Ly=spdiags([-ey 2*ey -ey],-1:1,Ny,Ny)/hy^2;
A0=.45*(kron(speye(Ny),Lx)+kron(Ly,speye(Nx)))+spdiags(v(:),0,Nx*Ny,Nx*Ny);
ix=[sub2ind([Nx,Ny],ones(Ny,1),(1:Ny)');sub2ind([Nx,Ny],Nx*ones(Ny,1),(1:Ny)')];
U=sparse(ix,1:numel(ix),1,Nx*Ny,numel(ix)); b=struct('Ny',Ny,'coupling',-.45/hx^2);
end
