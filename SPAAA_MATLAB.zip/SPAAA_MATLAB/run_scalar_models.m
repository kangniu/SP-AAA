function report=run_scalar_models(mode,outdir)
% Scalar point-defect, electronic, and high-contrast examples.
if nargin<1,mode='full';end
root=fileparts(mfilename('fullpath'));addpath(genpath(fullfile(root,'src')));
if nargin<2,outdir=fullfile(root,'runs','scalar');end
assert(~exist(fullfile(outdir,'summary.csv'),'file'),'Use a fresh output directory.');
if ~exist(outdir,'dir'),mkdir(outdir);end
cfg=struct('samples',301,'sketch',8,'max_support',5,'aaa_tol',1e-9, ...
 'svd_tol',1e-9,'error_shifts',61,'count_shifts',25,'kernel_shifts',41, ...
 'kernel_repeats',15,'count_repeats',3,'path_points',16,'seed',9);
Ns=[36 40 64];
if strcmp(mode,'smoke')
 Ns=[12 10 12];cfg.samples=61;cfg.error_shifts=11;cfg.count_shifts=5;
 cfg.kernel_shifts=7;cfg.kernel_repeats=2;cfg.count_repeats=2;cfg.path_points=5;
else,assert(strcmp(mode,'full'));end
names={'defect','electronic','largecell'};
labels={'Scalar point-defect supercell','Electronic superlattice','High-contrast periodic supercell'};
cells=[3 1 4];contrasts=[10 35 55];radii=[.17 .23 .14];
api=scalar_api;results=cell(3,1);rows=struct([]);
for i=1:3
 rng(cfg.seed,'twister');
 spec=struct('name',names{i},'label',labels{i},'kind',names{i},'N',Ns(i), ...
  'cells',cells(i),'contrast',contrasts(i),'radius',radii(i));
 folder=fullfile(outdir,names{i});if ~exist(folder,'dir'),mkdir(folder);end
 fprintf('Scalar model %s N=%d\n',spec.name,spec.N);
 [result,row]=run_scalar_case(api,spec,cfg,folder);results{i}=result;
 rows=[rows;row]; %#ok<AGROW>
 writetable(struct2table(row),fullfile(folder,'summary.csv'));
 save(fullfile(folder,'result.mat'),'result','cfg','spec','-v7.3');
 writetable(struct2table(rows),fullfile(outdir,'summary.csv'));
end
environment=struct('matlab',version,'threads',maxNumCompThreads,'date',char(datetime('now')));
report=struct('results',{results},'summary',struct2table(rows),'cfg',cfg,'environment',environment);
save(fullfile(outdir,'scalar_results.mat'),'report','-v7.3');
end
