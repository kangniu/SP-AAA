function plot_bandcost(data,outdir)
% Plot median total times for the two many-band examples.
root=fileparts(mfilename('fullpath'));
assert(nargin>=1 && ~isempty(data),'Provide the experiment output folder.');
if nargin<2 || isempty(outdir),outdir=fullfile(root,'figures');end
if ~exist(outdir,'dir'),mkdir(outdir);end
f=figure('Visible','off','Color','w','Position',[100 100 1050 350]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
names={'primary','confirmation'};
titles={'(a) Case I: 256 bands, 33 phases','(b) Case II: 192 bands, 17 phases'};
methods={'direct_shiftinvert','exact_lowrank','spaaa'};
colors=[.55 .55 .55;.90 .62 0;0 .45 .70];
for s=1:2
 t=readtable(fullfile(data,'bandcost',names{s},'runs.csv'),'TextType','string');
 values=zeros(1,3);
 for j=1:3,values(j)=median(t.total_seconds(t.method==methods{j}));end
 nexttile; b=barh(1:3,values,.55,'FaceColor','flat');b.CData=colors;
 set(gca,'YDir','reverse','YTick',1:3,'YTickLabel',{'Shift-invert','Exact count','SP-AAA'},'FontSize',12,'Box','off');
 xlim([0,max(values)*1.23]);ylim([.4,3.6]);
 for j=1:3,text(values(j)+max(values)*.025,j,sprintf('%.2f s',values(j)),'FontSize',12);end
 xlabel('Median total time (s)');title(titles{s},'FontWeight','normal');
 grid on;set(gca,'YGrid','off','GridAlpha',.12);
end
exportgraphics(f,fullfile(outdir,'figure_06_bandcost.pdf'),'ContentType','vector');
exportgraphics(f,fullfile(outdir,'figure_06_bandcost.png'),'Resolution',300);
close(f);
end
