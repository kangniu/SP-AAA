function plot_examples(data,outdir)
% Plot the six manuscript figures.
root=fileparts(mfilename('fullpath'));addpath(genpath(fullfile(root,'src')));
assert(nargin>=1 && ~isempty(data),'Provide the folder from run_examples(''full'').');
if nargin<2 || isempty(outdir),outdir=fullfile(root,'figures');end
if ~exist(outdir,'dir'),mkdir(outdir);end
p=load(fullfile(data,'scalar','largecell','result.mat'),'result');
plot_partition(p.result,outdir);
colors=[0 .36 .65;.85 .33 .10;.35 .35 .35]; styles={'-o','--s',':^'};
names={'AAA','Lobatto','Uniform'};
syn=readtable(fullfile(data,'selection','synthetic.csv'),'TextType','string');
strip=readtable(fullfile(data,'selection','validation','strip_confirmation.csv'),'TextType','string');
f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7 2.8]);
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
nexttile;hold on;methods=["aaa_sketch","cheb_lobatto","uniform"];
for i=1:3
 x=syn(syn.case_id=="case_05" & syn.seed==101 & syn.svd_tol==1e-10 & syn.method==methods(i),:);x=sortrows(x,'actual_m');
 semilogy(x.actual_m,x.max_relative_error,styles{i},'Color',colors(i,:),'MarkerSize',3,'DisplayName',names{i});
end
set(gca,'YScale','log');yline(1e-8,'k--','HandleVisibility','off');ylim([1e-14 1]);xlim([2 20]);grid on;
xlabel('Block samples m');ylabel('Maximum relative error');title('(a) Multiscale spectrum');legend('Location','northeast','Box','off');
nexttile;hold on;methods=["aaa_sketch","lobatto","uniform"];
for i=1:3
 x=strip(strip.case_id=="strip_n512_p24_g010" & strip.method==methods(i),:);if i==1,x=x(x.seed==37,:);end;x=sortrows(x,'actual_m');
 semilogy(x.actual_m,x.max_relative_error,styles{i},'Color',colors(i,:),'MarkerSize',3,'DisplayName',names{i});
end
set(gca,'YScale','log');yline(1e-8,'k--','HandleVisibility','off');ylim([1e-14 1e-1]);xlim([3 7]);grid on;
xlabel('Block samples m');ylabel('Maximum relative error');title('(b) Strip, p = 24');legend('Location','southwest','Box','off');finish(f,outdir,'figure_02_selection');

f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7.5 4.6]);tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
for kind={'rod','defect'}
 k=kind{1};x=load(fullfile(data,'maxwell',[k '_results.mat']),'result');r=x.result;prob=build_tm_problem(r.N,k);
 nexttile;imagesc(reshape(prob.eps,r.N,r.N));axis image xy;title([k ': permittivity']);colorbar;
 nexttile;plot(sqrt(max(r.band_values,0)).'/(2*pi),'LineWidth',.8);xticks([1 8 15 22]);xticklabels({'\Gamma','X','M','\Gamma'});ylabel('\omega a/(2\pi c)');grid on;title('SP-AAA bands');
 if strcmp(k,'rod'),kv=[pi pi];else,kv=[0 0];end
 A=prob.A0+prob.U*boundary_T(prob,kv)*prob.U';[V,ev]=lowest_eigpairs((A+A')/2,8);
 assert(abs(ev(r.field_mode)-r.field_lambda)<1e-7,'Field mode differs from saved result.');
 z=abs(prob.mass_inv_sqrt.*V(:,r.field_mode)).^2;
 nexttile;imagesc(reshape(z,r.N,r.N));axis image xy;colorbar;title('Fifth-mode intensity');
end
finish(f,outdir,'figure_04_maxwell');
plot_scalar_support(data,outdir);
plot_bandcost(data,outdir);
end
function finish(f,outdir,name)
set(findall(f,'Type','axes'),'FontName','Times New Roman','FontSize',9);
exportgraphics(f,fullfile(outdir,[name '.pdf']),'ContentType','vector');
exportgraphics(f,fullfile(outdir,[name '.png']),'Resolution',180);close(f);
end
