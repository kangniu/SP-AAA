function result=run_band_cost(cfg,outdir)
% Compute the lowest bands; include setup and all counting work in timings.
root=fileparts(mfilename('fullpath'));addpath(genpath(fullfile(root,'src')));
if nargin<1,cfg=struct;end
defaults=struct('Nx',128,'Ny',16,'Lx',4,'bands',64,'nk',5,'repeats',1, ...
 'm',5,'ns',201,'sketch',4,'svd_tol',1e-9,'aaa_tol',1e-9, ...
 'band_tol',1e-7,'eigs_tol',1e-9,'guard_fraction',.1,'cache_capacity',4096,'seed',20260927, ...
 'initialization','tree','validation_stride',1);
for f=fieldnames(defaults).',if ~isfield(cfg,f{1}),cfg.(f{1})=defaults.(f{1});end,end
if nargin<2,outdir=fullfile(root,'runs','bandcost');end
assert(~exist(fullfile(outdir,'runs.csv'),'file'),'Use a fresh output directory.');
if ~exist(outdir,'dir'),mkdir(outdir);end
kpoints=linspace(.03*pi,.97*pi,cfg.nk); % Avoid time-reversal degeneracies.
methods=["direct_shiftinvert","exact_lowrank","spaaa"];orders=[1 2 3;2 3 1;3 1 2;3 2 1;2 1 3];
rows=struct([]);outputs=cell(cfg.repeats,3);
for rep=1:cfg.repeats
 for pos=1:3
  im=orders(mod(rep-1,5)+1,pos);
  [row,out]=one_method(cfg,methods(im),kpoints);
  row.repeat=rep;row.position=pos;rows=[rows;row];outputs{rep,im}=out; %#ok<AGROW>
  fprintf('%dx%d L=%g bands=%d nk=%d round=%d %s %.3fs setup=%.3f q=%d queries=%d misses=%d fallbacks=%d\n', ...
   cfg.Nx,cfg.Ny,cfg.Lx,cfg.bands,cfg.nk,rep,methods(im),row.total_seconds,row.setup_seconds,row.q,row.queries,row.cache_misses,row.fallbacks);
  writetable(struct2table(rows),fullfile(outdir,'runs.csv'));
  save(fullfile(outdir,'checkpoint.mat'),'cfg','outputs','rows','kpoints','-v7.3');
 end
end
% Independent original-matrix checks are outside every timed method.
[A0,U,b]=bandcost_problem(cfg.Nx,cfg.Ny,cfg.Lx);
checks=0;max_difference=0;t=tic;
for ik=1:cfg.nk
 T=boundary(b,kpoints(ik));A=A0+U*T*U';A=(A+A')/2;
 ref=outputs{1,1}.values(:,ik);
 for rep=1:cfg.repeats
  for im=1:3
   v=outputs{rep,im}.values(:,ik);err=abs(v-ref)./max(1,abs(ref));
   max_difference=max(max_difference,max(err));
   assert(all(err<=4*cfg.band_tol),'Band methods disagree.');
  end
 end
 % A fixed independent enclosure for every band, including multiplicity.
 for j=unique([1:cfg.validation_stride:cfg.bands,cfg.bands])
  delta=4*cfg.band_tol*max(1,abs(ref(j)));
  lo=band_original_inertia(A,ref(j)-delta);hi=band_original_inertia(A,ref(j)+delta);
  assert(lo<j && hi>=j,'Original-matrix band enclosure failed.');checks=checks+2;
 end
end
result=struct('cfg',cfg,'runs',struct2table(rows),'kpoints',kpoints, ...
 'original_matrix_checks',checks,'max_relative_difference',max_difference, ...
 'validation_seconds',toc(t),'status','passed');
save(fullfile(outdir,'benchmark.mat'),'result','outputs','-v7.3');
fid=fopen(fullfile(outdir,'summary.json'),'w');fprintf(fid,'%s',jsonencode(rmfield(result,'runs'),PrettyPrint=true));fclose(fid);
disp(result.runs);
end

function [row,out]=one_method(cfg,method,kpoints)
rng(cfg.seed,'twister');timer=tic;
row=struct('method',method,'total_seconds',0,'setup_seconds',0,'spectral_seconds',0, ...
 'model_seconds',0,'q',0,'queries',0,'cache_hits',0,'cache_misses',0,'fallbacks',0, ...
 'explicit_residuals',0,'unresolved',0,'original_fallbacks',0,'far_seconds',0,'residual_seconds',0, ...
 'count_seconds',0,'proposal_seconds',0,'max_eigen_residual',0,'max_orthogonality',0,'repeat',0,'position',0);
[A0,U,b,V]=bandcost_problem(cfg.Nx,cfg.Ny,cfg.Lx);n=size(A0,1);r=size(U,2);
% Min-max bounds from the homogeneous discrete strip and min/max potential.
bounds=zeros(numel(kpoints),2);
for ik=1:numel(kpoints)
 free=sort(reshape(.9/b.hx^2*(1-cos(((0:cfg.Nx-1)'*2*pi+kpoints(ik))/cfg.Nx)) ...
  +.9/b.hy^2*(1-cos(pi*(1:cfg.Ny)/(cfg.Ny+1))),[],1));
 bounds(ik,:)=[free(1)+min(V(:))-1,free(cfg.bands)+max(V(:))+1];
end
interval=[min(bounds(:,1)),max(bounds(:,2))];
out=struct('values',zeros(cfg.bands,numel(kpoints)),'cumulative',zeros(numel(kpoints),1), ...
 'queries',zeros(numel(kpoints),1),'brackets',zeros(cfg.bands,2,numel(kpoints)), ...
 'interval',interval,'residuals',zeros(cfg.bands,numel(kpoints)));
if method~="direct_shiftinvert"
 t=tic;[Q,lambda]=eig(full(A0),'vector');[lambda,ix]=sort(real(lambda));Q=Q(:,ix);F=Q'*U;
 row.spectral_seconds=toc(t);
 assert(norm(A0*Q-Q.*lambda.','fro')/max(1,norm(A0,'fro'))<1e-10);clear Q
 near=lambda>=interval(1)-cfg.guard_fraction*diff(interval)&lambda<=interval(2)+cfg.guard_fraction*diff(interval);
 lf=lambda(~near);Ff=F(~near,:);ln=lambda(near);Fn=F(near,:);
 if method=="spaaa" || strcmp(cfg.initialization,'projected')
  t=tic;grid=sort(mean(interval)+diff(interval)/2*cos(linspace(0,pi,cfg.ns)));
  samples=sketch_samples(lf,Ff,grid,cfg.sketch);samples=samples/max(max(vecnorm(samples)),realmin);
  support=setvalued_aaa_support(grid,samples,cfg.aaa_tol,cfg.m);
  model=build_band_model(lf,Ff,support,cfg.svd_tol,method=="spaaa");row.q=numel(model.theta);row.model_seconds=toc(t);
 end
 cachekeys=NaN(1,cfg.cache_capacity);cacheitems=cell(1,cfg.cache_capacity);slot=0;
end
row.setup_seconds=toc(timer);
for ik=1:numel(kpoints)
 T=boundary(b,kpoints(ik));A=A0+U*T*U';A=(A+A')/2;
 if method=="direct_shiftinvert"
  opts=struct('tol',cfg.eigs_tol,'maxit',3000,'p',min(n,max(20,2*cfg.bands+1)));
  for attempt=1:4
   [Z,D,flag]=eigs(A,cfg.bands,bounds(ik,1),opts);assert(flag==0,'eigs did not converge.');
   [ev,ix]=sort(real(diag(D)));Z=Z(:,ix);
   residual=vecnorm(A*Z-Z.*ev.',2,1)./vecnorm(Z,2,1);
   orth=norm(Z'*Z-eye(cfg.bands),'fro');
   if all(residual'<=cfg.band_tol*max(1,abs(ev))) && orth<1e-6,break;end
   opts.tol=opts.tol/10;
  end
  assert(all(residual'<=cfg.band_tol*max(1,abs(ev))) && orth<1e-6,'Direct accuracy target not met.');
  row.max_eigen_residual=max(row.max_eigen_residual,max(residual./max(1,abs(ev.'))));
  row.max_orthogonality=max(row.max_orthogonality,orth);out.values(:,ik)=ev;
  out.residuals(:,ik)=residual';
 else
  % This physical update is nonsingular; use T^{-1}+F^*(D-d)^{-1}F.
  invT=full(T\speye(r));invT=(invT+invT')/2;
  assert(norm(T*invT-eye(r),'fro')<1e-10);
  npositive=sum(eig(full(T))>0);before=row.queries;
  [ca,oka]=query(interval(1));[cb,okb]=query(interval(2));
  assert(oka&&okb&&ca==0&&cb>=cfg.bands,'Physical min-max bracket failed.');
  if strcmp(cfg.initialization,'projected')
   t=tic;Fred=[Fn;model.C];Ar=diag([ln;model.theta])+Fred*T*Fred';Ar=(Ar+Ar')/2;
   guesses=sort(real(eig(Ar,'vector')));assert(all(lf>interval(1)));
   row.proposal_seconds=row.proposal_seconds+toc(t);
   for j=1:cfg.bands
    center=guesses(j);width=.45*cfg.band_tol*max(1,2*abs(center));
    for trial=1:60
     a=max(interval(1),center-width);z=min(interval(2),center+width);
     [na,oka]=query(a);[nz,okz]=query(z);
     if oka&&okz&&na<j&&nz>=j,break;end
     width=2*width;
    end
    assert(oka&&okz&&na<j&&nz>=j,'Projected proposal could not be enclosed.');
    while z-a>cfg.band_tol*max(1,abs(a)+abs(z))
     ok=false;
     for frac=[.5 .25 .75 .375 .625 .125 .875]
      d=a+frac*(z-a);[count,ok]=query(d);if ok,break;end
     end
     assert(ok,'All proposal-refinement counts unresolved.');
     if count>=j,z=d;else,a=d;end
    end
    out.values(j,ik)=(a+z)/2;out.brackets(j,:,ik)=[a z];
   end
   stack=[];
  else,stack=[interval ca cb];end
  while ~isempty(stack)
   node=stack(end,:);stack(end,:)=[];a=node(1);z=node(2);na=node(3);nz=node(4);
   first=max(1,na+1);last=min(cfg.bands,nz);if first>last,continue;end
   if z-a<=cfg.band_tol*max(1,abs(a)+abs(z))
    out.values(first:last,ik)=(a+z)/2;out.brackets(first:last,:,ik)=repmat([a z],last-first+1,1);continue
   end
   fractions=[.5 .25 .75 .375 .625 .125 .875];ok=false;
   for frac=fractions
    d=a+frac*(z-a);[count,ok]=query(d);if ok,break;end
   end
   assert(ok,'All count retries unresolved.');
   assert(count>=na&&count<=nz,'Nonmonotone count.');
   if count<nz,stack(end+1,:)=[d z count nz];end %#ok<AGROW>
   if count>na,stack(end+1,:)=[a d na count];end %#ok<AGROW>
  end
  out.queries(ik)=row.queries-before;
 end
 out.cumulative(ik)=toc(timer);
end
row.total_seconds=toc(timer);

 function [count,ok]=query(d)
  row.queries=row.queries+1;ok=false;count=NaN;
  if min(abs(lambda-d))<=100*eps(max([1;abs(lambda);abs(d)]))
   row.fallbacks=row.fallbacks+1;row.original_fallbacks=row.original_fallbacks+1;
   try,count=band_original_inertia(A,d);ok=true;catch, end
   if ~ok,row.unresolved=row.unresolved+1;end;return
  end
  cacheidx=find(cachekeys==d,1);
  if ~isempty(cacheidx)
   item=cacheitems{cacheidx};row.cache_hits=row.cache_hits+1;
  else
   row.cache_misses=row.cache_misses+1;t=tic;
   if method=="spaaa"
    [Rf,eta,explicit]=eval_band_model(model,lf,d);row.explicit_residuals=row.explicit_residuals+explicit;
   else,Rf=eval_exact(lf,Ff,d);eta=0;end
   row.far_seconds=row.far_seconds+toc(t);
   if isempty(Rf),Rtotal=[];else,Rtotal=Rf+eval_exact(ln,Fn,d);end
   item=struct('R',Rtotal,'eta',eta,'base_count',sum(lambda<d),'exact',method=="exact_lowrank");
   slot=slot+1;cacheidx=mod(slot-1,cfg.cache_capacity)+1;
   cachekeys(cacheidx)=d;cacheitems{cacheidx}=item;
  end
  t=tic;[count,ok]=small(item.R,item.eta,item.base_count);
  if ~ok && ~item.exact
   row.fallbacks=row.fallbacks+1;
   item.R=eval_exact(lambda,F,d);item.eta=0;item.exact=true;cacheitems{cacheidx}=item;
   [count,ok]=small(item.R,0,item.base_count);
  end
  if ~ok
   row.original_fallbacks=row.original_fallbacks+1;
   try,count=band_original_inertia(A,d);ok=true;catch,end
  end
  row.count_seconds=row.count_seconds+toc(t);
  if ~ok,row.unresolved=row.unresolved+1;end
 end
 function [count,ok]=small(R,eta,base)
  count=NaN;ok=false;if isempty(R)||~isfinite(eta),return;end
  K=invT+R;K=(K+K')/2;e=real(eig(K,'vector'));
  gap=min(abs(e))-64*eps*r*max(1,norm(K,'fro'));
  count=base+sum(e>0)-npositive;ok=gap>eta && count>=0 && count<=n;
 end
end

function T=boundary(b,k)
Z=sparse(b.Ny,b.Ny);X=b.coupling*exp(-1i*k)*speye(b.Ny);T=[Z X;X' Z];
end
