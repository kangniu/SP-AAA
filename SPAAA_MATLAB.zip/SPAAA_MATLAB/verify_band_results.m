function report=verify_band_results(data)
root=fileparts(mfilename('fullpath'));
assert(nargin>=1 && ~isempty(data),'Provide the experiment output folder.');
checks=0;values=0;
for name=["primary","confirmation"]
 s=load(fullfile(data,name,'benchmark.mat'),'result','outputs');r=s.result;
 assert(strcmp(r.status,'passed') && r.cfg.repeats==5 && r.cfg.validation_stride==1);
 assert(r.original_matrix_checks==2*r.cfg.bands*r.cfg.nk);
 assert(height(r.runs)==15 && all(r.runs.unresolved==0));
 for rep=1:5
  for im=1:3
   o=s.outputs{rep,im};ref=s.outputs{1,1}.values;
   assert(all(abs(o.values-ref)<=4*r.cfg.band_tol*max(1,abs(ref)),'all'));
   assert(all(diff(o.values,1,1)>=0,'all') && all(diff(o.cumulative)>0));
   if im>1
    a=squeeze(o.brackets(:,1,:));b=squeeze(o.brackets(:,2,:));
    assert(all(b-a<=r.cfg.band_tol*max(1,abs(a)+abs(b)),'all'));
    assert(all(o.values>=a & o.values<=b,'all'));
   end
   values=values+numel(o.values);
  end
 end
 checks=checks+r.original_matrix_checks;
end
report=struct('original_matrix_endpoint_checks',checks,'compared_band_values',values,'status','passed');disp(report);
end
