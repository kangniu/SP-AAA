function plot_partition(x,outdir)
% Plot the near/far pole partition and AAA support points.
root=fileparts(mfilename('fullpath'));
if nargin<1 || isempty(x)
    error('Provide the result structure from the high-contrast scalar experiment.');
end
if nargin<2 || isempty(outdir),outdir=fullfile(root,'figures');end
if ~exist(outdir,'dir'),mkdir(outdir);end
a=x.interval(1);b=x.interval(2);
ag=x.guard_interval(1);bg=x.guard_interval(2);
span=b-a;
window=[ag-0.35*span,bg+0.35*span];
far=x.far_poles(x.far_poles>=window(1) & x.far_poles<=window(2));
near=x.near_poles(x.near_poles>=window(1) & x.near_poles<=window(2));

fig=figure('Visible','off','Color','w','Position',[100 100 980 330]);
ax=axes(fig);hold(ax,'on');
patch(ax,[a b b a],[0.68 0.68 1.28 1.28],[0.82 0.90 1.00],...
    'EdgeColor','none','FaceAlpha',0.75);
patch(ax,[ag a a ag],[0.68 0.68 1.28 1.28],[1.00 0.92 0.72],...
    'EdgeColor','none','FaceAlpha',0.75);
patch(ax,[b bg bg b],[0.68 0.68 1.28 1.28],[1.00 0.92 0.72],...
    'EdgeColor','none','FaceAlpha',0.75);
yfar=0.24+0.08*mod(0:numel(far)-1,3);
ynear=0.24+0.08*mod(0:numel(near)-1,3);
scatter(ax,far,yfar,34,[0.35 0.35 0.35],'x','LineWidth',1.2);
scatter(ax,near,ynear,48,[0.82 0.12 0.12],'x','LineWidth',1.6);
for j=1:numel(x.support)
    plot(ax,[x.support(j) x.support(j)],[1.34 1.67],'-',...
        'Color',[0.05 0.50 0.22],'LineWidth',1.5);
    scatter(ax,x.support(j),1.34,38,[0.05 0.50 0.22],'filled');
end
xline(ax,a,'Color',[0.15 0.35 0.75],'LineWidth',1.3);
xline(ax,b,'Color',[0.15 0.35 0.75],'LineWidth',1.3);
xline(ax,ag,'--','Color',[0.75 0.48 0.08],'LineWidth',1.1);
xline(ax,bg,'--','Color',[0.75 0.48 0.08],'LineWidth',1.1);
yline(ax,0.18,'Color',[0.2 0.2 0.2]);
text(ax,(a+b)/2,1.03,'target interval [a,b]',...
    'HorizontalAlignment','center','Color',[0.10 0.28 0.68]);
text(ax,(ag+a)/2,1.03,'guard','HorizontalAlignment','center',...
    'Color',[0.62 0.35 0.02]);
text(ax,(b+bg)/2,1.03,'guard','HorizontalAlignment','center',...
    'Color',[0.62 0.35 0.02]);
text(ax,mean(x.support),1.79,'AAA support points',...
    'HorizontalAlignment','center','Color',[0.05 0.43 0.18]);
text(ax,window(1)+0.02*diff(window),0.48,'far poles: D_1',...
    'Color',[0.28 0.28 0.28]);
text(ax,(ag+bg)/2,0.48,'near poles: D_2',...
    'HorizontalAlignment','center','Color',[0.72 0.08 0.08]);
xlim(ax,window);ylim(ax,[0 1.95]);yticks(ax,[]);
xlabel(ax,'spectral parameter d');box(ax,'on');
set(ax,'FontSize',11,'Layer','top');
exportgraphics(fig,fullfile(outdir,'figure_01_partition.pdf'),'ContentType','vector');
exportgraphics(fig,fullfile(outdir,'figure_01_partition.png'),'Resolution',220);
close(fig);
end
