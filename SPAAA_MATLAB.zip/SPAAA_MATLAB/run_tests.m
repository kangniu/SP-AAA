function run_tests
root=fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root,'src')),fullfile(root,'tests'));
test_residual_safeguards;
test_original_count;
test_maxwell_hermitian_assembly;
test_unresolved_bisection;
test_band_cost_model;
end
