function output=run_support_sensitivity(mode,outdir)
% Compare projection models built from prefixes of one AAA support sequence.
if nargin<1,mode='full';end
root=fileparts(mfilename('fullpath'));addpath(genpath(fullfile(root,'src')));
if nargin<2,outdir=fullfile(root,'runs','support');end
assert(~exist(fullfile(outdir,'summary.csv'),'file'),'Use a fresh output directory.');
if ~exist(outdir,'dir'),mkdir(outdir);end
N=48;ns=401;budgets=2:10;nd=31;
if strcmp(mode,'smoke'),N=12;ns=61;budgets=2:5;nd=11;else,assert(strcmp(mode,'full'));end
prob=build_tm_problem(N,'defect');
ks=[.31*pi .17*pi;.58*pi .29*pi;.83*pi .46*pi];
interval=tm_ritz_interval(prob,ks,8);guard=.10*diff(interval);
[Q,lambda]=eig(full(prob.A0),'vector');[lambda,ix]=sort(real(lambda));Q=Q(:,ix);
assert(norm(Q'*Q-eye(prob.n),'fro')<1e-8);
assert(norm(prob.A0*Q-Q.*lambda.','fro')/max(1,norm(prob.A0,'fro'))<1e-10);
F=Q'*prob.U;clear Q
near=lambda>=interval(1)-guard & lambda<=interval(2)+guard;
s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near),'F_near',F(near,:), ...
 'lambda_far',lambda(~near),'F_far',F(~near,:));
z=linspace(interval(1),interval(2),ns);rng(7,'twister');
Y=sketch_samples(s.lambda_far,s.F_far,z,4);Y=Y/max(max(vecnorm(Y,2,1)),realmin);
support=setvalued_aaa_support(z,Y,0,max(budgets));
assert(numel(support)==max(budgets),'AAA stopped before the prescribed prefix budget.');
shifts=linspace(interval(1),interval(2),nd);references=zeros(nd,3);gap=Inf;
for ik=1:3
 A=prob.A0+prob.U*boundary_T(prob,ks(ik,:))*prob.U';A=(A+A')/2;
 ev=sort(real(eig(full(A),'vector')));
 for jd=1:nd
  d=shifts(jd);references(jd,ik)=sum(ev<d);gap=min(gap,min(abs(ev-d)));
  assert(references(jd,ik)==original_inertia(A,d));
 end
end
assert(gap>100*eps(max(1,norm(prob.A0,1))));
exact=cell(nd,1);for jd=1:nd,exact{jd}=eval_exact(s.lambda_far,s.F_far,shifts(jd));end
rows=struct([]);queries=struct([]);errors=struct([]);
for m=budgets
 model=build_projection_model(s.lambda_far,s.F_far,support(1:m),1e-10);
 absolute=zeros(nd,1);relative=zeros(nd,1);accepted=0;fallbacks=0;dense=0;unresolved=0;mismatch=0;
 for jd=1:nd
  d=shifts(jd);absolute(jd)=norm(exact{jd}-eval_projection(model,d),2);
  relative(jd)=absolute(jd)/norm(exact{jd},2);
  er=struct('m',m,'shift',d,'absolute_error',absolute(jd),'relative_error',relative(jd));errors=[errors;er]; %#ok<AGROW>
 end
 for ik=1:3
  update=prepare_inertia_update(s,boundary_T(prob,ks(ik,:)));
  for jd=1:nd
   d=shifts(jd);pole_tol=100*eps(max([1;abs(d);abs(model.theta)]));
   if min(abs(model.theta-d))<=pole_tol,R=[];eta=Inf;
   else,R=eval_projection(model,d);eta=projection_error_bound(model,s.lambda_far,d);end
   [count,~,ci]=inertia_count(s,update,d,R,eta);
   ok=ci.accepted_approximation && ~ci.used_fallback;
   accepted=accepted+ok;fallbacks=fallbacks+ci.used_fallback;dense=dense+ci.used_dense;
   unresolved=unresolved+~ci.reliable;mismatch=mismatch+(count~=references(jd,ik));
   q=struct('m',m,'k_index',ik,'shift',d,'reference',references(jd,ik),'count',count, ...
    'accepted',ok,'fallback',ci.used_fallback,'dense',ci.used_dense,'reliable',ci.reliable);
   queries=[queries;q]; %#ok<AGROW>
  end
 end
 row=struct('N',N,'n',prob.n,'r',size(F,2),'near_count',sum(near),'m',m,'q',numel(model.theta), ...
  'max_absolute_error',max(absolute),'max_relative_error',max(relative), ...
  'queries',nd*3,'accepted',accepted,'accepted_fraction',accepted/(nd*3), ...
  'fallbacks',fallbacks,'dense_fallbacks',dense,'unreliable',unresolved,'mismatches',mismatch);
 rows=[rows;row]; %#ok<AGROW>
 writetable(struct2table(rows),fullfile(outdir,'summary.csv'));
 writetable(struct2table(queries),fullfile(outdir,'queries.csv'));
 writetable(struct2table(errors),fullfile(outdir,'errors.csv'));
 fprintf('Defect support m=%d q=%d accepted=%d/%d fallbacks=%d\n',m,row.q,accepted,nd*3,fallbacks);
 assert(mismatch==0 && unresolved==0,'A final count is incorrect or unresolved.');
end
output=struct('summary',struct2table(rows),'interval',interval,'guard',guard,'support',support, ...
 'kpoints',ks,'shifts',shifts,'references',references,'minimum_reference_gap',gap, ...
 'seed',7,'svd_tol',1e-10,'ns',ns,'sketch',4,'matlab',version,'threads',maxNumCompThreads);
save(fullfile(outdir,'support_sensitivity.mat'),'output','-v7.3');
end
