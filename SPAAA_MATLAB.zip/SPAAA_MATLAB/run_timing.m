function result = run_timing(mode,outdir)
% Repeated count-map calculations on a fixed interval, with setup included.
if nargin==0, mode='full'; end
root=fileparts(mfilename('fullpath')); addpath(genpath(fullfile(root,'src')));
cfg=struct('Nx',128,'Ny',32,'nk',81,'nd',41,'repeats',5, ...
    'ns',201,'sketch',8,'m',5,'svd_tol',1e-9,'aaa_tol',1e-9, ...
    'interval',[-3,83],'threshold_interval',[-.4,80.4], ...
    'guard',8.6,'initial_nev',24,'seed',20260924);
if strcmpi(mode,'quick')
    cfg.Nx=32; cfg.Ny=12; cfg.nk=5; cfg.nd=9; cfg.repeats=2;
    cfg.ns=61; cfg.sketch=4; cfg.m=4;
elseif ~strcmpi(mode,'full')
    error('Mode must be quick or full.');
end
if nargin<2, outdir=fullfile(root,'runs','timing'); end
if ~exist(outdir,'dir'), mkdir(outdir); end
methods=["direct_sparse","exact_lowrank","spaaa"];
kpoints=linspace(0,pi,cfg.nk);
shifts=linspace(cfg.threshold_interval(1),cfg.threshold_interval(2),cfg.nd);
% Warm up each method on a small problem; rebuild its data for each timed run.
warm=cfg; warm.Nx=12; warm.Ny=6; warm.nk=2; warm.nd=3;
warm.ns=21; warm.sketch=3; warm.m=3;
for method=methods
    run_method(warm,method,[0,.7],[-.4,40,80.4]);
end
fprintf('Full-task benchmark: %s, n=%d, %d queries, %d repeats\n', ...
    mode,cfg.Nx*cfg.Ny,cfg.nk*cfg.nd,cfg.repeats);
rows=struct([]); maps=cell(cfg.repeats,3); curves=cell(cfg.repeats,3);
% Vary the method order across the five repetitions.
orders=[1,2,3;2,3,1;3,1,2;3,2,1;2,1,3];
for repeat=1:cfg.repeats
    order=orders(repeat,:);
    for position=1:3
        im=order(position); method=methods(im);
        [row,map,curve]=run_method(cfg,method,kpoints,shifts);
        row.repeat=repeat; row.execution_position=position;
        if isempty(rows), rows=row; else, rows(end+1)=row; end %#ok<AGROW>
        maps{repeat,im}=map; curves{repeat,im}=curve;
        fprintf('repeat %d, %s: %.3f s, fallbacks %d\n', ...
            repeat,method,row.total_seconds,row.fallbacks);
        writetable(struct2table(rows),fullfile(outdir,'runs.csv'));
    end
end
% Check every query by original-matrix LDL counts, outside the timed runs.
fprintf('Independent original-matrix LDL validation of every query...\n');
tcheck=tic;
[A0,U,boundary]=strip_problem(cfg.Nx,cfg.Ny);
reference=zeros(cfg.nd,cfg.nk);
for ik=1:cfg.nk
    T=strip_update(boundary,kpoints(ik)); A=A0+U*T*U'; A=(A+A')/2;
    for jd=1:cfg.nd
        reference(jd,ik)=sparse_inertia(A,shifts(jd));
    end
end
validation_seconds=toc(tcheck);
for repeat=1:cfg.repeats
    for im=1:3
        assert(isequal(maps{repeat,im},reference), ...
            'Count mismatch for %s at repeat %d.',methods(im),repeat);
    end
end
tbl=struct2table(rows); summary=struct([]);
for im=1:3
    times=tbl.total_seconds(tbl.method==methods(im));
    summary_row=struct('method',methods(im),'n',cfg.Nx*cfg.Ny, ...
        'queries',cfg.nk*cfg.nd,'repeats',cfg.repeats, ...
        'median_seconds',median(times),'min_seconds',min(times), ...
        'max_seconds',max(times),'std_seconds',std(times), ...
        'coefficient_of_variation',std(times)/mean(times), ...
        'all_counts_match',true);
    if isempty(summary), summary=summary_row; else, summary(im)=summary_row; end
end
summary=struct2table(summary);
speedups=struct([]);
sp_times=tbl.total_seconds(tbl.method=="spaaa");
for im=1:2
    ratios=tbl.total_seconds(tbl.method==methods(im))./sp_times;
    ratio_row=struct('baseline',methods(im), ...
        'median_speedup',median(ratios),'min_speedup',min(ratios), ...
        'max_speedup',max(ratios));
    if isempty(speedups), speedups=ratio_row; else, speedups(im)=ratio_row; end
end
speedups=struct2table(speedups);
environment=struct('matlab_version',version,'computer',computer, ...
    'threads',maxNumCompThreads,'date',char(datetime('now')), ...
    'warmup','One small untimed run of every method; fresh setup each timed run', ...
    'timing_scope','Assembly through completed count map; excludes disk I/O and independent validation');
result=struct('cfg',cfg,'runs',tbl,'summary',summary,'speedups',speedups, ...
    'validation_seconds',validation_seconds,'environment',environment);
writetable(summary,fullfile(outdir,'summary.csv'));
writetable(speedups,fullfile(outdir,'speedups.csv'));
save(fullfile(outdir,'benchmark.mat'),'result','maps','reference','curves', ...
    'kpoints','shifts','-v7.3');
fid=fopen(fullfile(outdir,'environment.json'),'w');
fprintf(fid,'%s',jsonencode(environment,PrettyPrint=true)); fclose(fid);
disp(summary);
end

function [row,counts,cumulative]=run_method(cfg,method,kpoints,shifts)
rng(cfg.seed,'twister');
row=struct('method',method,'total_seconds',0,'assembly_seconds',0, ...
    'spectral_seconds',0,'model_seconds',0,'update_seconds',0, ...
    'query_seconds',0,'residual_seconds',0,'far_seconds',0, ...
    'count_seconds',0,'other_seconds',0,'fallbacks',0, ...
    'explicit_residuals',0,'q',0,'direct_max_nev',0, ...
    'direct_dense_fallbacks',0,'max_eigen_residual',0, ...
    'max_orthogonality_error',0,'repeat',0,'execution_position',0);
total=tic;
tt=tic; [A0,U,boundary]=strip_problem(cfg.Nx,cfg.Ny);
row.assembly_seconds=toc(tt);
n=size(A0,1); counts=zeros(numel(shifts),numel(kpoints));
cumulative=zeros(numel(kpoints),1);
if method~="direct_sparse"
    tt=tic;
    [Q,lambda]=eig(full(A0),'vector');
    [lambda,ix]=sort(real(lambda)); Q=Q(:,ix); F=Q'*U;
    row.spectral_seconds=toc(tt);
    tt=tic;
    near=lambda>=cfg.interval(1)-cfg.guard & lambda<=cfg.interval(2)+cfg.guard;
    s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near), ...
        'F_near',F(near,:),'lambda_far',lambda(~near),'F_far',F(~near,:));
    if method=="spaaa"
        sample=sort(mean(cfg.interval)+diff(cfg.interval)/2*cos(linspace(0,pi,cfg.ns)));
        sketch=sketch_samples(s.lambda_far,s.F_far,sample,cfg.sketch);
        support=setvalued_aaa_support(sample,sketch,cfg.aaa_tol,cfg.m);
        model=build_projection_model(s.lambda_far,s.F_far,support,cfg.svd_tol);
        row.q=size(model.V,2);
    end
    row.model_seconds=toc(tt);
end
for ik=1:numel(kpoints)
    tt=tic; T=strip_update(boundary,kpoints(ik));
    if method=="direct_sparse"
        A=A0+U*T*U'; A=(A+A')/2;
    else
        cache=prepare_inertia_update(s,T);
    end
    row.update_seconds=row.update_seconds+toc(tt);
    tq=tic;
    if method=="direct_sparse"
        requested=min(cfg.initial_nev,n-2);
        opts=struct('isreal',false,'tol',1e-10,'maxit',3000);
        normA=norm(A,1);
        while true
            opts.p=min(n,max(48,3*requested));
            [Ve,D,flag]=eigs(A,requested,'smallestreal',opts);
            assert(flag==0,'Sparse reference eigensolver failed to converge.');
            [ev,residual,orthogonality]=check_eigenpairs(A,Ve,diag(D),normA);
            row.max_eigen_residual=max(row.max_eigen_residual,residual/max(1,normA));
            row.max_orthogonality_error=max(row.max_orthogonality_error,orthogonality);
            row.direct_max_nev=max(row.direct_max_nev,requested);
            if ev(end)>max(shifts)+10*residual, break; end
            if requested==n-2
                [Ve,D]=eig(full(A));
                [ev,residual,orthogonality]=check_eigenpairs(A,Ve,diag(D),normA);
                row.max_eigen_residual=max(row.max_eigen_residual,residual/max(1,normA));
                row.max_orthogonality_error=max(row.max_orthogonality_error,orthogonality);
                row.direct_dense_fallbacks=row.direct_dense_fallbacks+1;
                row.direct_max_nev=n;
                break
            end
            requested=min(n-2,max(requested+8,ceil(1.5*requested)));
        end
        assert(min(abs(ev-shifts),[],'all')>10*residual, ...
            'A requested threshold is unresolved at the computed Ritz residual scale.');
        for jd=1:numel(shifts), counts(jd,ik)=sum(ev<shifts(jd)); end
    else
        for jd=1:numel(shifts)
            d=shifts(jd); err=0;
            if method=="spaaa"
                pole_tol=100*eps(max([1;abs(d);abs(model.theta)]));
                if min(abs(model.theta-d))>pole_tol
                    tt=tic; R=eval_projection(model,d); row.far_seconds=row.far_seconds+toc(tt);
                    tt=tic; [err,diagnostic]=projection_error_bound(model,s.lambda_far,d);
                    row.residual_seconds=row.residual_seconds+toc(tt);
                    row.explicit_residuals=row.explicit_residuals+diagnostic.used_explicit;
                else
                    err=Inf; R=[];
                end
            else
                tt=tic; R=eval_exact(s.lambda_far,s.F_far,d); row.far_seconds=row.far_seconds+toc(tt);
            end
            tt=tic;
            [counts(jd,ik),~,info]=inertia_count(s,cache,d,R,err);
            assert(info.reliable,'A fixed task threshold is unresolved; no count map is reported.');
            row.count_seconds=row.count_seconds+toc(tt);
            row.fallbacks=row.fallbacks+info.used_fallback;
        end
    end
    row.query_seconds=row.query_seconds+toc(tq);
    cumulative(ik)=toc(total);
end
row.total_seconds=toc(total);
row.other_seconds=row.total_seconds-row.assembly_seconds-row.spectral_seconds ...
    -row.model_seconds-row.update_seconds-row.query_seconds;
end

function [A0,U,b]=strip_problem(Nx,Ny)
% Ny interior Dirichlet nodes have spacing 1/(Ny+1).
hx=1/Nx; hy=1/(Ny+1); [x,y]=ndgrid((0:Nx-1)/Nx,(1:Ny)/(Ny+1));
v=2.5*cos(2*pi*x).*cos(pi*y);
centers=[.20,.30;.45,.70;.70,.32;.88,.68];
for j=1:4
    dx=min(abs(x-centers(j,1)),1-abs(x-centers(j,1)));
    mask=dx.^2+(y-centers(j,2)).^2<=.085^2;
    v(mask)=v(mask)-45*(1+.08*j);
end
ex=ones(Nx,1); ey=ones(Ny,1);
Lx=spdiags([-ex,2*ex,-ex],-1:1,Nx,Nx)/hx^2;
Ly=spdiags([-ey,2*ey,-ey],-1:1,Ny,Ny)/hy^2;
A0=.45*(kron(speye(Ny),Lx)+kron(Ly,speye(Nx)))+spdiags(v(:),0,Nx*Ny,Nx*Ny);
ix=[sub2ind([Nx,Ny],ones(Ny,1),(1:Ny)');sub2ind([Nx,Ny],Nx*ones(Ny,1),(1:Ny)')];
U=sparse(ix,1:numel(ix),1,Nx*Ny,numel(ix)); b=struct('Ny',Ny,'coupling',-.45/hx^2);
end

function T=strip_update(b,k)
Z=sparse(b.Ny,b.Ny); X=b.coupling*exp(-1i*k)*speye(b.Ny);
T=[Z,X;X',Z];
end

function count=sparse_inertia(A,d)
% MATLAB's sparse LDL supports real symmetric matrices. Realification of a
% complex Hermitian matrix duplicates every eigenvalue, including multiplicity.
complex_case=~isreal(A);
if complex_case
    A=[real(A),-imag(A);imag(A),real(A)];
end
[~,D,~]=ldl(A-d*speye(size(A,1)),'vector');
count=0; j=1; n=size(A,1);
pivot_tol=100*eps(max(1,norm(D,1)));
while j<=n
    if j<n && D(j+1,j)~=0
        ev=eig(full(D(j:j+1,j:j+1))); j=j+2;
    else
        ev=real(D(j,j)); j=j+1;
    end
    assert(all(abs(ev)>pivot_tol), ...
        'Independent LDL encountered an unresolved zero pivot.');
    count=count+sum(ev<0);
end
if complex_case
    assert(mod(count,2)==0,'Realified Hermitian inertia has odd multiplicity.');
    count=count/2;
end
end

function [ev,residual,orthogonality]=check_eigenpairs(A,V,values,normA)
% Include these checks in direct-method timings. Independent LDL counts
% also check for missing eigenvalues and incorrect multiplicities.
residual=max(vecnorm(A*V-V.*values.',2,1)./vecnorm(V,2,1));
orthogonality=norm(V'*V-eye(size(V,2)),'fro');
assert(isfinite(residual) && residual<=1e-8*max(1,normA), ...
    'Direct eigensolver returned eigenpairs with excessive residuals.');
assert(isfinite(orthogonality) && orthogonality<=1e-8*max(1,sqrt(size(V,2))), ...
    'Direct eigensolver returned nonorthogonal eigenvectors.');
assert(all(abs(imag(values))<=1e-10*max(1,normA)), ...
    'Hermitian direct eigensolver returned nonreal eigenvalues.');
ev=sort(real(values(:)));
end
