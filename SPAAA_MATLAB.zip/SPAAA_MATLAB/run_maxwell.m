function results = run_maxwell(mode,outdir,phase)
% TM Maxwell band calculations. Timings include setup; reference spectra
% and original-matrix count checks are computed separately.
% Usage: run_maxwell('full',outdir,'all')
% Phases main and mesh may be run independently.
if nargin<1, mode='full'; end
root=fileparts(mfilename('fullpath')); addpath(genpath(fullfile(root,'src')));
if nargin<2 || isempty(outdir)
    outdir=fullfile(root,'runs','maxwell');
end
if nargin<3, phase='all'; end
if strcmpi(mode,'smoke'), cfg=maxwellOptions('smoke'); else, cfg=maxwellOptions(mode); end
cfg.mode=mode; cfg.repeats=1; cfg.ns=401; cfg.sketch=4; cfg.svd_tol=1e-10;
cfg.match_samples=31; cfg.seed=20260924; cfg.guard_fraction=.10;
cfg.matrix_abs_target=1e-13;
if strcmpi(mode,'smoke')
    cfg.repeats=1; cfg.ns=41; cfg.match_samples=11; cfg.query_repeats=3;
end
if ~exist(outdir,'dir'), mkdir(outdir); end
results=struct('cfg',cfg,'output_directory',outdir);
environment=struct('matlab',version,'computer',computer,'threads',maxNumCompThreads, ...
    'date',char(datetime('now')),'reference','Checked existing low eigenpairs; dense full spectrum at benchmark k points', ...
    'timing_scope','Fresh assembly, non-oracle Ritz bounds, spectral/model setup, updates, and all bisection work; references and validation excluded', ...
    'sketch','Same orthonormal Omega on both sides: Omega'' R Omega; one global maximum-column-norm normalization', ...
    'timing_nesting','residual_setup is included in projection/model; fallback_count is included in count; update/far/residual/count are included in query', ...
    'exact_far_timing','Exact low-rank resolvent construction is included in count_seconds', ...
    'chebyshev_status','Unvalidated numerical baseline; all its bisection counts are independently checked', ...
    'residual','Safeguarded QR residual and explicit recomputation; numerical acceptance only', ...
    'driver','Unreliable counts are discarded and other interior shifts are attempted');
write_json(fullfile(outdir,'environment.json'),environment);
write_json(fullfile(outdir,'query_log_schema.json'),struct( ...
    'columns',{{'k_index','band','iteration','shift','count','fallback','used_dense', ...
    'explicit_residual','far_error','accepted_approximation','used_exact_far','reliable','reason_code'}}, ...
    'reason_codes',{{'1 accepted approximate/exact supplied far matrix','2 exact resolvent', ...
    '3 unresolved Schur margin; original matrix','4 original diagonal pole', ...
    '5 equal displaced counts','6 inconclusive truncation; original matrix','7 zero update','8 other'}}));
if any(strcmpi(phase,{'all','main'}))
    kinds={'rod','defect'}; sizes=[cfg.validation_main_N,cfg.defect_N];
    for example=1:2
        result=main_case(kinds{example},sizes(example),cfg,outdir);
        results.(kinds{example})=result;
        save(fullfile(outdir,[kinds{example} '_results.mat']),'result','-v7.3');
    end
end
if any(strcmpi(phase,{'all','mesh'}))
    results.mesh=mesh_study(cfg,outdir);
    mesh=results.mesh; save(fullfile(outdir,'mesh_results.mat'),'mesh','-v7.3');
end

save(fullfile(outdir,['run_' phase '.mat']),'results','-v7.3');
end

function result=main_case(kind,N,cfg,outdir)
fprintf('Maxwell synchronization %s N=%d\n',kind,N);
ks=benchmark_kpoints(); vertices=[0 0;pi 0;pi pi;0 0];
[kpath,ticks]=make_kpath(vertices,cfg.path_per_segment);
prob=build_tm_problem(N,kind);
reference=cell(size(ks,1),1); reference_low=zeros(cfg.nev,size(ks,1));
tref=tic;
for p=1:size(ks,1)
    A=original_matrix(prob,ks(p,:));
    reference{p}=sort(real(eig(full(A),'vector')));
    reference_low(:,p)=reference{p}(1:cfg.nev);
end
reference_seconds=toc(tref);
% Warm up each method on a small problem before timing.
warm=cfg; warm.ns=min(21,cfg.ns); warm.match_samples=7; warm.nev=min(3,cfg.nev);
for method=["spaaa","exact_lowrank"]
    timed_run(kind,8,ks(1,:),method,warm);
end
methods=["spaaa","exact_lowrank"];
rows=struct([]); validations=struct([]); querylogs=cell(cfg.repeats,2); runs=cell(cfg.repeats,2);
for repeat=1:cfg.repeats
    order=circshift(1:2,[0,1-repeat]);
    for position=1:2
        m=order(position);
        [row,run]=timed_run(kind,N,ks,methods(m),cfg);
        row.repeat=repeat; row.execution_position=position;
        validation=validate_queries(run.logs,reference,prob,ks);
        validation.method=methods(m); validation.repeat=repeat;
        row.max_eigenvalue_error=max(abs(run.values-reference_low),[],'all');
        row.max_scaled_eigenvalue_error=max(abs(run.values-reference_low)./max(1,abs(reference_low)),[],'all');
        row.resolved_count_mismatches=validation.resolved_count_mismatches;
        row.unresolved_reference_queries=validation.unresolved_reference_queries;
        rows=append(rows,row); validations=append(validations,validation);
        querylogs{repeat,m}=run.logs; runs{repeat,m}=rmfield(run,'logs');
        fprintf('%s round %d %s %.3fs q=%d fallback=%d mismatch=%d\n', ...
            kind,repeat,methods(m),row.total_seconds,row.q,row.fallbacks,row.resolved_count_mismatches);
        writetable(struct2table(rows),fullfile(outdir,[kind '_complete_runs.csv']));
        save(fullfile(outdir,[kind '_complete_checkpoint.mat']),'rows','runs','querylogs','reference','-v7.3');
        assert(validation.resolved_count_mismatches==0, ...
            'Resolved original-matrix count mismatch for %s; checkpoint and CSV saved.',methods(m));
    end
end
summary=summary_table(rows,methods);
writetable(summary,fullfile(outdir,[kind '_complete_summary.csv']));
writetable(struct2table(validations),fullfile(outdir,[kind '_count_validation.csv']));

% Compute the SP-AAA band path.
t=tic; band_interval=ritz_interval(prob,kpath,cfg.nev);
band_solver=spectral_data(prob,band_interval,cfg.guard_fraction);
[band_solver.model,band_solver.support,~]=make_model(band_solver,cfg,"new_two_sided_selection");
band_setup_seconds=toc(t); band_solver.cheb=[];
[band_values,band_logs,band_stats]=query_bisection(band_solver,prob,kpath, ...
    repmat(band_interval,size(kpath,1),1),"spaaa",cfg);
t=tic; [band_ref,ref_check]=reference_path(prob,kpath,cfg.nev);
band_reference_seconds=toc(t);
band_error=max(abs(band_values-band_ref),[],'all');
bands=table((1:size(kpath,1)).',kpath(:,1),kpath(:,2),'VariableNames',{'path_index','kx','ky'});
for j=1:cfg.nev
    bands.(['reference_lambda_' num2str(j)])=band_ref(j,:).';
    bands.(['spaaa_lambda_' num2str(j)])=band_values(j,:).';
end
writetable(bands,fullfile(outdir,[kind '_band_values.csv']));

% Compute field diagnostics from the reference eigenpairs.
if strcmp(kind,'rod'), field_k=[pi pi]; else, field_k=[0 0]; end
[V,ev,field_check]=checked_lowest(original_matrix(prob,field_k),cfg.nev);
physical=prob.mass_inv_sqrt.*V;
if strcmp(kind,'rod')
    mode_index=min(5,cfg.nev); fraction=NaN;
else
    mask=(prob.x-.5).^2+(prob.y-.5).^2<.18^2;
    fractions=sum(abs(physical(mask,:)).^2,1)./sum(abs(physical).^2,1);
    [fraction,mode_index]=max(fractions(2:end)); mode_index=mode_index+1;
end
field=reshape(abs(physical(:,mode_index)).^2,N,N);
fig=figure('Visible','off','Color','w'); tiledlayout(1,2);
nexttile; plot(sqrt(max(band_values,0)).'/(2*pi),'LineWidth',1); grid on;
xticks(ticks); xticklabels({'\Gamma','X','M','\Gamma'}); ylabel('\omega a/(2\pi c)');
title([kind ' : updated SP-AAA bands']);
nexttile; imagesc(field); axis image xy; colorbar;
if strcmp(kind,'rod')
    title(sprintf('Field band %d at M',mode_index));
else
    title(sprintf('Field band %d; centre fraction %.4g',mode_index,fraction));
end
exportgraphics(fig,fullfile(outdir,[kind '_updated_bands_field.pdf']),'ContentType','vector');
exportgraphics(fig,fullfile(outdir,[kind '_updated_bands_field.png']),'Resolution',160); close(fig);
result=struct('kind',kind,'N',N,'reference_low',reference_low,'reference_seconds',reference_seconds, ...
    'runs',struct2table(rows),'summary',summary,'querylogs',{querylogs},'run_details',{runs}, ...
    'band_values',band_values,'band_reference',band_ref,'band_reference_check',ref_check, ...
    'band_setup_seconds',band_setup_seconds,'band_reference_seconds',band_reference_seconds, ...
    'band_query_stats',band_stats,'band_query_logs',band_logs,'band_max_error',band_error, ...
    'field_mode',mode_index,'field_lambda',ev(mode_index),'field_fraction',fraction,'field_check',field_check);
end

function [row,run]=timed_run(kind,N,ks,method,cfg)
rng(cfg.seed,'twister'); total=tic;
t=tic; prob=build_tm_problem(N,kind); assembly=toc(t);
t=tic; interval=ritz_interval(prob,ks,cfg.nev); bound_seconds=toc(t);
t=tic; s=spectral_data(prob,interval,cfg.guard_fraction); spectral_seconds=toc(t);
model_timing=struct('total',0,'sketch',0,'selection',0,'projection',0,'residual_setup',0);
cheb_seconds=0; validation_seconds=0; sampled_error=0; s.model=[]; s.cheb=[]; support=[];
sample=linspace(interval(1),interval(2),cfg.match_samples);
if method=="spaaa"
    [s.model,support,model_timing]=make_model(s,cfg,"new_two_sided_selection");
    t=tic;
    for d=sample
        sampled_error=max(sampled_error,norm(eval_exact(s.lambda_far,s.F_far,d)-eval_projection(s.model,d),2));
    end
    validation_seconds=toc(t); model_timing.total=model_timing.total+validation_seconds;
elseif method=="chebyshev_fixed_target"
    t=tic;
    s.cheb=build_cheb_fixed_target(s.lambda_far,s.F_far,interval,sample,cfg.matrix_abs_target);
    cheb_seconds=toc(t); sampled_error=s.cheb.sampled_error;
end
[values,logs,stats]=query_bisection(s,prob,ks,repmat(interval,size(ks,1),1),method,cfg);
row=stats; row.method=method; row.total_seconds=toc(total); row.assembly_seconds=assembly;
row.bound_seconds=bound_seconds; row.spectral_seconds=spectral_seconds;
row.model_seconds=model_timing.total; row.sketch_seconds=model_timing.sketch;
row.selection_seconds=model_timing.selection; row.projection_seconds=model_timing.projection;
row.residual_setup_seconds=model_timing.residual_setup; row.cheb_setup_seconds=cheb_seconds;
row.spectral_orthogonality_error=s.spectral_orthogonality_error;
row.spectral_relative_residual=s.spectral_relative_residual;
row.model_validation_seconds=validation_seconds; row.matrix_abs_target=cfg.matrix_abs_target;
row.sampled_resolvent_error=sampled_error; row.sampled_target_attained=sampled_error<=cfg.matrix_abs_target;
row.q=0; row.cheb_degree=0; row.cheb_target_attained=false; row.support_count=numel(support);
if ~isempty(s.model), row.q=size(s.model.V,2); end
if ~isempty(s.cheb), row.cheb_degree=s.cheb.degree; row.cheb_target_attained=s.cheb.target_attained; end
row.other_seconds=row.total_seconds-assembly-bound_seconds-spectral_seconds ...
    -model_timing.total-cheb_seconds-stats.query_seconds;
run=struct('values',values,'logs',logs,'interval',interval,'support',support);
end

function interval=ritz_interval(prob,ks,nev)
% Use positivity and the Rayleigh--Ritz principle to bound the first nev eigenvalues.
[ax,ay]=ndgrid(-2:2,-2:2); modes=[ax(:),ay(:)];
assert(nev<=size(modes,1));
hi=0;
for p=1:size(ks,1)
    phase=prob.x*(2*pi*modes(:,1).'+ks(p,1))+prob.y*(2*pi*modes(:,2).'+ks(p,2));
    trial=sqrt(prob.eps).*exp(1i*phase); [Q,~]=qr(trial,0);
    A=original_matrix(prob,ks(p,:)); H=Q'*A*Q;
    ev=sort(real(eig((H+H')/2,'vector'))); hi=max(hi,ev(nev));
end
hi=max(hi,1); interval=[-.01*hi,1.10*hi];
end

function cheb=build_cheb_fixed_target(lambda,F,interval,sample,threshold)
% Record the attained Chebyshev degree and error on the 31-point test grid.
reference=cell(size(sample));
for j=1:numel(sample), reference{j}=eval_exact(lambda,F,sample(j)); end
for degree=4:2:160
    coefficients=cheb_coefficients(lambda,F,interval,degree); measured=0;
    for j=1:numel(sample)
        measured=max(measured,norm(reference{j}-eval_cheb_coeff(coefficients,interval,sample(j)),2));
    end
    if measured<=threshold, break; end
end
cheb=struct('coeff',{coefficients},'interval',interval,'degree',degree, ...
    'sampled_error',measured,'sampled_target',threshold,'target_attained',measured<=threshold);
end

function s=spectral_data(prob,interval,guard_fraction)
A0=(prob.A0+prob.A0')/2;
[Q,lambda]=eig(full(A0),'vector'); [lambda,ix]=sort(real(lambda)); Q=Q(:,ix);
orthogonality=norm(Q'*Q-eye(numel(lambda)),'fro');
relative_residual=norm(A0*Q-Q.*lambda.','fro')/max(1,norm(A0,'fro'));
assert(orthogonality<1e-8 && relative_residual<1e-10, ...
    'A0 spectral transformation is not numerically unitary/accurate.');
F=Q'*prob.U; near=lambda>=interval(1)-guard_fraction*diff(interval) & ...
    lambda<=interval(2)+guard_fraction*diff(interval);
s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near),'F_near',F(near,:), ...
    'lambda_far',lambda(~near),'F_far',F(~near,:),'interval',interval, ...
    'spectral_orthogonality_error',orthogonality,'spectral_relative_residual',relative_residual);
end

function [model,support,timing]=make_model(s,cfg,selection)
rng(cfg.seed,'twister'); total=tic; z=linspace(s.interval(1),s.interval(2),cfg.ns);
t=tic;
if selection=="legacy_selection_reconstruction"
    % Use a complex sketch R*Omega with independent row scaling.
    r=size(s.F_far,2); Omega=randn(r,cfg.sketch)+1i*randn(r,cfg.sketch);
    sketches=zeros(r*cfg.sketch,numel(z));
    for j=1:numel(z)
        R=eval_exact(s.lambda_far,s.F_far,z(j)); G=R*Omega;
        sketches(:,j)=G(:);
    end
    row_scale=max(vecnorm(sketches,2,2),eps); sketches=sketches./row_scale;
else
    sketches=sketch_samples(s.lambda_far,s.F_far,z,cfg.sketch);
    scale=max(vecnorm(sketches,2,1));
    if scale>0, sketches=sketches/scale; end
end
timing.sketch=toc(t); t=tic;
support=setvalued_aaa_support(z,sketches,cfg.aaa_tol,cfg.max_support);
timing.selection=toc(t); t=tic;
model=build_projection_model(s.lambda_far,s.F_far,support,cfg.svd_tol);
timing.projection=toc(t); timing.residual_setup=model.residual_setup_seconds;
timing.total=toc(total);
end

function [values,logs,stats]=query_bisection(s,prob,ks,brackets,method,cfg)
stats=struct('query_seconds',0,'update_seconds',0,'far_seconds',0,'residual_seconds',0, ...
    'count_seconds',0,'fallback_count_seconds',0,'queries',0,'accepted',0, ...
    'fallbacks',0,'dense_fallbacks',0,'explicit_residuals',0,'exact_far_queries',0,'unreliable_queries',0);
logs=zeros(0,13); values=zeros(cfg.nev,size(ks,1)); tq=tic;
for p=1:size(ks,1)
    t=tic; cache=prepare_inertia_update(s,boundary_T(prob,ks(p,:)));
    stats.update_seconds=stats.update_seconds+toc(t);
    for band=1:cfg.nev
        lo=brackets(p,1); hi=brackets(p,2); iteration=0; probe=1;
        while hi-lo>cfg.bisect_tol*max(1,abs(hi)+abs(lo))
            fractions=[.5 .25 .75 .375 .625 .125 .875];
            assert(probe<=numel(fractions),'All interior probes unresolved; refusing to return an eigenvalue.');
            d=lo+fractions(probe)*(hi-lo); iteration=iteration+1; eta=0; explicit=false;
            original_pole=min(abs(s.lambda-d))<=100*eps(max([1;abs(d);abs(s.lambda)]));
            if original_pole
                R=[]; eta=Inf;
            elseif method=="spaaa"
                pole_tol=100*eps(max([1;abs(d);abs(s.model.theta)]));
                if min(abs(s.model.theta-d))<=pole_tol
                    R=[]; eta=Inf;
                else
                    t=tic; R=eval_projection(s.model,d); stats.far_seconds=stats.far_seconds+toc(t);
                    t=tic; [eta,diagnostic]=projection_error_bound(s.model,s.lambda_far,d);
                    stats.residual_seconds=stats.residual_seconds+toc(t); explicit=diagnostic.used_explicit;
                end
            elseif method=="chebyshev_fixed_target"
                t=tic; R=eval_cheb(s.cheb,d); stats.far_seconds=stats.far_seconds+toc(t);
            else
                R=[];
            end
            t=tic;
            if method=="chebyshev_fixed_target", [count,~,info]=inertia_count(s,cache,d,R);
            else, [count,~,info]=inertia_count(s,cache,d,R,eta); end
            dt=toc(t); stats.count_seconds=stats.count_seconds+dt;
            fallback=info.used_fallback || (method=="spaaa" && isempty(R));
            stats.fallback_count_seconds=stats.fallback_count_seconds+fallback*dt;
            stats.accepted=stats.accepted+(method=="spaaa" && info.accepted_approximation && ~fallback);
            stats.fallbacks=stats.fallbacks+fallback;
            stats.dense_fallbacks=stats.dense_fallbacks+info.used_dense;
            stats.exact_far_queries=stats.exact_far_queries+info.used_exact_far;
            stats.unreliable_queries=stats.unreliable_queries+~info.reliable;
            stats.explicit_residuals=stats.explicit_residuals+explicit; stats.queries=stats.queries+1;
            logs(end+1,:)=[p,band,iteration,d,count,fallback,info.used_dense,explicit,eta, ...
                info.accepted_approximation,info.used_exact_far,info.reliable,reason_code(info.reason)]; %#ok<AGROW>
            if ~info.reliable, probe=probe+1; continue; end
            probe=1;
            if count>=band, hi=d; else, lo=d; end
        end
        values(band,p)=(lo+hi)/2;
    end
end
stats.query_seconds=toc(tq);
end

function v=validate_queries(logs,reference,prob,ks)
v=struct('queries',size(logs,1),'resolved_count_mismatches',0, ...
    'unresolved_reference_queries',0,'all_resolved_counts_match',true);
scale=zeros(size(ks,1),1);
for p=1:size(ks,1), scale(p)=100*eps*max(1,norm(original_matrix(prob,ks(p,:)),1)); end
for j=1:size(logs,1)
    p=logs(j,1); d=logs(j,4); ev=reference{p}; gap=min(abs(ev-d));
    if gap<=scale(p), v.unresolved_reference_queries=v.unresolved_reference_queries+1;
    else, v.resolved_count_mismatches=v.resolved_count_mismatches+(logs(j,5)~=sum(ev<d)); end
end
v.all_resolved_counts_match=v.resolved_count_mismatches==0;
end

function data=mesh_study(cfg,outdir)
vertices=[0 0;pi 0;pi pi]; values=cell(numel(cfg.validation_N),1); checks=cell(size(values)); rows=struct([]);
for j=1:numel(cfg.validation_N)
    N=cfg.validation_N(j); prob=build_tm_problem(N,'rod'); t=tic;
    [ev,checks{j}]=reference_path(prob,vertices,cfg.nev); values{j}=sqrt(max(ev,0))/(2*pi);
    row=struct('N',N,'n',N^2,'reference_seconds',toc(t)); rows=append(rows,row);
    fprintf('Maxwell mesh N=%d checked\n',N);
end
ref=values{end};
for j=1:numel(values)
    delta=values{j}-ref; rows(j).max_frequency_error=max(abs(delta),[],'all');
    rows(j).relative_l2_error=norm(delta(:))/max(norm(ref(:)),eps);
end
data=struct('table',struct2table(rows),'frequencies',{values},'checks',{checks});
writetable(data.table,fullfile(outdir,'mesh_convergence.csv'));
end

function [values,checks]=reference_path(prob,ks,nev)
values=zeros(nev,size(ks,1)); checks=struct([]);
for p=1:size(ks,1)
    [~,values(:,p),check]=checked_lowest(original_matrix(prob,ks(p,:)),nev);
    check.kx=ks(p,1); check.ky=ks(p,2); checks=append(checks,check);
end
end

function [V,ev,check]=checked_lowest(A,nev)
[V,ev]=lowest_eigpairs(A,nev); residual=max(vecnorm(A*V-V.*ev.',2,1));
orthogonality=norm(V'*V-eye(nev),'fro'); scale=max(1,norm(A,1));
assert(isfinite(residual) && residual/scale<1e-8 && orthogonality<1e-8, ...
    'Reference eigenpairs failed residual/orthogonality checks.');
check=struct('relative_residual',residual/scale,'absolute_residual',residual, ...
    'orthogonality_error',orthogonality,'source',"existing checked lowest_eigpairs");
end

function A=original_matrix(prob,k)
A=prob.A0+prob.U*boundary_T(prob,k)*prob.U'; A=(A+A')/2;
end

function tbl=summary_table(rows,methods)
runs=struct2table(rows); summary=struct([]);
for method=methods
    x=runs(runs.method==method,:);
    row=struct('method',method,'repeats',height(x),'median_seconds',median(x.total_seconds), ...
        'min_seconds',min(x.total_seconds),'max_seconds',max(x.total_seconds), ...
        'max_eigenvalue_error',max(x.max_eigenvalue_error), ...
        'max_scaled_eigenvalue_error',max(x.max_scaled_eigenvalue_error), ...
        'count_mismatches',sum(x.resolved_count_mismatches),'median_queries',median(x.queries), ...
        'median_accepted',median(x.accepted),'median_fallbacks',median(x.fallbacks));
    summary=append(summary,row);
end
tbl=struct2table(summary);
end

function rows=append(rows,row)
if isempty(rows), rows=row; else, rows(end+1)=row; end
end

function code=reason_code(reason)
reasons={'far-field error below numerical inertia margin','exact resolvent', ...
    'unresolved numerical inertia margin; original matrix', ...
    'original diagonal pole; original matrix','equal reliable displaced effective counts', ...
    'truncation enclosure inconclusive; original matrix','zero update'};
code=find(strcmp(reason,reasons),1); if isempty(code), code=8; end
end

function write_json(path,data)
fid=fopen(path,'w'); assert(fid>=0); cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s',jsonencode(data,PrettyPrint=true));
end


