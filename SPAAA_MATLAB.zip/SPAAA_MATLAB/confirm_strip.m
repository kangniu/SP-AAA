function confirm_strip(base)
% Strip approximation errors and fixed-query inertia checks.
root=fileparts(mfilename('fullpath')); addpath(genpath(fullfile(root,'src')));
if nargin<1, base=fullfile(root,'runs','selection'); end
outdir=fullfile(base,'validation'); if ~exist(outdir,'dir'), mkdir(outdir); end
assert(~exist(fullfile(outdir,'strip_confirmation.csv'),'file'),'Use fresh output paths.');
maxNumCompThreads(2); %#ok<MAXNCT>
% Two spectral windows, three sketch seeds, and original-matrix counts.
ids={'strip_n512_p24_g010','strip_n512_p48_g010'};
rows=struct([]); saved=cell(1,numel(ids));
for c=1:numel(ids)
    x=load(fullfile(base,'strip',[ids{c} '.mat'])); s=x.s; interval=x.interval;
    u=unique([.5+.5*cos(pi*((1:1001)-.5)/1001),logspace(-12,-1,161), ...
        1-logspace(-12,-1,161),0,1]); test=interval(1)+diff(interval)*u;
    [exact,rnorm]=reference_resolvents(s,test);
    configs=struct([]); prefix=cell(1,3); seeds=[37 503 907];
    for is=1:3
        rng(seeds(is),'twister'); sketch=sketch_samples(s.lambda_far,s.F_far,x.train,4);
        prefix{is}=setvalued_aaa_support(x.train,sketch/max(vecnorm(sketch,2,1)),0,7);
    end
    for method={'aaa_sketch','lobatto','uniform'}
        name=method{1}; use_seeds=0; if strcmp(name,'aaa_sketch'), use_seeds=seeds; end
        for seed=use_seeds
            for m=3:7
                if strcmp(name,'aaa_sketch'), selected=prefix{find(seeds==seed,1)}; support=selected(1:min(m,numel(selected)));
                else, support=fixed_support(name,interval,m); end
                model=build_projection_model(s.lambda_far,s.F_far,support,1e-10);
                errors=zeros(size(test));
                for j=1:numel(test), errors(j)=norm(exact{j}-eval_projection(model,test(j)),2); end
                assert(all(isfinite(errors)),'Nonfinite strip confirmation error.');
                row=struct('case_id',string(ids{c}),'method',string(name),'seed',seed,'budget',m, ...
                    'actual_m',numel(support),'q',numel(model.theta), ...
                    'max_relative_error',max(errors./rnorm),'max_absolute_error',max(errors), ...
                    'global_relative_error',max(errors)/max(rnorm));
                rows=append(rows,row);
                config=struct('row',row,'support',support,'errors',errors); configs=append(configs,config);
            end
        end
    end
    save(fullfile(outdir,[ids{c} '_confirmation.mat']),'configs','test','rnorm','seeds','interval');
    writetable(struct2table(rows),fullfile(outdir,'strip_confirmation.csv'));
    saved{c}=x; fprintf('[Strip confirmation] %s complete.\n',ids{c});
end
counts=struct([]); logs=struct([]);
for c=1:2
    if c<=2
        x=saved{c}; s=x.s; interval=x.interval; train=x.train; id=ids{c};
        A0=x.A0; U=x.U; parameters=(0:4)*pi/4; updates=cell(1,5);
        for k=1:5
            X=x.boundary.coupling*exp(-1i*parameters(k))*eye(x.boundary.Ny);
            updates{k}=[zeros(x.boundary.Ny),X;X',zeros(x.boundary.Ny)];
        end
    end
    shifts=interval(1)+diff(interval)*((0:60)+.314159)/61;
    ref=zeros(61,5); refgap=zeros(61,5); resolved=false(61,5); caches=cell(1,5);
    for k=1:5
        A=A0+U*updates{k}*U'; A=(A+A')/2; ev=sort(real(eig(full(A),'vector')));
        separation=100*eps*max(1,norm(A,1));
        for j=1:61
            ref(j,k)=sum(ev<shifts(j)); refgap(j,k)=min(abs(ev-shifts(j)));
            resolved(j,k)=refgap(j,k)>separation;
        end
        caches{k}=prepare_inertia_update(s,updates{k});
    end
    assert(numel(unique(ref))>2,'The intended count test is trivial.');
    rng(37,'twister'); sketch=sketch_samples(s.lambda_far,s.F_far,train,4);
    prefix=setvalued_aaa_support(train,sketch/max(vecnorm(sketch,2,1)),0,6);
    for method={'aaa_sketch','lobatto','uniform'}
        name=method{1};
        for m=[4 5 6]
            if strcmp(name,'aaa_sketch'), support=prefix(1:min(m,numel(prefix)));
            else, support=fixed_support(name,interval,m); end
            model=build_projection_model(s.lambda_far,s.F_far,support,1e-10);
            eta=zeros(1,61); approx=cell(1,61); residual_info=cell(1,61);
            for j=1:61
                approx{j}=eval_projection(model,shifts(j));
                [eta(j),residual_info{j}]=projection_error_bound(model,s.lambda_far,shifts(j));
            end
            row=struct('case_id',string(id),'method',string(name),'budget',m,'actual_m',numel(support), ...
                'q',numel(model.theta),'queries',305,'accepted',0,'fallbacks',0,'dense',0, ...
                'unreliable',0,'resolved_mismatches',0,'reference_unresolved',sum(~resolved,'all'), ...
                'distinct_reference_counts',numel(unique(ref)),'min_reference_count',min(ref,[],'all'), ...
                'max_reference_count',max(ref,[],'all'));
            for k=1:5
                for j=1:61
                    [n,margin,info]=spaaa_inertia_count(s,caches{k},shifts(j),approx{j},eta(j));
                    mismatch=resolved(j,k) && n~=ref(j,k);
                    row.accepted=row.accepted+info.accepted_approximation;
                    row.fallbacks=row.fallbacks+info.used_fallback;
                    row.dense=row.dense+info.used_dense; row.unreliable=row.unreliable+~info.reliable;
                    row.resolved_mismatches=row.resolved_mismatches+mismatch;
                    record=struct('case_id',string(id),'method',string(name),'budget',m,'k_index',k, ...
                        'shift',shifts(j),'count',n,'reference',ref(j,k),'reference_gap',refgap(j,k), ...
                        'reference_resolved',resolved(j,k),'accepted',info.accepted_approximation, ...
                        'fallback',info.used_fallback,'dense',info.used_dense,'reliable',info.reliable, ...
                        'far_error',eta(j),'margin',margin,'reason',string(info.reason),'mismatch',mismatch);
                    logs=append(logs,record);
                end
            end
            counts=append(counts,row);
        end
    end
    writetable(struct2table(counts),fullfile(outdir,'inertia_summary.csv'));
    writetable(struct2table(logs),fullfile(outdir,'inertia_queries.csv'));
    fprintf('[Original-matrix counts] %s complete; %d methods/budgets.\n',id,9);
end
assert(all([counts.resolved_mismatches]==0),'Original-matrix count mismatch; inspect saved logs.');
save(fullfile(outdir,'validation_summary.mat'),'counts','rows','-v7.3');
end

function support=fixed_support(name,interval,m)
if strcmp(name,'lobatto'), support=sort(mean(interval)+.5*diff(interval)*cos(linspace(0,pi,m)));
else, support=linspace(interval(1),interval(2),m); end
end
function rows=append(rows,row)
if isempty(rows), rows=row; else, rows(end+1)=row; end
end
function [exact,rnorm]=reference_resolvents(s,test)
exact=cell(size(test)); rnorm=zeros(size(test));
for j=1:numel(test)
    R=s.F_far'*(s.F_far./(s.lambda_far-test(j))); R=(R+R')/2;
    exact{j}=R; rnorm(j)=norm(R,2);
end
end
