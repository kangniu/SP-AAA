function plot_scalar_support(data,outdir)
% Plot scalar band structures and support-count sensitivity.
root=fileparts(mfilename('fullpath'));
assert(nargin>=1 && ~isempty(data),'Provide the experiment output folder.');
if nargin<2 || isempty(outdir),outdir=fullfile(root,'figures');end
if ~exist(outdir,'dir'),mkdir(outdir);end
names={'defect','electronic','largecell'};
labels={'Point-defect supercell','Electronic superlattice','High-contrast supercell'};
f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7.4 6.6]);
tiledlayout(3,2,'TileSpacing','compact','Padding','compact');
for i=1:3
 folder=fullfile(data,'scalar',names{i});
 b=readtable(fullfile(folder,[names{i} '_bands.csv']));
 e=readtable(fullfile(folder,[names{i} '_residual_diagnostics.csv']));
 summary=readtable(fullfile(folder,'summary.csv'));
 nexttile;plot(b.path_distance,b{:,4:end},'LineWidth',.65);grid on;
 ticks=[1,find(abs(b.kx-pi)<1e-12 & abs(b.ky)<1e-12,1),find(abs(b.kx-pi)<1e-12 & abs(b.ky-pi)<1e-12,1),height(b)];
 xticks(b.path_distance(ticks));xticklabels({'\Gamma','X','M','\Gamma'});
 ylabel('\lambda');xlabel('Bloch path');title([labels{i} ': reference bands']);
 nexttile;semilogy(e.shift,e.relative_matrix_error,'-',e.shift,e.cheb4_relative_error,'--', ...
  e.shift,e.cheb_matched_relative_error,':','LineWidth',1);grid on;
 xlabel('Shift d');ylabel('Relative far-field error');
 legend({'SP-AAA','Cheb-4',sprintf('Cheb-%d',summary.matched_cheb_degree)},'Location','best','Box','off');
 title(sprintf('n = %d, r = %d',summary.n,summary.r_columns));
end
finish(f,outdir,'figure_03_scalar');

x=readtable(fullfile(data,'support','summary.csv'));
f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7 2.65]);
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
nexttile;semilogy(x.m,x.max_relative_error,'-o','LineWidth',1,'MarkerSize',4);grid on;
xlabel('Retained block samples m');ylabel('Maximum relative far-field error');title('(a) Maxwell defect model');xticks(x.m);
nexttile;plot(x.m,x.accepted_fraction,'-o',x.m,x.fallbacks./x.queries,'--s','LineWidth',1,'MarkerSize',4);grid on;
xlabel('Retained block samples m');ylabel('Fraction of fixed-grid queries');ylim([-.04 1.04]);xticks(x.m);
title(sprintf('(b) %d queries per model',x.queries(1)));
legend({'Accepted approximation','Direct fallback'},'Location','best','Box','off');
finish(f,outdir,'figure_05_support');
end
function finish(f,outdir,name)
set(findall(f,'Type','axes'),'FontName','Times New Roman','FontSize',9);
exportgraphics(f,fullfile(outdir,[name '.pdf']),'ContentType','vector');
exportgraphics(f,fullfile(outdir,[name '.png']),'Resolution',180);close(f);
end
