function outdir = run_examples(mode,outdir)
% Run the numerical examples. Modes: 'quick' or 'full'.
if nargin < 1, mode = 'quick'; end
mode = validatestring(mode,{'quick','full'});
root = fileparts(mfilename('fullpath'));
addpath(root,genpath(fullfile(root,'src')));
if nargin < 2
    stamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
    outdir = fullfile(root,'runs',stamp);
end
assert(~exist(outdir,'dir'),'Choose a new output directory.');
mkdir(outdir);
if strcmp(mode,'quick'), profile = 'smoke'; else, profile = 'full'; end

maxNumCompThreads(16);
run_selection(profile,fullfile(outdir,'selection'));
maxNumCompThreads(16);
run_scalar_models(profile,fullfile(outdir,'scalar'));
run_parameters(profile,fullfile(outdir,'parameters'));
run_support_sensitivity(profile,fullfile(outdir,'support'));
run_maxwell(profile,fullfile(outdir,'maxwell'),'all');
if strcmp(mode,'full')
    validate_maxwell(fullfile(outdir,'maxwell'));
    timing_mode = 'full';
else
    timing_mode = 'quick';
end
run_timing(timing_mode,fullfile(outdir,'timing'));
run_largecell_timing(profile,fullfile(outdir,'largecell_timing'));

if strcmp(mode,'full')
    run_band_confirmation(fullfile(outdir,'bandcost'));
else
    maxNumCompThreads(4);
    cfg = struct('Nx',32,'Ny',8,'Lx',1,'bands',8,'nk',2,'m',4);
    run_band_cost(cfg,fullfile(outdir,'bandcost_quick'));
end
fprintf('Results saved to %s\n',outdir);
end
