function [out,row] = run_scalar_case(api,spec,cfg,outdir)
t=tic; [A0,U,bd,meta]=api.build_problem(spec); assembly_seconds=toc(t);
n=size(A0,1); r=size(U,2);
t=tic;
[Q,lambda]=eig(full(A0),'vector'); [lambda,ord]=sort(real(lambda));
Q=Q(:,ord); F=Q'*U;
spectral_seconds=toc(t);
assert(norm(A0*Q-Q.*lambda.','fro')/max(1,norm(A0,'fro'))<1e-10);
assert(norm(Q'*Q-eye(n),'fro')<1e-8); clear Q
t=tic;
width=max(1,lambda(12)-lambda(1));
interval=[lambda(1)-.03*width,lambda(13)+.08*width];
pad=max(.08*diff(interval),100*eps(max(abs(lambda))));
near=lambda>=interval(1)-pad & lambda<=interval(2)+pad;
s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near),'F_near',F(near,:), ...
    'lambda_far',lambda(~near),'F_far',F(~near,:));
partition_seconds=toc(t);
grid=sort(mean(interval)+diff(interval)/2*cos(linspace(pi,0,cfg.samples)));
t=tic; samples=sketch_samples(s.lambda_far,s.F_far,grid,cfg.sketch);
sample_scale=max(vecnorm(samples,2,1));
% One global scaling yields a relative AAA tolerance; no per-row scaling.
scaled_samples=samples/max(sample_scale,realmin);
sketch_seconds=toc(t);
t=tic; support=setvalued_aaa_support(grid,scaled_samples,cfg.aaa_tol,cfg.max_support);
aaa_seconds=toc(t);
t=tic; model=build_projection_model(s.lambda_far,s.F_far,support,cfg.svd_tol);
projection_seconds=toc(t); s.model=model;
test=linspace(interval(1),interval(2),cfg.error_shifts);
t=tic; cheb4=api.build_cheb_model(s.lambda_far,s.F_far,interval,5);
cheb4_seconds=toc(t);
exact=cell(numel(test),1); diagnostic=cell(numel(test),1);
for j=1:numel(test)
    d=test(j); R=eval_exact(s.lambda_far,s.F_far,d); exact{j}=R;
    Rp=eval_projection(model,d);
    [eta,ri]=projection_error_bound(model,s.lambda_far,d,true);
    Y=model.Uh*(model.C./(model.theta-d));
    explicit=norm(s.F_far-(s.lambda_far-d).*(model.V*Y),'fro');
    actual=norm(R-Rp,2); scale=max(norm(R,2),eps);
    old_eta=model.normF2*sqrt(max(ri.raw_residual_squared,0))/min(abs(s.lambda_far-d));
    diagnostic{j}=struct('shift',d,'absolute_matrix_error',actual, ...
        'relative_matrix_error',actual/scale, ...
        'cheb4_relative_error',norm(R-api.eval_cheb(cheb4,d),2)/scale, ...
        'new_indicator',eta,'computed_residual_norm',ri.residual_norm, ...
        'explicit_residual_norm',explicit,'roundoff_allowance',ri.roundoff_allowance, ...
        'explicit_recomputed',ri.explicit_recomputed, ...
        'legacy_squared_residual',ri.raw_residual_squared, ...
        'legacy_clipped_indicator',old_eta, ...
        'legacy_negative_square',ri.raw_residual_squared<0, ...
        'legacy_zero_indicator',old_eta==0, ...
        'legacy_below_matrix_error',old_eta<actual, ...
        'new_below_matrix_error',eta<actual);
end
diagnostics=struct2table(vertcat(diagnostic{:}));
t=tic;
chebmatch=cheb4; matched_degree=4; matched_errors=diagnostics.cheb4_relative_error;
for degree=[8 12 16 24 32 48 64 80]
    candidate=api.build_cheb_model(s.lambda_far,s.F_far,interval,degree+1);
    errors=zeros(numel(test),1);
    for j=1:numel(test)
        errors(j)=norm(exact{j}-api.eval_cheb(candidate,test(j)),2)/max(norm(exact{j},2),eps);
    end
    chebmatch=candidate; matched_degree=degree; matched_errors=errors;
    if max(errors)<=1e-10, break; end
end
cheb_search_seconds=toc(t); diagnostics.cheb_matched_relative_error=matched_errors;
writetable(diagnostics,fullfile(outdir,[spec.name '_residual_diagnostics.csv']));
clear exact samples scaled_samples

% Independent physical-operator LDL reference lies outside all timed loops.
klist=[.17 .13;.41 .08;.37 .44]*pi;
shifts=linspace(interval(1)+.03*diff(interval),interval(2)-.03*diff(interval),cfg.count_shifts);
validation_t=tic;
references=zeros(size(klist,1),numel(shifts));
for ik=1:size(klist,1)
    A=A0+U*api.boundary_T(bd,klist(ik,:))*U'; A=(A+A')/2;
    for j=1:numel(shifts), references(ik,j)=ldl_count(A-shifts(j)*speye(n)); end
end
reference_seconds=toc(validation_t);
queries=cell(numel(references),1); z=0;
for ik=1:size(klist,1)
    T=api.boundary_T(bd,klist(ik,:)); update=prepare_inertia_update(s,T);
    for j=1:numel(shifts)
        d=shifts(j); z=z+1;
        [count,margin,ci,ri]=protected_query(s,update,d);
        [exactcount,~,ei]=spaaa_inertia_count(s,update,d,[]);
        % Compare the squared-norm indicator on the same projection model.
        [~,legacyri]=projection_error_bound(model,s.lambda_far,d,true);
        oldeta=model.normF2*sqrt(max(legacyri.raw_residual_squared,0))/min(abs(s.lambda_far-d));
        Rnear=eval_exact(s.lambda_near,s.F_near,d);
        oldM=inv(full(T))+Rnear+eval_projection(model,d); oldM=(oldM+oldM')/2;
        oldev=real(eig(oldM)); oldgap=min(abs(oldev));
        oldcount=sum(lambda<d)+sum(oldev>0)-sum(real(eig(-inv(full(T))))<0);
        queries{z}=struct('kx',klist(ik,1),'ky',klist(ik,2),'shift',d, ...
            'reference_ldl_count',references(ik,j),'protected_sp_count',count, ...
            'exact_count',exactcount,'original_count_agreement',count==references(ik,j), ...
            'exact_count_agreement',exactcount==references(ik,j), ...
            'accepted_approximation',ci.accepted_approximation && ~ci.used_fallback, ...
            'fallback',ci.used_fallback,'dense_fallback',ci.used_dense, ...
            'reliable',ci.reliable,'reason',ci.reason, ...
            'exact_reliable',ei.reliable,'exact_reason',ei.reason, ...
            'explicit_residual',ri.explicit_recomputed, ...
            'indicator',ri.eta,'resolvent_margin',margin, ...
            'old_accept_same_model',oldgap>oldeta, ...
            'old_approximate_count',oldcount,'old_count_agreement',oldcount==references(ik,j), ...
            'exact_dense_fallback',ei.used_dense);
    end
end
querytable=struct2table(vertcat(queries{:}));
writetable(querytable,fullfile(outdir,[spec.name '_count_validation.csv']));
assert(all(querytable.original_count_agreement),'Protected count differs from independent LDL.');
assert(all(querytable.exact_count_agreement),'Exact count differs from independent LDL.');
assert(all(querytable.reliable) && all(querytable.exact_reliable), ...
    'A count has an unresolved numerical margin; do not report it as validated.');
[reason_labels,~,reason_group]=unique(querytable.reason);
reason_counts=table(reason_labels,accumarray(reason_group,1), ...
    'VariableNames',{'reason','queries'});
writetable(reason_counts,fullfile(outdir,[spec.name '_count_reasons.csv']));

% Kernel-only repeated timings (all validation and model construction excluded).
query=test(randperm(numel(test),min(cfg.kernel_shifts,numel(test))));
kernelfuns={@(d)eval_exact(s.lambda_far,s.F_far,d),@(d)eval_projection(model,d), ...
    @(d)api.eval_cheb(cheb4,d),@(d)api.eval_cheb(chebmatch,d)};
kernel_names={'exact','sp_projection','cheb4','cheb_matched'};
kernel_rows=cell(4*cfg.kernel_repeats,1); z=0;
for m=1:4, for d=query, kernelfuns{m}(d); end, end
for rep=1:cfg.kernel_repeats
    order=circshift(1:4,[0 mod(rep-1,4)]);
    for m=order
        t=tic; for d=query, kernelfuns{m}(d); end
        elapsed=toc(t); z=z+1;
        kernel_rows{z}=struct('method',kernel_names{m},'repeat',rep, ...
            'total_seconds',elapsed,'queries',numel(query),'seconds_per_query',elapsed/numel(query));
    end
end
kernel_timing=struct2table(vertcat(kernel_rows{:}));
writetable(kernel_timing,fullfile(outdir,[spec.name '_kernel_timings.csv']));

% Complete query task includes boundary assembly, one update factorization
% per k, all residuals, near assembly, small inertia, and any fallback.
% Three repetitions rotate method order; timers are instrumented equally.
timing_rows=cell(2*cfg.count_repeats,1); z=0;
for method=1:2
    update=prepare_inertia_update(s,api.boundary_T(bd,klist(1,:)));
    if method==1, protected_query(s,update,shifts(1));
    else, spaaa_inertia_count(s,update,shifts(1),[]); end
end
for rep=1:cfg.count_repeats
    order=circshift(1:2,[0 mod(rep-1,2)]);
    for method=order
        [counts,tr]=timed_count_task(api,bd,s,klist,shifts,method);
        assert(isequal(counts,references));
        tr.repeat=rep; z=z+1; timing_rows{z}=tr;
    end
end
count_timing=struct2table(vertcat(timing_rows{:}));
writetable(count_timing,fullfile(outdir,[spec.name '_complete_count_timings.csv']));

% Buffered partial spectra are checked against original-matrix LDL counts
% below the first value and in every distinguishable gap through band 12.
% Gamma/X/M use dense spectra; any failed partial check also triggers dense.
[kpath,kdist,kticks]=api.make_kpath(cfg.path_points);
bands=zeros(size(kpath,1),12); bandchecks=zeros(size(kpath,1),1);
band_diagnostic=cell(size(kpath,1),1); gamma_cache=[]; gamma_info=[];
bandclock=tic;
for j=1:size(kpath,1)
    A=A0+U*api.boundary_T(bd,kpath(j,:))*U'; A=(A+A')/2;
    high_symmetry=all(abs(sin(kpath(j,:)))<1e-13);
    if all(kpath(j,:)==0) && ~isempty(gamma_cache)
        ev=gamma_cache; bi=gamma_info; bi.method='reused_checked_Gamma';
    else
        [ev,bi]=band_reference(A,high_symmetry,12);
        if all(kpath(j,:)==0), gamma_cache=ev; gamma_info=bi; end
    end
    bands(j,:)=ev(1:12); bandchecks(j)=double(~bi.verified);
    bi.path_index=j; bi.kx=kpath(j,1); bi.ky=kpath(j,2);
    band_diagnostic{j}=bi;
    fprintf('[Scalar validation] %s bands %d/%d [%s]\n',spec.name,j,size(kpath,1),bi.method);
end
band_seconds=toc(bandclock);
band_validation=struct2table(vertcat(band_diagnostic{:}));
writetable(band_validation,fullfile(outdir,[spec.name '_band_validation.csv']));
band_columns=[{'kx','ky','path_distance'},arrayfun(@(j)sprintf('band_%d',j),1:12,'UniformOutput',false)];
writetable(array2table([kpath,kdist,bands],'VariableNames',band_columns), ...
    fullfile(outdir,[spec.name '_bands.csv']));
common_setup=assembly_seconds+spectral_seconds+partition_seconds;
sp_setup=sketch_seconds+aaa_seconds+projection_seconds;
sp_online=median(count_timing.total_seconds(strcmp(count_timing.method,'sp_protected')));
ex_online=median(count_timing.total_seconds(strcmp(count_timing.method,'exact')));
kernelmean=zeros(1,4);
for m=1:4, kernelmean(m)=mean(kernel_timing.seconds_per_query(strcmp(kernel_timing.method,kernel_names{m}))); end
row=struct('case_name',spec.name,'n',n,'r_columns',r,'nnear',sum(near), ...
    'q',numel(model.theta),'supports',numel(support),'sketch_scale',sample_scale, ...
    'max_relative_error',max(diagnostics.relative_matrix_error), ...
    'matched_cheb_degree',matched_degree,'matched_cheb_error',max(matched_errors), ...
    'count_queries',height(querytable),'accepted_fraction',mean(querytable.accepted_approximation), ...
    'fallback_count',sum(querytable.fallback),'dense_fallback_count',sum(querytable.dense_fallback), ...
    'explicit_residual_count',sum(querytable.explicit_residual), ...
    'original_count_agreement',mean(querytable.original_count_agreement), ...
    'unreliable_count',sum(~querytable.reliable), ...
    'legacy_negative_residual_count',sum(diagnostics.legacy_negative_square), ...
    'legacy_zero_indicator_count',sum(diagnostics.legacy_zero_indicator), ...
    'legacy_below_error_count',sum(diagnostics.legacy_below_matrix_error), ...
    'new_below_error_count',sum(diagnostics.new_below_matrix_error), ...
    'legacy_accept_same_model_fraction',mean(querytable.old_accept_same_model), ...
    'assembly_seconds',assembly_seconds,'spectral_seconds',spectral_seconds, ...
    'partition_seconds',partition_seconds,'sketch_seconds',sketch_seconds, ...
    'aaa_seconds',aaa_seconds,'projection_seconds',projection_seconds, ...
    'residual_setup_seconds',model.residual_setup_seconds, ...
    'cheb4_setup_seconds',cheb4_seconds,'cheb_match_search_seconds',cheb_search_seconds, ...
    'common_setup_seconds',common_setup,'sp_extra_setup_seconds',sp_setup, ...
    'kernel_exact_seconds',kernelmean(1),'kernel_sp_seconds',kernelmean(2), ...
    'kernel_cheb4_seconds',kernelmean(3),'kernel_matched_cheb_seconds',kernelmean(4), ...
    'kernel_exact_over_sp',kernelmean(1)/kernelmean(2), ...
    'complete_sp_online_median',sp_online,'complete_exact_online_median',ex_online, ...
    'sp_setup_plus_online',common_setup+sp_setup+sp_online, ...
    'exact_setup_plus_online',common_setup+ex_online, ...
    'complete_online_exact_over_sp',ex_online/sp_online, ...
    'original_ldl_reference_seconds',reference_seconds,'band_reference_seconds',band_seconds);
out=row; out.interval=interval; out.guard_interval=interval+[-pad pad];
out.far_poles=lambda(~near); out.near_poles=lambda(near);
out.support=support; out.diagnostics=diagnostics; out.count_validation=querytable;
out.kernel_timing=kernel_timing; out.complete_count_timing=count_timing;
out.meta=meta;
out.kpath=kpath; out.kdist=kdist; out.kticks=kticks; out.bands=bands; out.bandchecks=bandchecks; out.band_validation=band_validation;
end

function [count,margin,ci,ri,stage] = protected_query(s,update,d)
ri=struct('explicit_recomputed',false,'eta',Inf);
stage=struct('projection_seconds',0,'residual_seconds',0,'count_seconds',0);
dguard=100*eps(max([1;abs(d);abs(s.lambda(:))]));
hguard=100*eps(max([1;abs(d);abs(s.model.theta(:))]));
if min(abs(s.lambda-d))<=dguard || min(abs(s.model.theta-d))<=hguard
    t=tic; [count,margin,ci]=spaaa_inertia_count(s,update,d,[],Inf); stage.count_seconds=toc(t);
    ci.used_fallback=true;
    if min(abs(s.model.theta-d))<=hguard
        ci.reason=['projected pole guard; ' ci.reason];
    end
    return
end
t=tic; R=eval_projection(s.model,d); stage.projection_seconds=toc(t);
t=tic; [eta,ri]=projection_error_bound(s.model,s.lambda_far,d); stage.residual_seconds=toc(t);
ri.eta=eta;
t=tic; [count,margin,ci]=spaaa_inertia_count(s,update,d,R,eta); stage.count_seconds=toc(t);
end

function [counts,row] = timed_count_task(api,bd,s,klist,shifts,method)
counts=zeros(size(klist,1),numel(shifts));
update_seconds=0; projection_seconds=0; residual_seconds=0; count_seconds=0;
fallbacks=0; explicit=0; dense=0; accepted=0; clock=tic;
for ik=1:size(klist,1)
    t=tic; T=api.boundary_T(bd,klist(ik,:)); update=prepare_inertia_update(s,T);
    update_seconds=update_seconds+toc(t);
    for j=1:numel(shifts)
        if method==1
            [counts(ik,j),~,ci,ri,st]=protected_query(s,update,shifts(j));
            projection_seconds=projection_seconds+st.projection_seconds;
            residual_seconds=residual_seconds+st.residual_seconds;
            count_seconds=count_seconds+st.count_seconds;
            explicit=explicit+ri.explicit_recomputed;
        else
            t=tic; [counts(ik,j),~,ci]=spaaa_inertia_count(s,update,shifts(j),[]);
            count_seconds=count_seconds+toc(t);
        end
        fallbacks=fallbacks+ci.used_fallback; dense=dense+ci.used_dense;
        accepted=accepted+(ci.accepted_approximation && ~ci.used_fallback);
    end
end
elapsed=toc(clock);
names={'sp_protected','exact'};
row=struct('method',names{method},'total_seconds',elapsed, ...
    'update_and_boundary_seconds',update_seconds,'projection_seconds',projection_seconds, ...
    'residual_seconds',residual_seconds,'count_and_fallback_seconds',count_seconds, ...
    'queries',numel(counts),'accepted',accepted,'fallbacks',fallbacks, ...
    'dense_fallbacks',dense,'explicit_residuals',explicit);
end


function [ev,info]=band_reference(A,force_dense,nev)
n=size(A,1);
info=struct('method','sparse_LDL_checked','verified',false, ...
    'sparse_scaled_residual',NaN,'sparse_orthogonality_defect',NaN, ...
    'partial_check_failed',false,'ldl_checks',0);
use_dense=force_dense || n<=400;
if ~use_dense
    try
        [V,ev]=lowest_eigpairs(A,min(n-2,nev+12));
        normscale=max(1,norm(A,inf));
        info.sparse_scaled_residual=max(vecnorm(A*V-V.*ev.',2,1))/normscale;
        info.sparse_orthogonality_defect=norm(V'*V-eye(numel(ev)),'fro');
        [good,nchecks]=check_band_gaps(A,ev,nev);
        info.ldl_checks=nchecks;
        good=good && all(isfinite(ev)) && ...
            info.sparse_scaled_residual<=1e-10 && info.sparse_orthogonality_defect<=1e-7;
    catch
        good=false;
    end
    if ~good, use_dense=true; info.partial_check_failed=true; end
end
if use_dense
    ev=sort(real(eig(full(A),'vector')));
    if info.partial_check_failed, info.method='dense_after_partial_check';
    else, info.method='dense_high_symmetry_or_small'; end
    [good,nchecks]=check_band_gaps(A,ev,nev);
    info.ldl_checks=nchecks;
    assert(good,'Dense reference spectrum failed independent original-matrix LDL checks.');
end
info.verified=true;
end

function [good,nchecks]=check_band_gaps(A,ev,nev)
n=size(A,1); good=false; nchecks=0;
if numel(ev)<=nev || any(~isfinite(ev)), return; end
edge=max(1e-6*max(1,abs(ev(1))),1000*eps(max(1,norm(A,inf))));
nchecks=nchecks+1;
if ldl_count(A-(ev(1)-edge)*speye(n))~=0, return; end
for j=1:numel(ev)-1
    if ev(j+1)-ev(j)>1e-8*max(1,abs(ev(j+1)))
        threshold=.5*(ev(j)+ev(j+1));
        nchecks=nchecks+1;
        if ldl_count(A-threshold*speye(n))~=j, return; end
        if j>=nev, good=true; return; end
    end
end
end

function n=ldl_count(A)
% MATLAB sparse LDL is real symmetric; realification doubles multiplicities.
complex_case=~isreal(A);
if complex_case, A=[real(A),-imag(A);imag(A),real(A)]; end
[~,D,~]=ldl(A,'vector'); n=0; j=1;
pivot_tol=100*eps(max(1,norm(D,1)));
while j<=size(D,1)
    if j<size(D,1) && D(j+1,j)~=0
        ev=real(eig(full(D(j:j+1,j:j+1)))); j=j+2;
    else
        ev=real(D(j,j)); j=j+1;
    end
    assert(all(abs(ev)>pivot_tol),'Independent LDL has an unresolved zero pivot.');
    n=n+sum(ev<0);
end
if complex_case
    assert(mod(n,2)==0,'Realified Hermitian inertia has odd multiplicity.');
    n=n/2;
end
end
