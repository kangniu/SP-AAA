function interval=tm_ritz_interval(prob,ks,nev)
% PSD supplies the lower bound. Rayleigh--Ritz minmax supplies an upper
% bound on the nev-th eigenvalue without using reference eigenvalues.
[ax,ay]=ndgrid(-2:2,-2:2); modes=[ax(:),ay(:)];
assert(nev<=size(modes,1));
hi=0;
for p=1:size(ks,1)
    phase=prob.x*(2*pi*modes(:,1).'+ks(p,1))+prob.y*(2*pi*modes(:,2).'+ks(p,2));
    trial=sqrt(prob.eps).*exp(1i*phase); [Q,~]=qr(trial,0);
    A=prob.A0+prob.U*boundary_T(prob,ks(p,:))*prob.U'; A=(A+A')/2; H=Q'*A*Q;
    ev=sort(real(eig((H+H')/2,'vector'))); hi=max(hi,ev(nev));
end
hi=max(hi,1); interval=[-.01*hi,1.10*hi];
end

