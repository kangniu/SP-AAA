function count=original_inertia(A,d)
% MATLAB's sparse LDL supports real symmetric matrices. Realification of a
% complex Hermitian matrix duplicates every eigenvalue, including multiplicity.
complex_case=~isreal(A);
if complex_case
    A=[real(A),-imag(A);imag(A),real(A)];
end
[~,D,~]=ldl(A-d*speye(size(A,1)),'vector');
count=0; j=1; n=size(A,1);
pivot_tol=100*eps(max(1,norm(D,1)));
while j<=n
    if j<n && D(j+1,j)~=0
        ev=eig(full(D(j:j+1,j:j+1))); j=j+2;
    else
        ev=real(D(j,j)); j=j+1;
    end
    assert(all(abs(ev)>pivot_tol), ...
        'Independent LDL encountered an unresolved zero pivot.');
    count=count+sum(ev<0);
end
if complex_case
    assert(mod(count,2)==0,'Realified Hermitian inertia has odd multiplicity.');
    count=count/2;
end
end

