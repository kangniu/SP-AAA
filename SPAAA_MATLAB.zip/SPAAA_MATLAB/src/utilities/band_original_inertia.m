function count=band_original_inertia(A,d)
% Independent sparse LDL inertia, with vectorized scalar-pivot checks.
complex_case=~isreal(A);
if complex_case,A=[real(A),-imag(A);imag(A),real(A)];end
[~,D,~]=ldl(A-d*speye(size(A,1)),'vector');
v=real(diag(D));pairs=find(diag(D,-1)~=0);single=true(size(v));
single(pairs)=false;single(pairs+1)=false;
tol=100*eps(max(1,norm(D,1)));
assert(all(abs(v(single))>tol),'Independent scalar LDL pivot unresolved.');
count=sum(v(single)<0);
for i=pairs.'
 ev=eig(full(D(i:i+1,i:i+1)));assert(all(abs(ev)>tol),'Independent LDL block unresolved.');
 count=count+sum(ev<0);
end
if complex_case,assert(mod(count,2)==0);count=count/2;end
end
