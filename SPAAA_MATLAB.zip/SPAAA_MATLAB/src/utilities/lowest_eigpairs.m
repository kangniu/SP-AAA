function [V,vals] = lowest_eigpairs(A,nev)
n = size(A,1);
if n <= 400
    [V,vals] = eig(full(A),'vector');
    [vals,ord] = sort(real(vals),'ascend');
    vals = vals(1:nev);
    V = V(:,ord(1:nev));
else
    opts.isreal = false; opts.tol = 1e-10; opts.maxit = 4000;
    nrequest = min(n-2,nev+4);
    opts.p = min(n,max(40,4*nrequest));
    [V,D] = eigs(A,nrequest,'smallestreal',opts);
    [vals,ord] = sort(real(diag(D)),'ascend');
    vals = vals(1:nev);
    V = V(:,ord(1:nev));
end
end


