function [path,ticks] = make_kpath(vertices,nseg)
path = [];
ticks = 1;
for j = 1:size(vertices,1)-1
    t = linspace(0,1,nseg+1).';
    seg = (1-t).*vertices(j,:)+t.*vertices(j+1,:);
    if j>1, seg=seg(2:end,:); end
    path=[path;seg]; %#ok<AGROW>
    ticks(end+1)=size(path,1); %#ok<AGROW>
end
end


