function kpoints = benchmark_kpoints()
kpoints = pi*[0.17 0.11; 0.63 0.27; 0.82 0.74];
end


