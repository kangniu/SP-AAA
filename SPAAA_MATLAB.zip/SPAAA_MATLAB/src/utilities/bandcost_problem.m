function [A0,U,b,V]=bandcost_problem(Nx,Ny,Lx)
% Bloch periodic longitudinal direction, transverse homogeneous Dirichlet.
hx=Lx/Nx;hy=1/(Ny+1);[x,y]=ndgrid((0:Nx-1)*hx,(1:Ny)*hy);
V=2.5*cos(2*pi*x).*cos(pi*y);
for cell=0:Lx-1
 centers=[.20,.30;.45,.70;.70,.32;.88,.68];
 for j=1:4
  dx=abs(x-(cell+centers(j,1)));dx=min(dx,Lx-dx);
  strength=45*(1+.08*j)*(1+.12*cos(2*pi*(cell+.3)/Lx));
  V(dx.^2+(y-centers(j,2)).^2<=.085^2)=V(dx.^2+(y-centers(j,2)).^2<=.085^2)-strength;
 end
end
ex=ones(Nx,1);ey=ones(Ny,1);
Lxx=spdiags([-ex 2*ex -ex],-1:1,Nx,Nx)/hx^2;
Lyy=spdiags([-ey 2*ey -ey],-1:1,Ny,Ny)/hy^2;
A0=.45*(kron(speye(Ny),Lxx)+kron(Lyy,speye(Nx)))+spdiags(V(:),0,Nx*Ny,Nx*Ny);
ix=[sub2ind([Nx Ny],ones(Ny,1),(1:Ny)');sub2ind([Nx Ny],Nx*ones(Ny,1),(1:Ny)')];
U=sparse(ix,1:2*Ny,1,Nx*Ny,2*Ny);
b=struct('Nx',Nx,'Ny',Ny,'Lx',Lx,'hx',hx,'hy',hy,'coupling',-.45/hx^2);
end
