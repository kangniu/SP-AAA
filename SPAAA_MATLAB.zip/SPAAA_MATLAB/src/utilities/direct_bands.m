function bands = direct_bands(prob,kpath,nev)
bands = zeros(nev,size(kpath,1));
for j = 1:size(kpath,1)
    Ak = prob.A0+prob.U*boundary_T(prob,kpath(j,:))*prob.U';
    bands(:,j) = lowest_eigs(Ak,nev);
end
end


