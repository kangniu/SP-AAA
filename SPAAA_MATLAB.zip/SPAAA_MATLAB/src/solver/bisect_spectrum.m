function [vals,nqueries,nfallback] = bisect_spectrum(varargin)
% Compatibility entry point; update decomposition is cached per call.
[vals,nqueries,nfallback] = spaaa_bisect_spectrum(varargin{:});
end
