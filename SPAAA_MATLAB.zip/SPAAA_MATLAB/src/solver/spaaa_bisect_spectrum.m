function [vals,nqueries,nfallback] = spaaa_bisect_spectrum(s,T,brackets,nev,tol,method)
% Cache the update decomposition once per k, outside all bisection loops.
if isstruct(T) && isfield(T,'is_inertia_update')
    update = T;
else
    update = prepare_inertia_update(s,T);
end
vals = zeros(nev,1); nqueries = 0; nfallback = 0;
for j = 1:nev
    lo = brackets(j,1); hi = brackets(j,2); probe = 1;
    while hi-lo > tol*max(1,abs(hi)+abs(lo))
        fractions = [.5 .25 .75 .375 .625 .125 .875];
        if probe > numel(fractions)
            error('SPAAA:UnresolvedBracket','No reliable interior count; bracket is unchanged.');
        end
        d = lo + fractions(probe)*(hi-lo);
        diagonal_tol = 100*eps(max([1;abs(d);abs(s.lambda(:))]));
        if min(abs(s.lambda-d)) <= diagonal_tol
            [cnt,~,info] = inertia_count(s,update,d,[]);
        elseif method == 1
            pole_scale = max([1;abs(d);abs(s.model.theta(:))]);
            if min(abs(s.model.theta-d)) <= 100*eps(pole_scale)
                [cnt,~,info] = inertia_count(s,update,d,[],Inf);
                info.used_fallback = true;
            else
                R = eval_projection(s.model,d);
                eta = projection_error_bound(s.model,s.lambda_far,d);
                [cnt,~,info] = inertia_count(s,update,d,R,eta);
            end
        elseif method == 2
            R = eval_cheb(s.cheb,d);
            % The Chebyshev baseline supplies no resolvent error bound.
            [cnt,~,info] = inertia_count(s,update,d,R);
        else
            [cnt,~,info] = inertia_count(s,update,d,[]);
        end
        nfallback = nfallback+double(info.used_fallback);
        nqueries = nqueries+1;
        if ~info.reliable, probe = probe+1; continue; end
        probe = 1;
        if cnt >= j, hi = d; else, lo = d; end
    end
    vals(j) = 0.5*(lo+hi);
end
end

