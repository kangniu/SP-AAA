function update = prepare_inertia_update(s,T,opts)
% Cache one Hermitian update for repeated shift queries.
% Default: retain every nonzero eigenvalue of T. A positive rank_tol requests
% numerical truncation; inertia_count then checks the original matrix using
% two displaced effective counts, or falls back to the original matrix.
% These are floating-point numerical checks, not validated certification.
if nargin < 3, opts = struct(); end
if ~isfield(opts,'rank_tol'), opts.rank_tol = 0; end
validateattributes(opts.rank_tol,{'numeric'},{'scalar','real','finite','nonnegative'});
if isfield(s,'F')
    lambda = s.lambda(:); F = s.F;
else
    lambda = [s.lambda_near(:);s.lambda_far(:)];
    F = [s.F_near;s.F_far];
end
T = full((T+T')/2);
[Z,tau] = eig(T,'vector'); tau = real(tau);
keep = abs(tau) > opts.rank_tol;
Q = Z(:,keep).*sqrt(abs(tau(keep))).';
signs = sign(tau(keep));
discard = ~keep & tau ~= 0;
if any(discard)
    discarded_factor = (F*Z(:,discard)).*sqrt(abs(tau(discard))).';
    % Frobenius norm upper-bounds the discarded update's spectral norm.
    eta_T = norm(discarded_factor,'fro')^2;
    eta_T = eta_T*(1+64*eps*max(1,numel(lambda)));
else
    eta_T = 0;
end
if isempty(signs), error_scale = 0; else, error_scale = max(abs(tau(keep))); end
update = struct('is_inertia_update',true,'T',T,'lambda',lambda,'F',F, ...
    'Q',Q,'signs',signs,'B',F*Q,'Bnear',s.F_near*Q, ...
    'lambda_near',s.lambda_near(:),'positive_signs',sum(signs>0), ...
    'error_scale',error_scale,'eta_T',eta_T,'has_truncation',any(discard), ...
    'rank_tol',opts.rank_tol,'retained_rank',sum(keep),'discarded_rank',sum(discard));
end
