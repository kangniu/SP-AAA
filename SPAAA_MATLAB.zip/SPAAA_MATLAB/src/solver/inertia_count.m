function [count,margin,info] = inertia_count(varargin)
% Compatibility entry point. See spaaa_inertia_count for the query contract.
[count,margin,info] = spaaa_inertia_count(varargin{:});
end
