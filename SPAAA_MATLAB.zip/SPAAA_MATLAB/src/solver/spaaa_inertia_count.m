function [count,margin,info] = spaaa_inertia_count(s,T,d,Rfar,farError)
% Numerically checked count of eigenvalues of A below d.
% T may be prepare_inertia_update's cache, reused for every shift.
% A supplied Rfar is assumed exact unless its norm-error estimate farError
% is also supplied. Supply farError when Rfar is approximate.
% Rfar=[] requests an exact resolvent (or a dense diagonal-pole fallback).
% margin is in Rfar error units. All checks use ordinary floating point.
has_error_estimate = nargin >= 5;
if nargin < 4, Rfar = []; end
if nargin < 5, farError = 0; end
if isstruct(T) && isfield(T,'is_inertia_update')
    update = T;
else
    update = prepare_inertia_update(s,T);
end
info = struct('used_fallback',false,'used_dense',false, ...
    'used_exact_far',false,'accepted_approximation',false, ...
    'truncation_verified',~update.has_truncation,'reason','', ...
    'eta_T',update.eta_T,'shifted_counts',[NaN NaN], ...
    'evaluated_shifts',[NaN NaN],'reliable',false);

if update.has_truncation
    % Weyl: N_eff(d-eta_T) <= N_A(d) <= N_eff(d+eta_T).
    % Reevaluate the resolvent at both shifted thresholds.
    shifts = [d-update.eta_T,d+update.eta_T];
    info.evaluated_shifts = shifts;
    if update.eta_T > 0 && shifts(1) < d && shifts(2) > d
        [left,ml,okl,densel] = exact_effective_count(update,shifts(1));
        [right,mr,okr,denser] = exact_effective_count(update,shifts(2));
        info.shifted_counts = [left right];
        info.used_exact_far = true;
        info.used_dense = densel || denser;
        if okl && okr && left == right
            count = left; margin = min(ml,mr);
            info.truncation_verified = true;
            info.used_fallback = true; info.reliable = true;
            info.reason = 'equal reliable displaced effective counts';
            return
        end
    end
    [count,margin,info.reliable] = dense_count(update,d,false);
    info.used_fallback = true; info.used_dense = true;
    info.reason = 'truncation enclosure inconclusive; original matrix';
    return
end

if isempty(update.signs)
    count = sum(update.lambda < d); margin = Inf;
    info.reliable = ~is_diagonal_pole(update.lambda,d);
    info.reason = 'zero update'; return
end
if is_diagonal_pole(update.lambda,d)
    [count,margin,info.reliable] = dense_count(update,d,false);
    info.used_fallback = true; info.used_dense = true;
    info.reason = 'original diagonal pole; original matrix'; return
end

if ~isempty(Rfar) && isscalar(farError) && isfinite(farError) && farError >= 0 ...
        && all(isfinite(Rfar(:)))
    Rnear = update.Bnear'*(update.Bnear./(update.lambda_near-d));
    K = diag(update.signs)+Rnear+update.Q'*Rfar*update.Q;
    [count,margin,reliable] = small_count(update,K,d);
    if reliable && farError < margin
        info.reliable = true;
        info.accepted_approximation = has_error_estimate;
        info.reason = 'far-field error below numerical inertia margin';
        return
    end
    info.used_fallback = true;
elseif ~isempty(Rfar)
    info.used_fallback = true;
end

[count,margin,reliable,dense] = exact_effective_count(update,d);
info.used_exact_far = true; info.used_dense = dense;
info.used_fallback = info.used_fallback || dense; info.reliable = reliable;
info.reason = 'exact resolvent';
if dense, info.reason = 'unresolved numerical inertia margin; original matrix'; end
end

function [count,margin,reliable,used_dense] = exact_effective_count(update,d)
used_dense = false;
if isempty(update.signs)
    count = sum(update.lambda<d); margin = Inf;
    reliable = ~is_diagonal_pole(update.lambda,d); return
end
if is_diagonal_pole(update.lambda,d)
    [count,margin,reliable] = dense_count(update,d,update.has_truncation);
    used_dense = true; return
end
K = diag(update.signs)+update.B'*(update.B./(update.lambda-d));
[count,margin,reliable] = small_count(update,K,d);
if ~reliable
    [count,margin,reliable] = dense_count(update,d,update.has_truncation);
    used_dense = true;
end
end

function [count,margin,reliable] = small_count(update,K,d)
K = (K+K')/2;
if any(~isfinite(K(:)))
    count = NaN; margin = 0; reliable = false; return
end
ev = real(eig(K,'vector'));
count = sum(update.lambda<d)+sum(ev>0)-update.positive_signs;
% Heuristic arithmetic margin, not a validated rounding-error enclosure.
roundoff = 64*eps*max(1,numel(ev))*max(1,norm(K,'fro'));
gap = min(abs(ev))-roundoff;
margin = max(0,gap)/update.error_scale;
reliable = gap > 0 && count >= 0 && count <= numel(update.lambda);
end

function tf = is_diagonal_pole(lambda,d)
scale = max([1;abs(d);abs(lambda(:))]);
tf = any(abs(lambda-d) <= 100*eps(scale));
end

function [count,margin,reliable] = dense_count(update,d,effective)
if effective
    A = diag(update.lambda)+(update.B.*update.signs.')*update.B';
else
    A = diag(update.lambda)+update.F*update.T*update.F';
end
A = (A+A')/2;
ev = real(eig(A-d*eye(numel(update.lambda)),'vector'));
count = sum(ev<0); margin = min(abs(ev));
threshold = 64*eps*max(1,numel(ev))*max([1,norm(A,'fro'),abs(d)]);
reliable = margin > threshold;
end

