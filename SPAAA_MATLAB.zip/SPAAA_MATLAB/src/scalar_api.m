function api=scalar_api
api=struct('build_problem',@build_problem,'boundary_T',@boundary_T,'make_kpath',@make_kpath,'build_cheb_model',@build_cheb_model,'eval_cheb',@eval_cheb);
end
function [A0,U,boundary,meta] = build_problem(spec)
N = spec.N;
h = 1/N;
[x,y] = ndgrid((0:N-1)/N,(0:N-1)/N);
switch spec.kind
    case 'defect'
        potential = zeros(N);
        nc = spec.cells;
        for ix = 0:nc-1
            for iy = 0:nc-1
                if ix == floor(nc/2) && iy == floor(nc/2), continue; end
                cx = (ix+.5)/nc; cy = (iy+.5)/nc;
                rr = spec.radius/nc;
                potential((x-cx).^2+(y-cy).^2 <= rr^2) = -spec.contrast;
            end
        end
        kinetic = 0.55;
    case 'electronic'
        potential = spec.contrast*(cos(2*pi*x).*cos(2*pi*y) + ...
            .22*cos(4*pi*x+0.3).*cos(2*pi*y));
        kinetic = 0.35;
    case 'largecell'
        potential = zeros(N);
        nc = spec.cells;
        for ix = 0:nc-1
            for iy = 0:nc-1
                cx = (ix+.5)/nc; cy = (iy+.5)/nc;
                rr = spec.radius/nc;
                amp = -spec.contrast*(1+0.12*cos(pi*(ix+iy)));
                potential((x-cx).^2+(y-cy).^2 <= rr^2) = amp;
            end
        end
        potential = potential + 3*cos(2*pi*x).*cos(2*pi*y);
        kinetic = 0.45;
end

e = ones(N,1);
L1 = spdiags([-e 2*e -e],-1:1,N,N);
L1(1,N)=0; L1(N,1)=0;
A0 = kinetic*(kron(speye(N),L1)+kron(L1,speye(N)))/h^2 + ...
    spdiags(potential(:),0,N^2,N^2);

% Columns of U are boundary degrees of freedom. T contains x and y wrap
% couplings in four off-diagonal N-by-N blocks.
left = sub2ind([N,N],ones(N,1),(1:N)');
right = sub2ind([N,N],N*ones(N,1),(1:N)');
bottom = sub2ind([N,N],(1:N)',ones(N,1));
top = sub2ind([N,N],(1:N)',N*ones(N,1));
idx = [left;right;bottom;top];
U = sparse(idx,1:numel(idx),1,N^2,numel(idx));
boundary.N = N;
boundary.cx = -kinetic/h^2;
boundary.cy = -kinetic/h^2;
meta.potential_min = min(potential,[],'all');
meta.potential_max = max(potential,[],'all');
end


function T = boundary_T(boundary,k)
N = boundary.N;
Z = sparse(N,N);
Tx = boundary.cx*exp(-1i*k(1))*speye(N);
Ty = boundary.cy*exp(-1i*k(2))*speye(N);
T = [Z Tx Z Z; Tx' Z Z Z; Z Z Z Ty; Z Z Ty' Z];
end


function R = eval_exact(lambda,F,d)
R = F'*(F./(lambda-d));
R = (R+R')/2;
end


function model = build_cheb_model(lambda,F,interval,p)
% Matrix-valued Chebyshev interpolation at p first-kind nodes.
j = (1:p)';
x = cos((2*j-1)*pi/(2*p));
d = (interval(1)+interval(2))/2 + (interval(2)-interval(1))/2*x;
r = size(F,2);
vals = zeros(r,r,p);
for k = 1:p
    vals(:,:,k)=eval_exact(lambda,F,d(k));
end
coef = zeros(r,r,p);
for ell = 0:p-1
    w = (2/p)*cos(ell*(2*j-1)*pi/(2*p));
    if ell==0, w=w/2; end
    for k = 1:p
        coef(:,:,ell+1)=coef(:,:,ell+1)+w(k)*vals(:,:,k);
    end
end
model.coef=coef;
model.interval=interval;
end


function R = eval_cheb(model,d)
x = (2*d-sum(model.interval))/diff(model.interval);
p = size(model.coef,3);
b1 = zeros(size(model.coef,1));
b2 = b1;
for k = p:-1:2
    b0 = 2*x*b1-b2+model.coef(:,:,k);
    b2=b1; b1=b0;
end
R = x*b1-b2+model.coef(:,:,1);
R=(R+R')/2;
end


function [k,kdist,ticks] = make_kpath(points)
points=max(5,round(points));
nodes=[0 0; pi 0; pi pi; 0 0];
k=[];
ticks=zeros(1,4);
dist=0;
kdist=[];
for s=1:3
    t=linspace(0,1,points+1)';
    if s>1, t=t(2:end); end
    seg=(1-t).*nodes(s,:)+t.*nodes(s+1,:);
    if isempty(k)
        ds=[0;cumsum(vecnorm(diff(seg),2,2))];
    else
        ds=dist+cumsum(vecnorm(diff([k(end,:);seg]),2,2));
    end
    k=[k;seg]; %#ok<AGROW>
    kdist=[kdist;ds]; %#ok<AGROW>
    dist=kdist(end);
    ticks(s+1)=dist;
end
end

