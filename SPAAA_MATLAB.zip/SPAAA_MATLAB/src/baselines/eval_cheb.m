function R = eval_cheb(cheb,d)
R = eval_cheb_coeff(cheb.coeff,cheb.interval,d);
end


