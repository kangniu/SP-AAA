function coeff = cheb_coefficients(lambda,F,interval,degree)
theta = pi*((1:degree+1)-0.5)/(degree+1);
x = cos(theta);
z = 0.5*(interval(1)+interval(2))+0.5*(interval(2)-interval(1))*x;
samples = cell(degree+1,1);
for j = 1:degree+1, samples{j}=eval_exact(lambda,F,z(j)); end
coeff = cell(degree+1,1);
for k = 0:degree
    C = zeros(size(samples{1}));
    for j = 1:degree+1, C=C+samples{j}*cos(k*theta(j)); end
    C=2*C/(degree+1);
    if k==0, C=C/2; end
    coeff{k+1}=C;
end
end


