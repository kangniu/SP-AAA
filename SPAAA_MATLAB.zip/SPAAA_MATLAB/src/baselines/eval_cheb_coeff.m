function R = eval_cheb_coeff(coeff,interval,d)
x = (2*d-sum(interval))/(interval(2)-interval(1));
b1 = zeros(size(coeff{1})); b2=b1;
for k = numel(coeff):-1:2
    b0=2*x*b1-b2+coeff{k}; b2=b1; b1=b0;
end
R=x*b1-b2+coeff{1}; R=(R+R')/2;
end


