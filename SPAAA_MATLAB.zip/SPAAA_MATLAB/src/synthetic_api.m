function api=synthetic_api
api=struct('evaluate_case',@evaluate_case,'threshold_minima',@threshold_minima);
end
function [rows,details]=evaluate_case(spec,seed,cutoff,cfg,confirm)
rng(seed,'twister');
n=spec.n; r=spec.r;
t=((0:n-1)'+.5+.2*(rand(n,1)-.5))/n;
if spec.easy, delta=2+t; else, delta=spec.g*exp(t*log(spec.L/spec.g)); end
delta(1)=spec.g; delta(end)=spec.L;
lambda=1+delta;
if strcmp(spec.weight,'endpoint_balanced'), weights=delta/n; else, weights=ones(n,1)/n; end
directions=zeros(n,r);
for i=1:n
    if spec.family==1
        slot=1+mod(i-1,r); direction=zeros(1,r); direction(slot)=1;
    else
        angle=2*pi*t(i);
        slot=1+min(r-1,floor(t(i)*r)); next=1+mod(slot,r);
        direction=zeros(1,r); direction(slot)=1; direction(next)=.5*sin(angle)+.45;
    end
    direction=direction+.04*randn(1,r);
    directions(i,:)=direction/norm(direction);
end
F=sqrt(weights).*directions;
train=unique([0 1 (1-cos(linspace(0,pi,129)))/2, ...
    1-logspace(log10(min(spec.g/16,.1)),0,65)]);
if confirm, nu=1201; nl=769; nr=128; else, nu=401; nl=257; nr=64; end
rng(seed+20000,'twister');
valid=unique([0 1 linspace(0,1,nu), ...
    1-logspace(log10(min(spec.g/64,.025)),0,nl),rand(1,nr)]);
train_values=zeros(r*r,numel(train));
train_exact=cell(1,numel(train));
for j=1:numel(train)
    R=eval_exact(lambda,F,train(j)); train_exact{j}=R;
    train_values(:,j)=R(:);
end
global_scale=max(vecnorm(train_values,2,1));
full_samples=train_values/max(global_scale,realmin);
methods={'aaa_full','cheb_lobatto','uniform'}; Omega=[]; sketch_scale=NaN;
if confirm
    methods={'aaa_full','aaa_sketch','cheb_lobatto','uniform'};
    rng(seed+10000,'twister'); [Omega,~]=qr(randn(r,r/2),0);
    sketch_samples=zeros((r/2)^2,numel(train));
    for j=1:numel(train), G=Omega'*train_exact{j}*Omega; sketch_samples(:,j)=G(:); end
    sketch_scale=max(vecnorm(sketch_samples,2,1));
    sketch_samples=sketch_samples/max(sketch_scale,realmin);
end
references=cell(1,numel(valid)); refnorm=zeros(numel(valid),1);
for j=1:numel(valid)
    references{j}=eval_exact(lambda,F,valid(j)); refnorm(j)=norm(references{j},2);
end
rows=struct([]); models=cell(numel(methods),numel(cfg.budgets));
for a=1:numel(methods)
    method=methods{a};
    for b=1:numel(cfg.budgets)
        m=cfg.budgets(b); support=[]; q=NaN; failure='';
        errors=inf(numel(valid),1); abs_errors=errors; selection_seconds=NaN; build_seconds=NaN;
        interval_poles=NaN;
        try
            clock=tic;
            switch method
                case 'aaa_full'
                    support=setvalued_aaa_support(train,full_samples,cfg.aaa_tol,m);
                case 'aaa_sketch'
                    support=setvalued_aaa_support(train,sketch_samples,cfg.aaa_tol,m);
                case 'cheb_lobatto'
                    support=(1-cos(linspace(0,pi,m)))/2;
                case 'uniform'
                    support=linspace(0,1,m);
            end
            selection_seconds=toc(clock);
            clock=tic; model=build_projection_model(lambda,F,support,cutoff); build_seconds=toc(clock);
            q=numel(model.theta); interval_poles=sum(model.theta>=0 & model.theta<=1);
            assert(interval_poles==0,'One-sided projection unexpectedly has an interval Ritz pole.');
            for j=1:numel(valid)
                approximation=eval_projection(model,valid(j));
                abs_errors(j)=norm(references{j}-approximation,2);
                errors(j)=abs_errors(j)/max(refnorm(j),realmin);
            end
            assert(all(isfinite(errors)),'Nonfinite full matrix validation error.');
        catch exception
            failure=[exception.identifier ': ' exception.message];
        end
        row=struct('case_id',spec.id,'family',spec.family,'n',n,'r',r,'g',spec.g,'L',spec.L, ...
            'weight',spec.weight,'easy',spec.easy,'seed',seed,'svd_tol',cutoff, ...
            'phase',char_phase(confirm),'method',method,'requested_m',m,'actual_m',numel(support), ...
            'q',q,'max_relative_error',max(errors),'max_absolute_error',max(abs_errors), ...
            'max_global_relative_error',max(abs_errors)/max(refnorm), ...
            'interval_ritz_poles',interval_poles,'failure',failure, ...
            'selection_seconds_exploratory',selection_seconds,'build_seconds_exploratory',build_seconds);
        rows=append_rows(rows,row);
        models{a,b}=struct('method',method,'requested_m',m,'support',support,'q',q, ...
            'relative_error',errors,'absolute_error',abs_errors,'failure',failure);
    end
end
details=struct('spec',spec,'seed',seed,'sketch_seed',seed+10000,'svd_tol',cutoff, ...
    'lambda',lambda,'F',F,'interval',cfg.interval,'Omega',Omega, ...
    'full_global_scale',global_scale,'sketch_global_scale',sketch_scale, ...
    'train_grid',train,'validation_grid',valid,'validation_reference_norm',refnorm, ...
    'sample_recipe','full R or Omega'' R Omega; one global scalar normalization', ...
    'models',{models},'rows',rows);
end

function mins=threshold_minima(rows,thresholds)
mins=struct([]); methods=unique({rows.method},'stable');
for a=1:numel(methods)
    subset=rows(strcmp({rows.method},methods{a}));
    for tolerance=thresholds
        good=arrayfun(@(x)isempty(x.failure) && x.max_relative_error<=tolerance,subset);
        best_m=Inf; best_q=Inf; request=NaN; attained=false;
        if any(good)
            choices=subset(good);
            [~,order]=sortrows([[choices.actual_m]',[choices.q]',[choices.requested_m]'],[1 2 3]);
            winner=choices(order(1));
            best_m=winner.actual_m; best_q=winner.q; request=winner.requested_m; attained=true;
        end
        first=subset(1);
        row=struct('case_id',first.case_id,'family',first.family,'n',first.n,'r',first.r, ...
            'g',first.g,'L',first.L,'weight',first.weight,'easy',first.easy, ...
            'seed',first.seed,'svd_tol',first.svd_tol,'phase',first.phase, ...
            'method',methods{a},'tolerance',tolerance,'attained',attained, ...
            'minimum_actual_m',best_m,'q_at_minimum_m',best_q,'requested_budget_at_minimum',request);
        mins=append_rows(mins,row);
    end
end
end

function ranked=rank_candidates(cases,minima)
ranked=struct([]);
for c=1:numel(cases)
    subset=minima(strcmp({minima.case_id},cases(c).id) & [minima.tolerance]==1e-8);
    a=subset(strcmp({subset.method},'aaa_full'));
    if ~a.attained, continue; end
    simple=subset(~strcmp({subset.method},'aaa_full'));
    [~,simple_order]=sortrows([[simple.minimum_actual_m]',[simple.q_at_minimum_m]'],[1 2]);
    idx=simple_order(1); simple_m=simple(idx).minimum_actual_m;
    simple_q=simple(idx).q_at_minimum_m; censored=~isfinite(simple_m);
    rank_m=simple_m; if censored, rank_m=14; end
    row=struct('case_id',cases(c).id,'aaa_m',a.minimum_actual_m,'aaa_q',a.q_at_minimum_m, ...
        'best_simple_m',simple_m,'best_simple_q',simple_q, ...
        'best_simple_method',simple(idx).method,'simple_censored',censored, ...
        'm_advantage',rank_m/a.minimum_actual_m,'q_advantage',simple_q/a.q_at_minimum_m);
    ranked=append_rows(ranked,row);
end
if ~isempty(ranked)
    [~,order]=sortrows(-[[ranked.m_advantage]',[ranked.q_advantage]'],[1 2]);
    ranked=ranked(order);
end
end

function out=append_rows(out,rows)
if isempty(out), out=rows; else, out=[out,rows]; end
end
function p=char_phase(confirm)
if confirm, p='confirmation'; else, p='screen'; end
end
