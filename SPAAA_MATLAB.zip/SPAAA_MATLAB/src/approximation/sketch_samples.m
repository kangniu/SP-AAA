function sketches = sketch_samples(lambda,F,z,m)
r = size(F,2); m=min(m,r);
if isreal(F), Omega=randn(r,m); else, Omega=randn(r,m)+1i*randn(r,m); end
[Omega,~]=qr(Omega,0);
FOmega=F*Omega;
sketches = zeros(m*m,numel(z));
for j = 1:numel(z)
    G = FOmega'*(FOmega./(lambda-z(j)));
    sketches(:,j) = G(:);
end
end


