function R = eval_exact(lambda,F,d)
R = F' * ((1./(lambda-d)).*F);
R = (R+R')/2;
end


