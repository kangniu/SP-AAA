function support = setvalued_aaa_support(z,Y,tol,max_support)
ns = numel(z);
support_idx = round(ns/2);
for m = 1:max_support
    mask = true(1,ns); mask(support_idx)=false;
    idx = find(mask);
    C = 1./(z(idx).'-z(support_idx));
    A = zeros(size(Y,1)*numel(idx),numel(support_idx));
    for j = 1:numel(idx)
        A((j-1)*size(Y,1)+(1:size(Y,1)),:) = ...
            C(j,:).*(Y(:,idx(j))-Y(:,support_idx));
    end
    [~,~,V] = svd(A,0); w = V(:,end);
    approx = bary_eval(z,Y(:,support_idx),z(support_idx),w);
    err = vecnorm(Y-approx,2,1);
    err(support_idx)=0;
    if max(err) <= tol*max(1,max(vecnorm(Y,2,1))), break; end
    if numel(support_idx) >= max_support, break; end
    [~,newidx] = max(err);
    support_idx(end+1)=newidx; %#ok<AGROW>
end
support = z(support_idx);
end


