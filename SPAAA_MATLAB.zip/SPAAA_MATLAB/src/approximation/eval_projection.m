function R = eval_projection(model,d)
R = model.C'*(model.C./(model.theta-d));
R = (R+R')/2;
end


