function model = build_projection_model(lambda,F,support,tol)
if nargin < 4 || isempty(tol), tol = 1e-10; end
validateattributes(tol,{'numeric'},{'scalar','real','finite','positive','<=',1});
lambda = lambda(:);
n = numel(lambda);
W = zeros(n,size(F,2)*numel(support));
for j = 1:numel(support)
    cols = (j-1)*size(F,2)+(1:size(F,2));
    W(:,cols) = (1./(lambda-support(j))).*F;
end
[V,S,~] = svd(W,'econ');
sigma = diag(S);
q = find(sigma >= tol*sigma(1),1,'last');
V = V(:,1:q);
H = V'*(lambda.*V);
H = (H+H')/2;
B = V'*F;
[Uh,theta] = eig(H,'vector');
[theta,ord] = sort(real(theta),'ascend');
Uh = Uh(:,ord);
G = V'*(lambda.*F);
K2 = V'*((lambda.^2).*V);
model = struct('V',V,'H',H,'B',B,'theta',theta,'Uh',Uh, ...
    'C',Uh'*B,'Gs',Uh'*G,'K2s',Uh'*K2*Uh, ...
    'normF2',norm(F,2),'normFro2',norm(F,'fro')^2,'support',support);
% Offline residual compression; include this work in setup timings.
tres = tic;
VB = V*B; DV = lambda.*V; VH = V*H;
[~,model.residual_factor] = qr([F-VB, DV-VH],0);
model.residual_scale = [norm(F,'fro')+norm(VB,'fro'), ...
    norm(DV,'fro')+norm(VH,'fro')];
model.normV2 = norm(V,2);
model.F = F;
model.residual_setup_seconds = toc(tres);
end


