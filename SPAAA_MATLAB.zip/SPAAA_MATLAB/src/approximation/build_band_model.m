function model=build_band_model(lambda,F,support,cutoff,with_residual)
% Galerkin model with residual compression in the eigenbasis of H.
if nargin<5,with_residual=true;end
W=zeros(numel(lambda),size(F,2)*numel(support));
for j=1:numel(support),W(:,(j-1)*size(F,2)+(1:size(F,2)))=F./(lambda-support(j));end
[V,S,~]=svd(W,'econ');sv=diag(S);q=find(sv>=cutoff*sv(1),1,'last');V=V(:,1:q);
H=V'*(lambda.*V);H=(H+H')/2;
[Q,theta]=eig(H,'vector');[theta,ix]=sort(real(theta));V=V*Q(:,ix);
C=V'*F;
model=struct('V',V,'theta',theta,'C',C,'support',support);
if ~with_residual,return;end
VC=V*C;DV=lambda.*V;VT=V.*theta.';
[~,Rf]=qr([F-VC,DV-VT],0);
model=struct('V',V,'theta',theta,'C',C,'R0',Rf(:,1:size(F,2)), ...
 'R1',Rf(:,size(F,2)+1:end),'scale0',norm(F,'fro')+norm(VC,'fro'), ...
 'scale1',norm(DV,'fro')+norm(VT,'fro'),'normF',norm(F,2), ...
 'normV',norm(V,2),'F',F,'support',support);
% Galerkin defects and numerical rounding allowances for the quadratic bound.
model.coupling_defect=64*eps*model.normV*norm(F,'fro');
model.operator_defect=norm(V'*DV-diag(theta),2)+64*eps*model.normV*norm(DV,'fro');
model.orth_defect=norm(V'*V-eye(q),2)+64*eps*model.normV^2;
end
