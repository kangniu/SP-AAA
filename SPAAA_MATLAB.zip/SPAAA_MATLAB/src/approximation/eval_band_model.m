function [R,eta,explicit]=eval_band_model(m,lambda,d)
% Evaluate the projected resolvent and quadratic residual bound.
% Recompute residuals near rounding precision.
explicit=false;R=[];eta=Inf;
if min(abs(m.theta-d))<=100*eps(max([1;abs(d);abs(m.theta)])),return;end
sep=min(abs(lambda-d));if sep<=0,return;end
Z=m.C./(m.theta-d);R=m.C'*Z;R=(R+R')/2;
diagres=norm(m.C-(m.theta-d).*Z,'fro');
res=norm(m.R0-m.R1*Z,'fro')+m.normV*diagres;
allowance=64*eps*(m.scale0+m.scale1*norm(Z,'fro')+m.normV*diagres);
if ~isfinite(res)||res<=allowance
 P=(lambda-d).*(m.V*Z);res=norm(m.F-P,'fro');
 allowance=64*eps*(norm(m.F,'fro')+norm(P,'fro'));explicit=true;
end
% For an exact reduced solve, in exact arithmetic:
% R-Rtilde=E'*(D-dI)^(-1)*E + DeltaC'*Z+Z'*DeltaC - Z'*(DeltaH-d*DeltaG)*Z.
% The computed bound also includes the reduced-solve residual.
nz=norm(Z,'fro');
eta=(res+allowance)^2/sep+2*m.coupling_defect*nz ...
 +(m.operator_defect+abs(d)*m.orth_defect)*nz^2+nz*diagres ...
 +64*eps*norm(R,'fro');
end
