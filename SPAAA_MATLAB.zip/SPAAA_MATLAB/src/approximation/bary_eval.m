function Yq = bary_eval(z,Ys,support,w)
Yq = zeros(size(Ys,1),numel(z));
for j = 1:numel(z)
    hit = find(abs(z(j)-support)<10*eps(max(1,abs(z(j)))),1);
    if ~isempty(hit)
        Yq(:,j)=Ys(:,hit);
    else
        c = w./(z(j)-support).';
        Yq(:,j)=Ys*c/sum(c);
    end
end
end


