function [eta,info] = projection_error_bound(model,lambda,d,compute_legacy)
%PROJECTION_ERROR_BOUND Residual-based error indicator.
% Compress [F-V*B, D*V-V*H] by QR and include the reduced-solve residual.
% Recompute F-(D-d)*V*Y near rounding precision. The rounding allowance
% is numerical, not a validated floating-point bound.
if nargin < 4, compute_legacy = false; end
t0 = tic;
info = struct('method','unavailable','residual_norm',Inf, ...
    'explicit_recomputed',false,'used_explicit',false,'cancellation_suspected',false, ...
    'separation',min(abs(lambda-d)),'roundoff_allowance',Inf, ...
    'raw_residual_squared',NaN,'residual_seconds',0);
eta = Inf;
delta = info.separation;
if isempty(delta) || ~isfinite(delta) || delta <= 0 || ...
        any(~isfinite(model.theta)) || any(model.theta == d)
    info.method = 'pole';
    info.residual_seconds = toc(t0);
    return
end
if isfield(model,'Uh')
    Y = model.Uh*(model.C./(model.theta-d));
else
    Y = (model.H-d*eye(size(model.H)))\model.B;
end
if any(~isfinite(Y(:)))
    info.method = 'pole';
    info.residual_seconds = toc(t0);
    return
end
has_source = isfield(model,'F');
has_factor = isfield(model,'residual_factor') && ...
    isfield(model,'residual_scale') && isfield(model,'normV2');
if has_factor
    reduced_residual = model.B-(model.H-d*eye(size(model.H)))*Y;
    Z = [eye(size(model.B,2)); -Y];
    res = norm(model.residual_factor*Z,'fro') + ...
        model.normV2*norm(reduced_residual,'fro');
    scale = model.residual_scale(1) + ...
        model.residual_scale(2)*norm(Y,'fro') + ...
        model.normV2*norm(reduced_residual,'fro');
    allowance = 64*eps*scale;
    info.method = 'compressed';
    info.cancellation_suspected = ~isfinite(res) || res <= allowance;
else
    % Without a residual factor, use F directly or request an exact count.
    info.cancellation_suspected = true;
end
if ~has_factor || info.cancellation_suspected
    if ~has_source
        info.method = 'unavailable';
        info.residual_seconds = toc(t0);
        return
    end
    product = (lambda-d).*(model.V*Y);
    res = norm(model.F-product,'fro');
    allowance = 64*eps*(norm(model.F,'fro')+norm(product,'fro'));
    info.method = 'explicit';
    info.explicit_recomputed = true;
    info.used_explicit = true;
end
if ~isfinite(res) || ~isfinite(allowance)
    info.method = 'unavailable';
    info.residual_seconds = toc(t0);
    return
end
info.residual_norm = res;
info.roundoff_allowance = allowance;
eta = model.normF2*(res+allowance)/delta;
if nargout > 1 && compute_legacy
    % Squared-norm identity for diagnostics only.
    if isfield(model,'Gs') && isfield(model,'K2s')
        Ys = model.C./(model.theta-d);
        S = model.K2s+diag(d^2-2*d*model.theta);
        info.raw_residual_squared = model.normFro2 - ...
            2*real(trace(Ys'*(model.Gs-d*model.C))) + real(trace(Ys'*S*Ys));
    elseif isfield(model,'G') && isfield(model,'K2')
        S = model.K2-2*d*model.H+d^2*eye(size(model.H));
        info.raw_residual_squared = model.normFro2 - ...
            2*real(trace(Y'*(model.G-d*model.B))) + real(trace(Y'*S*Y));
    end
end
info.residual_seconds = toc(t0);
end
