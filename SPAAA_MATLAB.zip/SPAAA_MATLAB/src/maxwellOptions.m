function cfg = maxwellOptions(mode)
%MAXWELLOPTIONS Discretization and algorithm settings for Examples 5--6.
switch lower(mode)
    case 'smoke'
        cfg.validation_N = [10 14];
        cfg.validation_main_N = 14;
        cfg.defect_N = 16;
        cfg.scaling_N = [12 16];
        cfg.path_per_segment = 2;
        cfg.nev = 4;
    case 'quick'
        cfg.validation_N = [16 24 32];
        cfg.validation_main_N = 32;
        cfg.defect_N = 36;
        cfg.scaling_N = [16 24 32];
        cfg.path_per_segment = 4;
        cfg.nev = 8;
    case 'full'
        cfg.validation_N = [16 24 32 40 48];
        cfg.validation_main_N = 32;
        cfg.defect_N = 48;
        cfg.scaling_N = [20 28 36 44 52];
        cfg.path_per_segment = 7;
        cfg.nev = 8;
    otherwise
        error('Unknown mode "%s".', mode);
end
cfg.aaa_tol = 1e-9;
cfg.max_support = 10;
cfg.bisect_tol = 2e-8;
cfg.query_repeats = 20;
end

