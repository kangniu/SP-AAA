function T = boundary_T(prob,k)
zx = exp(1i*k(1)); zy = exp(1i*k(2));
r = size(prob.U,2);
il = prob.boundary_map(prob.left);
ir = prob.boundary_map(prob.right);
ib = prob.boundary_map(prob.bottom);
it = prob.boundary_map(prob.top);
rows = [il;ir;ib;it];
cols = [ir;il;it;ib];
vals = [conj(zx)*prob.wx;zx*prob.wx; ...
        conj(zy)*prob.wy;zy*prob.wy];
T = sparse(rows,cols,vals,r,r);
end


