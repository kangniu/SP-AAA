function fraction = disk_volume_fraction(X,Y,cx,cy,radius,h,ns)
fraction = zeros(size(X));
offset = ((1:ns)-0.5)/ns-0.5;
for ix = 1:ns
    for iy = 1:ns
        Xs = mod(X+h*offset(ix),1);
        Ys = mod(Y+h*offset(iy),1);
        inside = periodic_distance(Xs,cx).^2+ ...
            periodic_distance(Ys,cy).^2 <= radius^2;
        fraction = fraction+inside;
    end
end
fraction = fraction/ns^2;
end


