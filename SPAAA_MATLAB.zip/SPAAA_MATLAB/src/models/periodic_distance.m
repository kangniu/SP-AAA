function z = periodic_distance(x,c)
z = min(abs(x-c),1-abs(x-c));
end


