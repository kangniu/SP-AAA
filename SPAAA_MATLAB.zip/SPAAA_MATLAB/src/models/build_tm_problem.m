function prob = build_tm_problem(N,kind)
h = 1/N;
[X,Y] = ndgrid((0:N-1)/N,(0:N-1)/N);
epsr = ones(N,N);
switch kind
    case 'rod'
        fraction = disk_volume_fraction(X,Y,0.5,0.5,0.2,h,5);
        epsr = 1+(11.56-1)*fraction;
    case 'defect'
        centers = (0:2)/3 + 1/6;
        for ix = 1:3
            for iy = 1:3
                if ix == 2 && iy == 2, continue; end
                mask = periodic_distance(X,centers(ix)).^2+ ...
                    periodic_distance(Y,centers(iy)).^2 <= (0.19/3)^2;
                epsr(mask) = 11.56;
            end
        end
    otherwise
        error('Unknown geometry %s',kind);
end
e = epsr(:);
s = 1./sqrt(e);
e1 = ones(N,1);
L1 = spdiags([-e1 2*e1 -e1],-1:1,N,N)/h^2;
Lopen = kron(speye(N),L1)+kron(L1,speye(N));
A0 = spdiags(s,0,N^2,N^2)*Lopen*spdiags(s,0,N^2,N^2);
% Enforce exact Hermitian storage: roundoff asymmetry can make eig choose
% its general-matrix path and return a nonorthogonal basis in repeated modes.
A0 = (A0+A0')/2;

left = (1:N)';
right = (N-1)*N+(1:N)';
bottom = (0:N-1)'*N+1;
top = (0:N-1)'*N+N;
indices = unique([left;right;bottom;top],'stable');
U = sparse(indices,1:numel(indices),1,N^2,numel(indices));
boundary_map = zeros(N^2,1);
boundary_map(indices) = 1:numel(indices);
wx = -(s(left).*s(right))/h^2;
wy = -(s(bottom).*s(top))/h^2;
prob = struct('N',N,'n',N^2,'h',h,'A0',A0,'U',U, ...
    'wx',wx,'wy',wy,'left',left,'right',right,'bottom',bottom,'top',top, ...
    'boundary_map',boundary_map,'eps',e,'mass_inv_sqrt',s,'x',X(:),'y',Y(:));
end



