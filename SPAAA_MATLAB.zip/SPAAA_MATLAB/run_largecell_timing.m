function result=run_largecell_timing(mode,outdir)
% Repeated complete count maps, with all setup included at every prefix.
% Use a fixed interval and query thresholds.
if nargin<1,mode='full';end
root=fileparts(mfilename('fullpath'));addpath(genpath(fullfile(root,'src')));
if nargin<2,outdir=fullfile(root,'runs','largecell_timing');end
assert(~exist(fullfile(outdir,'runs.csv'),'file'),'Use a fresh output directory.');
if ~exist(outdir,'dir'),mkdir(outdir);end
cfg=struct('N',64,'nk',48,'nd',21,'repeats',5,'ns',301,'sketch',8,'m',5, ...
 'svd_tol',1e-9,'aaa_tol',1e-9,'interval',[-10,110], ...
 'threshold_interval',[-7,103],'guard',12,'initial_nev',24,'seed',20260927);
[ix,iy]=ndgrid(0:7,0:5);kpoints=pi*[(ix(:)+.314159)/8,(iy(:)+.271828)/6];
checkpoints=[6 12 24 48];
if strcmp(mode,'smoke')
 cfg.N=12;cfg.nk=6;cfg.nd=5;cfg.repeats=2;cfg.ns=61;cfg.sketch=4;cfg.m=4;
 kpoints=kpoints(1:6,:);checkpoints=[2 4 6];
else,assert(strcmp(mode,'full'));end
shifts=linspace(cfg.threshold_interval(1),cfg.threshold_interval(2),cfg.nd);
methods=["direct_sparse","exact_lowrank","spaaa"];
warm=cfg;warm.N=12;warm.ns=31;warm.sketch=3;warm.m=3;
for method=methods,run_method(warm,method,kpoints(1:2,:),shifts([1 ceil(end/2) end]));end
orders=[1 2 3;2 3 1;3 1 2;3 2 1;2 1 3];
rows=struct([]);prefixrows=struct([]);maps=cell(cfg.repeats,3);curves=cell(cfg.repeats,3);
fprintf('Large-cell full task N=%d, %d Bloch points, %d shifts, %d repeats\n',cfg.N,cfg.nk,cfg.nd,cfg.repeats);
for rep=1:cfg.repeats
 for pos=1:3
  im=orders(rep,pos);[row,map,curve]=run_method(cfg,methods(im),kpoints,shifts);
  row.repeat=rep;row.execution_position=pos;rows=[rows;row]; %#ok<AGROW>
  maps{rep,im}=map;curves{rep,im}=curve;
  for nk=checkpoints
   rr=struct('method',methods(im),'repeat',rep,'bloch_points',nk,'queries',nk*cfg.nd, ...
    'total_seconds',curve(nk),'setup_seconds',row.assembly_seconds+row.spectral_seconds+row.model_seconds);
   prefixrows=[prefixrows;rr]; %#ok<AGROW>
  end
  fprintf('largecell round %d %s: %.3fs q=%d fallback=%d\n',rep,methods(im),row.total_seconds,row.q,row.fallbacks);
  writetable(struct2table(rows),fullfile(outdir,'runs.csv'));
  writetable(struct2table(prefixrows),fullfile(outdir,'prefix_runs.csv'));
  save(fullfile(outdir,'checkpoint.mat'),'rows','prefixrows','maps','curves','cfg','kpoints','shifts','-v7.3');
 end
end
fprintf('Independent original-matrix LDL validation...\n');
api=scalar_api;spec=struct('kind','largecell','N',cfg.N,'cells',4,'contrast',55,'radius',.14);
[A0,U,bd]=api.build_problem(spec);reference=zeros(cfg.nd,cfg.nk);t=tic;
for ik=1:cfg.nk
 A=A0+U*api.boundary_T(bd,kpoints(ik,:))*U';A=(A+A')/2;
 for jd=1:cfg.nd,reference(jd,ik)=original_inertia(A,shifts(jd));end
end
validation_seconds=toc(t);
for rep=1:cfg.repeats
 for im=1:3
  assert(isequal(maps{rep,im},reference),'Original-matrix count mismatch: %s round %d.',methods(im),rep);
 end
end
prefix=struct2table(prefixrows);summary=struct([]);ratios=struct([]);
for nk=checkpoints
 sp=prefix.total_seconds(prefix.method=="spaaa" & prefix.bloch_points==nk);
 for im=1:3
  times=prefix.total_seconds(prefix.method==methods(im) & prefix.bloch_points==nk);
  row=struct('method',methods(im),'bloch_points',nk,'queries',nk*cfg.nd, ...
   'median_seconds',median(times),'min_seconds',min(times),'max_seconds',max(times),'all_counts_match',true);
  summary=[summary;row]; %#ok<AGROW>
  if im<3
   ratio=times./sp;row=struct('baseline',methods(im),'bloch_points',nk, ...
    'median_ratio',median(ratio),'min_ratio',min(ratio),'max_ratio',max(ratio));
   ratios=[ratios;row]; %#ok<AGROW>
  end
 end
end
environment=struct('matlab',version,'computer',computer,'threads',maxNumCompThreads,'date',char(datetime('now')), ...
 'timing_scope','Fresh assembly and full method setup through each completed count-map prefix; excludes disk I/O and common independent checks', ...
 'prefix_interpretation','Measured prefixes of the same ordered 48-point task, each including all setup; not separate restarts', ...
 'query_grid','Offset 8-by-6 first-quadrant Bloch grid, x varying fastest; 21 fixed thresholds', ...
 'sketch','Two-sided orthonormal Gaussian sketch with one global normalization');
result=struct('cfg',cfg,'runs',struct2table(rows),'prefix_runs',prefix,'summary',struct2table(summary), ...
 'speedups',struct2table(ratios),'environment',environment,'validation_seconds',validation_seconds);
writetable(result.summary,fullfile(outdir,'summary.csv'));writetable(result.speedups,fullfile(outdir,'speedups.csv'));
save(fullfile(outdir,'benchmark.mat'),'result','maps','reference','curves','kpoints','shifts','checkpoints','-v7.3');
fid=fopen(fullfile(outdir,'environment.json'),'w');fprintf(fid,'%s',jsonencode(environment,PrettyPrint=true));fclose(fid);
disp(result.summary);
end

function [row,counts,cumulative]=run_method(cfg,method,kpoints,shifts)
rng(cfg.seed,'twister');
row=struct('method',method,'total_seconds',0,'assembly_seconds',0, ...
    'spectral_seconds',0,'model_seconds',0,'update_seconds',0, ...
    'query_seconds',0,'residual_seconds',0,'far_seconds',0, ...
    'count_seconds',0,'other_seconds',0,'fallbacks',0, ...
    'explicit_residuals',0,'q',0,'direct_max_nev',0, ...
    'direct_dense_fallbacks',0,'max_eigen_residual',0, ...
    'max_orthogonality_error',0,'repeat',0,'execution_position',0);
total=tic;
api=scalar_api;
spec=struct('kind','largecell','N',cfg.N,'cells',4,'contrast',55,'radius',.14);
tt=tic; [A0,U,boundary]=api.build_problem(spec);
row.assembly_seconds=toc(tt);
n=size(A0,1); counts=zeros(numel(shifts),size(kpoints,1));
cumulative=zeros(size(kpoints,1),1);
if method~="direct_sparse"
    tt=tic;
    [Q,lambda]=eig(full(A0),'vector');
    [lambda,ix]=sort(real(lambda)); Q=Q(:,ix); F=Q'*U;
    row.spectral_seconds=toc(tt);
    tt=tic;
    near=lambda>=cfg.interval(1)-cfg.guard & lambda<=cfg.interval(2)+cfg.guard;
    s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near), ...
        'F_near',F(near,:),'lambda_far',lambda(~near),'F_far',F(~near,:));
    if method=="spaaa"
        sample=sort(mean(cfg.interval)+diff(cfg.interval)/2*cos(linspace(0,pi,cfg.ns)));
        sketch=sketch_samples(s.lambda_far,s.F_far,sample,cfg.sketch);
        sketch=sketch/max(max(vecnorm(sketch,2,1)),realmin);
        support=setvalued_aaa_support(sample,sketch,cfg.aaa_tol,cfg.m);
        model=build_projection_model(s.lambda_far,s.F_far,support,cfg.svd_tol);
        row.q=size(model.V,2);
    end
    row.model_seconds=toc(tt);
end
for ik=1:size(kpoints,1)
    tt=tic; T=api.boundary_T(boundary,kpoints(ik,:));
    if method=="direct_sparse"
        A=A0+U*T*U'; A=(A+A')/2;
    else
        cache=prepare_inertia_update(s,T);
    end
    row.update_seconds=row.update_seconds+toc(tt);
    tq=tic;
    if method=="direct_sparse"
        requested=min(cfg.initial_nev,n-2);
        opts=struct('isreal',false,'tol',1e-10,'maxit',3000);
        normA=norm(A,1);
        while true
            opts.p=min(n,max(48,3*requested));
            [Ve,D,flag]=eigs(A,requested,'smallestreal',opts);
            assert(flag==0,'Sparse reference eigensolver failed to converge.');
            [ev,residual,orthogonality]=check_eigenpairs(A,Ve,diag(D),normA);
            row.max_eigen_residual=max(row.max_eigen_residual,residual/max(1,normA));
            row.max_orthogonality_error=max(row.max_orthogonality_error,orthogonality);
            row.direct_max_nev=max(row.direct_max_nev,requested);
            if ev(end)>max(shifts)+10*residual, break; end
            if requested==n-2
                [Ve,D]=eig(full(A));
                [ev,residual,orthogonality]=check_eigenpairs(A,Ve,diag(D),normA);
                row.max_eigen_residual=max(row.max_eigen_residual,residual/max(1,normA));
                row.max_orthogonality_error=max(row.max_orthogonality_error,orthogonality);
                row.direct_dense_fallbacks=row.direct_dense_fallbacks+1;
                row.direct_max_nev=n;
                break
            end
            requested=min(n-2,max(requested+8,ceil(1.5*requested)));
        end
        assert(min(abs(ev-shifts),[],'all')>10*residual, ...
            'A requested threshold is unresolved at the computed Ritz residual scale.');
        for jd=1:numel(shifts), counts(jd,ik)=sum(ev<shifts(jd)); end
    else
        for jd=1:numel(shifts)
            d=shifts(jd); err=0;
            if method=="spaaa"
                pole_tol=100*eps(max([1;abs(d);abs(model.theta)]));
                if min(abs(model.theta-d))>pole_tol && min(abs(s.lambda-d))>100*eps(max([1;abs(d);abs(s.lambda)]))
                    tt=tic; R=eval_projection(model,d); row.far_seconds=row.far_seconds+toc(tt);
                    tt=tic; [err,diagnostic]=projection_error_bound(model,s.lambda_far,d);
                    row.residual_seconds=row.residual_seconds+toc(tt);
                    row.explicit_residuals=row.explicit_residuals+diagnostic.used_explicit;
                else
                    err=Inf; R=[];
                end
            else
                tt=tic; R=eval_exact(s.lambda_far,s.F_far,d); row.far_seconds=row.far_seconds+toc(tt);
            end
            tt=tic;
            [counts(jd,ik),~,info]=inertia_count(s,cache,d,R,err);
            assert(info.reliable,'A fixed task threshold is unresolved; no count map is reported.');
            row.count_seconds=row.count_seconds+toc(tt);
            row.fallbacks=row.fallbacks+info.used_fallback;
        end
    end
    row.query_seconds=row.query_seconds+toc(tq);
    cumulative(ik)=toc(total);
end
row.total_seconds=toc(total);
row.other_seconds=row.total_seconds-row.assembly_seconds-row.spectral_seconds ...
    -row.model_seconds-row.update_seconds-row.query_seconds;
end

function [ev,residual,orthogonality]=check_eigenpairs(A,V,values,normA)
% Include these checks in direct-method timings. Independent LDL counts
% also check for missing eigenvalues and incorrect multiplicities.
residual=max(vecnorm(A*V-V.*values.',2,1)./vecnorm(V,2,1));
orthogonality=norm(V'*V-eye(size(V,2)),'fro');
assert(isfinite(residual) && residual<=1e-8*max(1,normA), ...
    'Direct eigensolver returned eigenpairs with excessive residuals.');
assert(isfinite(orthogonality) && orthogonality<=1e-8*max(1,sqrt(size(V,2))), ...
    'Direct eigensolver returned nonorthogonal eigenvectors.');
assert(all(abs(imag(values))<=1e-10*max(1,normA)), ...
    'Hermitian direct eigensolver returned nonreal eigenvalues.');
ev=sort(real(values(:)));
end
