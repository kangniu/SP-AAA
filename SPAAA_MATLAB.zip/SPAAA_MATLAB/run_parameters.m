function output = run_parameters(mode,outdir)
% Guard-width and SVD-tolerance study on a fixed interval.
if nargin<1, mode='full'; end
root=fileparts(mfilename('fullpath')); addpath(genpath(fullfile(root,'src')));
if nargin<2, outdir=fullfile(root,'runs','parameters'); end
if ~exist(outdir,'dir'), mkdir(outdir); end
rng(7,'twister');
if strcmp(mode,'full'), N=32; else, N=16; end
t=tic; prob=build_tm_problem(N,'rod'); assembly_seconds=toc(t);
if strcmp(mode,'full')
    interval=[-3.70665009168776, 50.0397762377947];
else
    refs=direct_bands(prob,[0 0;pi 0;pi pi],8);
    interval=[min(refs(:)),max(refs(:))];
    interval=interval+[-1 1]*.08*diff(interval);
end
t=tic; [Q,lambda]=eig(full(prob.A0),'vector');
[lambda,order]=sort(real(lambda)); Q=Q(:,order); F=Q'*prob.U;
spectral_seconds=toc(t);
kpoints=[.31*pi .17*pi;.58*pi .29*pi;.83*pi .46*pi];
shifts=linspace(interval(1),interval(2),31);
references=zeros(31,3); reference_gap=Inf;
for ik=1:3
    A=prob.A0+prob.U*boundary_T(prob,kpoints(ik,:))*prob.U';
    ev=sort(real(eig(full((A+A')/2),'vector')));
    for jd=1:31
        references(jd,ik)=sum(ev<shifts(jd));
        reference_gap=min(reference_gap,min(abs(ev-shifts(jd))));
    end
end
settings=[.05 1e-10;.10 1e-10;.50 1e-10;.10 1e-8;.10 1e-12];
rows=struct([]); diagnostics=table; supports=struct([]);
for variant="current_two_sided"
    for ic=1:size(settings,1)
        guard_fraction=settings(ic,1); svd_cutoff=settings(ic,2);
        near=lambda>=interval(1)-guard_fraction*diff(interval) & ...
            lambda<=interval(2)+guard_fraction*diff(interval);
        s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near), ...
            'F_near',F(near,:),'lambda_far',lambda(~near),'F_far',F(~near,:));
        sample=linspace(interval(1),interval(2),401);
        rng(7,'twister'); tt=tic;
        if variant=="current_two_sided"
            Y=sketch_samples(s.lambda_far,s.F_far,sample,4);
            Y=Y/max(max(vecnorm(Y,2,1)),realmin);
        else
            Omega=randn(size(F,2),4)+1i*randn(size(F,2),4);
            Y=zeros(size(F,2)*4,numel(sample));
            for j=1:numel(sample)
                Y(:,j)=reshape(eval_exact(s.lambda_far,s.F_far,sample(j))*Omega,[],1);
            end
            Y=Y./max(vecnorm(Y,2,2),eps);
        end
        support=setvalued_aaa_support(sample,Y,1e-9,10);
        selection_seconds=toc(tt); tt=tic;
        model=build_projection_model(s.lambda_far,s.F_far,support,svd_cutoff);
        model_seconds=toc(tt);
        min_ritz_distance=min(abs(model.theta-shifts),[],'all');
        assert(min_ritz_distance>100*eps(max([1;abs(model.theta);abs(shifts(:))])), ...
            'This fixed-grid replay reached a reduced pole; use the explicit pole fallback.');
        fprintf('%s, guard %.2g, cutoff %.1e, m=%d q=%d\n', ...
            variant,guard_fraction,svd_cutoff,numel(support),size(model.V,2));
        actual=zeros(31,1); eta=zeros(31,1); oldsq=zeros(31,1);
        explicit=false(31,1); residual=zeros(31,1); allowance=zeros(31,1);
        for jd=1:31
            d=shifts(jd); R=eval_projection(model,d);
            actual(jd)=norm(eval_exact(s.lambda_far,s.F_far,d)-R,2);
            [eta(jd),ri]=projection_error_bound(model,s.lambda_far,d,true);
            oldsq(jd)=ri.raw_residual_squared; explicit(jd)=ri.used_explicit;
            residual(jd)=ri.residual_norm; allowance(jd)=ri.roundoff_allowance;
        end
        accepted=0; fallbacks=0; dense=0; unreliable=0; mismatches=0;
        update_seconds=0; query_seconds=0; residual_seconds=0;
        for ik=1:3
            tt=tic; update=prepare_inertia_update(s,boundary_T(prob,kpoints(ik,:)));
            update_seconds=update_seconds+toc(tt);
            for jd=1:31
                tt=tic; R=eval_projection(model,shifts(jd)); tr=tic;
                e=projection_error_bound(model,s.lambda_far,shifts(jd));
                residual_seconds=residual_seconds+toc(tr);
                [cnt,~,ci]=inertia_count(s,update,shifts(jd),R,e);
                query_seconds=query_seconds+toc(tt);
                accepted=accepted+ci.accepted_approximation;
                fallbacks=fallbacks+ci.used_fallback; dense=dense+ci.used_dense;
                unreliable=unreliable+~ci.reliable;
                mismatches=mismatches+(cnt~=references(jd,ik));
            end
        end
        row=struct('variant',variant,'guard_fraction',guard_fraction,'svd_cutoff',svd_cutoff, ...
            'N',N,'near_count',sum(near),'support_count',numel(support), ...
            'projection_rank',size(model.V,2),'max_resolvent_error',max(actual), ...
            'accepted',accepted,'queries',93,'accepted_fraction',accepted/93, ...
            'fallbacks',fallbacks,'dense_fallbacks',dense,'unreliable_counts',unreliable, ...
            'count_mismatches',mismatches,'explicit_residual_shifts',sum(explicit), ...
            'negative_legacy_squares',sum(oldsq<0),'nonpositive_legacy_squares',sum(oldsq<=0), ...
            'min_indicator',min(eta),'max_indicator',max(eta), ...
            'min_ritz_distance',min_ritz_distance, ...
            'indicator_below_measured_error',sum(eta<actual), ...
            'selection_seconds',selection_seconds,'model_seconds',model_seconds, ...
            'residual_setup_seconds',model.residual_setup_seconds, ...
            'update_seconds',update_seconds,'query_seconds',query_seconds, ...
            'residual_seconds',residual_seconds);
        rows=[rows;row]; %#ok<AGROW>
        dt=table(repmat(variant,31,1),repmat(guard_fraction,31,1), ...
            repmat(svd_cutoff,31,1),shifts',actual,eta,oldsq,explicit,residual,allowance, ...
            'VariableNames',{'variant','guard_fraction','svd_cutoff','shift', ...
            'absolute_error','new_indicator','legacy_residual_square','explicit_recomputed', ...
            'residual_norm','roundoff_allowance'});
        diagnostics=[diagnostics;dt]; %#ok<AGROW>
        support_row=struct('variant',variant,'guard_fraction',guard_fraction, ...
            'svd_cutoff',svd_cutoff,'support',support);
        if isempty(supports), supports=support_row;
        else, supports(end+1)=support_row; end %#ok<AGROW>
        writetable(struct2table(rows),fullfile(outdir,'sensitivity.csv'));
        writetable(diagnostics,fullfile(outdir,'residual_diagnostics.csv'));
        assert(mismatches==0,'A safeguarded count disagrees with the original matrix.');
        assert(unreliable==0,'An unresolved count requires investigation.');
    end
end
output=struct('rows',struct2table(rows),'diagnostics',diagnostics, ...
    'supports',supports,'interval',interval,'kpoints',kpoints,'shifts',shifts, ...
    'references',references,'reference_gap',reference_gap, ...
    'assembly_seconds',assembly_seconds,'spectral_seconds',spectral_seconds, ...
    'matlab_version',version,'threads',maxNumCompThreads);
save(fullfile(outdir,'sensitivity.mat'),'output','-v7.3');
disp(output.rows);
end
