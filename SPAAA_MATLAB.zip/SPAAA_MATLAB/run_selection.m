function run_selection(mode,outdir)
if nargin<1,mode='full';end
root=fileparts(mfilename('fullpath'));addpath(genpath(fullfile(root,'src')));
if nargin<2,outdir=fullfile(root,'runs','selection');end
assert(~exist(fullfile(outdir,'synthetic.csv'),'file'),'Choose a fresh output directory.');
if ~exist(outdir,'dir'),mkdir(outdir);end
api=synthetic_api;cfg=struct('budgets',2:20,'thresholds',[1e-8 1e-10],'aaa_tol',1e-15,'interval',[0 1]);
seeds=[101 202 303];if strcmp(mode,'smoke'),cfg.budgets=[8 15];seeds=101;end
spec=struct('id','case_05','family',1,'n',256,'r',4,'g',.01,'L',1,'weight','endpoint_balanced','easy',false);
allrows=struct([]);
for seed=seeds
 [rows,details]=api.evaluate_case(spec,seed,1e-10,cfg,true);
 assert(all(cellfun(@isempty,{rows.failure})),'Synthetic model failure.');
 allrows=[allrows rows]; %#ok<AGROW>
 writetable(struct2table(allrows),fullfile(outdir,'synthetic.csv'));
 save(fullfile(outdir,sprintf('synthetic_seed%d.mat',seed)),'details','cfg','spec');
end
% Easy control uses the original full-matrix selection, same projection.
spec.id='easy';spec.g=2;spec.L=3;spec.weight='flat';spec.easy=true;cfg.budgets=2:2:12;
[rows,details]=api.evaluate_case(spec,17,1e-10,cfg,false);
writetable(struct2table(rows),fullfile(outdir,'easy.csv'));
if strcmp(mode,'smoke'),return;end
generate_strip('full',outdir);confirm_strip(outdir);generate_strip('holdout',outdir);
end
