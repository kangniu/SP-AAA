function test_maxwell_hermitian_assembly()
% Non-power-of-two mesh regression: tiny storage asymmetry must not send eig
% to a general-matrix path with nonorthogonal repeated-mode eigenvectors.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(genpath(root));
prob=build_tm_problem(14,'rod');
assert(ishermitian(prob.A0),'The assembled Maxwell A0 must be exactly Hermitian.');
[Q,lambda]=eig(full(prob.A0),'vector'); [lambda,ix]=sort(real(lambda)); Q=Q(:,ix);
assert(norm(Q'*Q-eye(prob.n),'fro')<1e-10,'Hermitian eig must produce a unitary basis.');
F=Q'*prob.U; near=false(prob.n,1); near(1:12)=true;
s=struct('lambda',lambda,'F',F,'lambda_near',lambda(near),'F_near',F(near,:), ...
    'lambda_far',lambda(~near),'F_far',F(~near,:));
ks=benchmark_kpoints();
for p=1:size(ks,1)
    T=boundary_T(prob,ks(p,:)); A=prob.A0+prob.U*T*prob.U'; A=(A+A')/2;
    ev=sort(real(eig(full(A),'vector')));
    transformed=diag(lambda)+F*T*F';
    et=sort(real(eig((transformed+transformed')/2,'vector')));
    assert(norm(ev-et,Inf)<1e-9,'Unitary transformation changed the original spectrum.');
    cache=prepare_inertia_update(s,T);
    for j=1:8
        d=(ev(j)+ev(j+1))/2;
        count=inertia_count(s,cache,d,[]);
        assert(count==sum(ev<d),'Original Maxwell inertia mismatch.');
    end
end
fprintf('test_maxwell_hermitian_assembly: exact Hermitian storage, unitary basis and original counts passed.\n');
end
