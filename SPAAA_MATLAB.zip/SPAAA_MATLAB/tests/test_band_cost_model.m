function report=test_band_cost_model
root=fileparts(fileparts(mfilename('fullpath')));addpath(genpath(fullfile(root,'src')));
rng(20260927);checks=0;
for indefinite=[false true]
for complex_data=[false true]
 lambda=linspace(3,100,80)';
 if indefinite,lambda=[-flipud(lambda(1:40));lambda(41:80)];end
 F=randn(80,4);
 if complex_data,F=F+1i*randn(size(F));end
 model=build_band_model(lambda,F,[-1 0 1],1e-9);
 for d=linspace(-1.2,1.4,17)
  [R,eta]=eval_band_model(model,lambda,d);exact=F'*(F./(lambda-d));
  Z=model.C./(model.theta-d);actual=norm(F-(lambda-d).*(model.V*Z),'fro');
  compressed=norm(model.R0-model.R1*Z,'fro');
  assert(abs(actual-compressed)<1e-10*norm(F,'fro'));
  assert(norm(exact-R,2)<=eta && isfinite(eta));checks=checks+1;
 end
end
end
lambda=[2;3];F=[1;2];model=build_band_model(lambda,F,[0 1],1e-12);
[~,eta,explicit]=eval_band_model(model,lambda,.5);assert(explicit&&eta>0);
[~,eta]=eval_band_model(model,lambda,model.theta(1));assert(isinf(eta));
checks=checks+2;
% The defect-corrected identity also holds for a deliberately nonorthogonal
% basis and a diagonal operator not obtained by projecting D.
D=linspace(5,25,30)';F=randn(30,3)+1i*randn(30,3);W=randn(30,4)/8;
theta=[6;10;15;20];C=W'*F+1e-3*randn(4,3);d=1.2;Z=C./(theta-d);
E=F-(D-d).*(W*Z);dc=W'*F-C;dh=W'*(D.*W)-diag(theta);dg=W'*W-eye(4);
R=F'*(F./(D-d));P=C'*Z;
identity=E'*(E./(D-d))+dc'*Z+Z'*dc-Z'*(dh-d*dg)*Z;
assert(norm(R-P-identity,'fro')<1e-11*norm(R,'fro'));
bound=norm(E,'fro')^2/min(abs(D-d))+2*norm(dc,2)*norm(Z,'fro') ...
 +(norm(dh,2)+abs(d)*norm(dg,2))*norm(Z,'fro')^2;
assert(norm(R-P,2)<=bound);checks=checks+2;
for complex_data=[false true]
 H=randn(35);if complex_data,H=H+1i*randn(size(H));end
 H=sparse((H+H')/2);ev=eig(full(H));
 for d=[-12 -3 .13 4 12]
  assert(band_original_inertia(H,d)==sum(ev<d));
  assert(band_original_inertia(H,d)==original_inertia(H,d));checks=checks+1;
 end
end
report=struct('checks',checks,'status','passed');disp(report);
end
