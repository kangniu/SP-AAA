function report = test_residual_safeguards
%TEST_RESIDUAL_SAFEGUARDS Regression checks for cancellation-safe acceptance.
% Run with run_tests from the package directory.
rng(20260924);
lambda = linspace(2,20,35)';
F = randn(35,3)+1i*randn(35,3);
model = build_projection_model(lambda,F,[-1 0],1e-9);
d = 1.4;
[eta,info] = projection_error_bound(model,lambda,d);
Y = model.Uh*(model.C./(model.theta-d));
explicit = norm(F-(lambda-d).*(model.V*Y),'fro');
assert(strcmp(info.method,'compressed'),'A well-resolved residual should stay compressed.');
assert(explicit > 1e-5*norm(F,'fro'),'The high-residual fixture is ineffective.');
assert(abs(info.residual_norm-explicit) < 1e-10*norm(F,'fro'), ...
    'Compressed residual disagrees with its explicit counterpart.');
Rexact = F'*(F./(lambda-d));
Rapprox = model.C'*(model.C./(model.theta-d));
assert(eta >= norm(Rexact-Rapprox,2), ...
    'The high-residual test underestimates the directly measured matrix error.');
assert(eta == projection_error_bound(model,lambda,d), ...
    'Requesting diagnostics must not change acceptance.');
assert(info.residual_seconds >= 0 && model.residual_setup_seconds >= 0);

% A full span has roundoff-size residual and must explicitly recompute.
small_lambda = [2;3];
small_F = [1;2];
full_model = build_projection_model(small_lambda,small_F,[0 1]);
[eta_full,full_info] = projection_error_bound(full_model,small_lambda,0.5);
assert(full_info.explicit_recomputed,'Roundoff-scale residual did not recompute.');
assert(eta_full > 0 && isfinite(eta_full), ...
    'A rounding-scale residual must not yield a clipped-zero acceptance bound.');
Yfull = full_model.Uh*(full_model.C./(full_model.theta-0.5));
explicit_full = norm(small_F-(small_lambda-0.5).*(full_model.V*Yfull),'fro');
assert(full_info.residual_norm == explicit_full);

% Reproduce the downward perturbation of the squared-norm identity that
% occurs under cancellation, without altering any residual source data.
negative_model = full_model;
negative_model.normFro2 = full_model.normFro2*(1-128*eps);
[eta_negative,negative_info] = projection_error_bound(negative_model,small_lambda,0.5,true);
assert(negative_info.raw_residual_squared < 0, ...
    'The regression fixture must exercise a negative legacy residual square.');
assert(eta_negative == eta_full && negative_info.explicit_recomputed, ...
    'A negative legacy square changed the safe residual evaluation.');

% Without residual compression, use F directly or request an exact count.
legacy = rmfield(model,{'residual_factor','residual_scale','normV2'});
[eta_legacy,legacy_info] = projection_error_bound(legacy,lambda,d);
assert(legacy_info.explicit_recomputed && isfinite(eta_legacy));
assert(abs(legacy_info.residual_norm-explicit) < eps*max(1,explicit));
legacy_missing = rmfield(legacy,'F');
[eta_missing,missing_info] = projection_error_bound(legacy_missing,lambda,d);
assert(isinf(eta_missing) && strcmp(missing_info.method,'unavailable'));
assert(isinf(projection_error_bound(model,lambda,lambda(1))), ...
    'An original pole must force fallback.');
assert(isinf(projection_error_bound(model,lambda,model.theta(1))), ...
    'A projected pole must force fallback.');

report = struct('status','passed','high_residual',explicit, ...
    'high_residual_indicator',eta,'roundoff_residual',explicit_full, ...
    'negative_legacy_square',negative_info.raw_residual_squared, ...
    'roundoff_indicator',eta_full,'fallback_without_source',isinf(eta_missing));
disp(report);
end

