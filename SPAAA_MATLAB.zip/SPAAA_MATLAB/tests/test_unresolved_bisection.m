function test_unresolved_bisection
% A midpoint exactly at a repeated root must not determine a bracket side.
s=struct('lambda',[0;0;2],'F',eye(3),'lambda_near',zeros(0,1), ...
    'F_near',zeros(0,3),'lambda_far',[0;0;2],'F_far',eye(3));
[~,~,info]=inertia_count(s,eye(3),1,[]);
assert(~info.reliable,'Fixture must hit an unresolved original-matrix pole.');
[v,n]=bisect_spectrum(s,eye(3),repmat([-1 3],2,1),2,1e-10,3);
assert(max(abs(v-1))<1e-8 && n>2,'Repeated-root retry failed.');
% No safe interior shift exists at this scale: report failure, never an eigenvalue.
failed=false;
try
 bisect_spectrum(s,eye(3),[1-1e-14 1+1e-14],1,1e-18,3);
catch e
 failed=strcmp(e.identifier,'SPAAA:UnresolvedBracket');
end
assert(failed,'An unresolved bracket must terminate explicitly.');
fprintf('test_unresolved_bisection: repeated-root retry and explicit failure passed.\n');
end

