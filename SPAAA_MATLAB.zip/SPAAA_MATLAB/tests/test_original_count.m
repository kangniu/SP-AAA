function test_original_count()
% Regression checks for original-matrix counts, poles and truncation.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(root));

% Strict counting at exact repeated roots, including a zero-rank update.
s = fixture([-2;0;0;3],eye(4));
for d = [-3 -2 0 1 3 4]
    [c,~,info] = inertia_count(s,zeros(4),d,[]);
    assert(c == sum(s.lambda<d),'Zero-update strict count failed.');
    assert(info.reliable == ~any(s.lambda==d), ...
        'Zero-update reliability must reject unresolved diagonal poles.');
end
for d = [-2+eps(2),0+eps(3),3-eps(3)]
    [~,~,info] = inertia_count(s,zeros(4),d,[]);
    assert(~info.reliable,'A near-pole zero-update count must remain unresolved.');
end

% A tiny eigenvalue of T can produce a substantial update when F is large.
s = fixture([0;2],diag([1e8 1])); T = diag([1e-16 0]);
u = prepare_inertia_update(s,T);
assert(u.retained_rank == 1 && ~u.has_truncation);
[c,~,info] = inertia_count(s,u,0.5,[]);
assert(c == 0 && ~info.used_dense,'Nonzero direction was incorrectly discarded.');
ut = prepare_inertia_update(s,T,struct('rank_tol',1e-14));
[c,~,info] = inertia_count(s,ut,0.5,[]);
assert(c == 0 && info.used_dense && ~info.truncation_verified, ...
    'Inconclusive truncation must count the original matrix.');
assert(info.shifted_counts(1) ~= info.shifted_counts(2));

% Well-separated shifted counts certify the same integer in exact arithmetic.
s = fixture([0;2],eye(2)); T = diag([1e-12 1]);
ut = prepare_inertia_update(s,T,struct('rank_tol',1e-10));
[c,~,info] = inertia_count(s,ut,1,999*eye(2),0);
assert(c == 1 && info.truncation_verified && all(info.shifted_counts==1));
assert(info.used_exact_far,'Displaced queries must reevaluate their resolvents.');

% A displaced query can hit a diagonal pole; never perturb that pole.
T = diag([0.125 0.5]);
ut = prepare_inertia_update(s,T,struct('rank_tol',0.2));
d = 2+ut.eta_T;
[c,~,info] = inertia_count(s,ut,d,[]);
assert(c == 1 && info.truncation_verified && info.used_dense);
assert(abs(info.evaluated_shifts(1)-2)<4*eps(2));
% If the displaced effective matrix is singular, the enclosure is rejected.
d = -ut.eta_T;
[c,~,info] = inertia_count(s,ut,d,[]);
assert(c == 0 && info.used_dense && ~info.truncation_verified);

% Original diagonal poles use the original matrix, with no d perturbation.
T = diag([0.5 -0.5]); u = prepare_inertia_update(s,T);
for d = [0 2]
    [c,~,info] = inertia_count(s,u,d,[]);
    assert(c == sum([0.5;1.5]<d) && info.used_dense);
end

% An excessive/invalid approximate-resolvent error forces exact recomputation.
for eta = [100 Inf NaN]
    [c,~,info] = inertia_count(s,u,1,20*eye(2),eta);
    assert(c == 1 && info.used_fallback && info.used_exact_far);
end
[c,~,info] = inertia_count(s,u,1,diag([-1 1])+1e-6*eye(2),1e-6);
assert(c == 1 && info.accepted_approximation && ~info.used_fallback);
[c,~,info] = inertia_count(s,u,1,diag([-1 1]),0);
assert(c == 1 && info.accepted_approximation && ~info.used_fallback, ...
    'A supplied zero error must be recognized as an accepted approximation.');

% Repeated roots and bisection queries through original diagonal poles.
s = fixture([0;1;2],eye(3)); T = diag([1 0 1]);
for d = [0.5 1 1.5 3 3.5]
    c = inertia_count(s,T,d,[]);
    assert(c == sum([1;1;3]<d),'Repeated-root count failed.');
end
[v,~,~] = bisect_spectrum(s,T,repmat([-1 4],3,1),3,1e-10,3);
assert(max(abs(v-[1;1;3]))<1e-8,'Repeated-root bisection failed.');

% Deterministic complex Hermitian, indefinite, rank-deficient updates.
rng(9024,'twister'); n = 12; r = 5;
F = randn(n,r)+1i*randn(n,r); lambda = sort(randn(n,1));
s = fixture(lambda,F); X = randn(r)+1i*randn(r); [Z,~] = qr(X);
T = Z*diag([-1 -1e-15 0 0.3 2])*Z'; T = (T+T')/2;
A = diag(lambda)+F*T*F'; reference = sort(real(eig((A+A')/2)));
u = prepare_inertia_update(s,T);
for d = linspace(reference(1)-1,reference(end)+1,71)
    c = inertia_count(s,u,d,[]);
    assert(c == sum(reference<d),'Random original-matrix count disagrees with eig.');
end
fprintf('test_original_count: all original-count, truncation, pole and bisection checks passed.\n');
end

function s = fixture(lambda,F)
lambda = lambda(:); near = false(size(lambda));
if numel(lambda)>2, near(2:2:end) = true; end
s = struct('lambda',lambda,'F',F,'lambda_near',lambda(near), ...
    'F_near',F(near,:),'lambda_far',lambda(~near),'F_far',F(~near,:));
end
