function report=verify_saved_results(data)
% Check stored scalar, support and eigenvalue-count results.
root=fileparts(mfilename('fullpath'));
assert(nargin>=1 && ~isempty(data),'Provide the experiment output folder.');
names={'defect','electronic','largecell'};ns=[1296 1600 4096];qs=0;bands=0;
for i=1:3
 folder=fullfile(data,'scalar',names{i});r=readtable(fullfile(folder,'summary.csv'));
 assert(r.n==ns(i) && r.supports==5 && r.count_queries==75);
 d=readtable(fullfile(folder,[names{i} '_residual_diagnostics.csv']));
 assert(height(d)==61 && max(d.relative_matrix_error)<=1e-10 && max(d.cheb_matched_relative_error)<=1e-10);
 assert(abs(max(d.relative_matrix_error)-r.max_relative_error)<1e-22);
 c=readtable(fullfile(folder,[names{i} '_count_validation.csv']));
 assert(height(c)==75 && all(c.original_count_agreement) && all(c.exact_count_agreement));
 assert(all(c.reliable) && all(c.exact_reliable));qs=qs+height(c);
 v=readtable(fullfile(folder,[names{i} '_band_validation.csv']));
 assert(height(v)==49 && all(v.verified));bands=bands+12*height(v);
 t=readtable(fullfile(folder,[names{i} '_kernel_timings.csv']),'TextType','string');
 assert(height(t)==60 && all(t.queries==41));
 methods=["exact","sp_projection","cheb4","cheb_matched"];
 fields={'kernel_exact_seconds','kernel_sp_seconds','kernel_cheb4_seconds','kernel_matched_cheb_seconds'};
 for j=1:4
  assert(sum(t.method==methods(j))==15);
  assert(abs(mean(t.seconds_per_query(t.method==methods(j)))-r.(fields{j}))<1e-12);
 end
end
s=readtable(fullfile(data,'support','summary.csv'));q=readtable(fullfile(data,'support','queries.csv'));
assert(isequal(s.m,(2:10)') && all(s.queries==93));
assert(all(s.mismatches==0) && all(s.unreliable==0) && height(q)==837);
assert(all(q.count==q.reference) && all(q.reliable));
for i=1:height(s)
 rows=q.m==s.m(i);assert(sum(q.accepted(rows))==s.accepted(i));
 assert(sum(q.fallback(rows))==s.fallbacks(i));
end
x=load(fullfile(data,'largecell_timing','benchmark.mat'));
assert(x.result.cfg.N==64 && x.result.cfg.nk==48 && x.result.cfg.nd==21 && x.result.cfg.repeats==5);
methods=["direct_sparse","exact_lowrank","spaaa"];
assert(isequal(size(x.reference),[21 48]));
for rep=1:5
 for im=1:3
  assert(isequal(x.maps{rep,im},x.reference));curve=x.curves{rep,im};
  assert(numel(curve)==48 && all(diff(curve)>0));
  r=x.result.runs(x.result.runs.method==methods(im) & x.result.runs.repeat==rep,:);
  assert(height(r)==1 && abs(curve(end)-r.total_seconds)<.1);
  setup=r.assembly_seconds+r.spectral_seconds+r.model_seconds;
  assert(setup<curve(1) && r.other_seconds>=-1e-5);
  for nk=[6 12 24 48]
   p=x.result.prefix_runs(x.result.prefix_runs.method==methods(im) & ...
    x.result.prefix_runs.repeat==rep & x.result.prefix_runs.bloch_points==nk,:);
   assert(height(p)==1 && p.queries==21*nk && abs(p.total_seconds-curve(nk))<1e-10);
  end
 end
end
report=struct('scalar_original_matrix_queries',qs,'scalar_reference_band_values',bands, ...
 'support_queries',height(q),'largecell_distinct_thresholds',numel(x.reference), ...
 'largecell_validated_method_query_results',numel(x.reference)*numel(x.maps), ...
 'largecell_timed_runs',height(x.result.runs),'status','passed');
disp(report);
end
