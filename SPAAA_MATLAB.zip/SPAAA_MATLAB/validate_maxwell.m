function report=validate_maxwell(inputdir,outdir)
%VALIDATE_MAXWELL Check computed bands by original-matrix inertia.
% Test enclosures for all ordered eigenvalues, including multiplicities.
root=fileparts(mfilename('fullpath')); project=fileparts(root);
if nargin<1 || isempty(inputdir)
    inputdir=fullfile(root,'runs','maxwell');
end
if nargin<2 || isempty(outdir), outdir=fullfile(inputdir,'band_validation'); end
if exist(fullfile(outdir,'summary.csv'),'file')
    error('Band validation output already exists; choose a new directory.');
end
if ~exist(outdir,'dir'), mkdir(outdir); end
addpath(genpath(fullfile(root,'src')));
vertices=[0 0;pi 0;pi pi;0 0];
[kpath,ticks]=make_kpath(vertices,7);
assert(size(kpath,1)==22);
tol=2e-8; halfwidth_factor=1.1;
report=struct('input_directory',inputdir,'tolerance',tol, ...
    'halfwidth_factor',halfwidth_factor,'kpath',kpath,'ticks',ticks, ...
    'test','N_A(lambda_j-delta)<j<=N_A(lambda_j+delta)', ...
    'scope','Final SP-AAA band values only; no assertion about every intermediate bisection query', ...
    'arithmetic','Ordinary floating-point original-matrix sparse LDL with pivot guards; not rigorous interval certification', ...
    'results',struct());
kinds={'rod','defect'}; summaries=cell(2,1);
for c=1:2
    kind=kinds{c}; data=load(fullfile(inputdir,[kind '_results.mat']),'result');
    result=data.result;
    assert(strcmp(result.kind,kind));
    assert(isequal(size(result.band_values),[8,22]), ...
        'Input is not the formal eight-band, 22-point path; no reinterpretation is permitted.');
    assert(isequal(size(result.band_reference),size(result.band_values)));
    assert(all(isfinite(result.band_values),'all'),'SP-AAA values must be finite.');
    csv_path=fullfile(inputdir,[kind '_band_values.csv']);
    if exist(csv_path,'file')
        path_csv=readtable(csv_path);
        assert(height(path_csv)==22 && ...
            max(abs([path_csv.kx,path_csv.ky]-kpath),[],'all')<1e-13, ...
            'Saved band path differs from the prescribed full k path.');
    end
    prob=build_tm_problem(result.N,kind);
    rows=cell(numel(result.band_values),1); z=0; started=tic;
    for p=1:size(kpath,1)
        A=prob.A0+prob.U*boundary_T(prob,kpath(p,:))*prob.U'; A=(A+A')/2;
        for band=1:size(result.band_values,1)
            z=z+1;
            value=result.band_values(band,p); ref=result.band_reference(band,p);
            delta=halfwidth_factor*tol*max(1,2*abs(value));
            lower=value-delta; upper=value+delta;
            assert(lower<value && upper>value,'Endpoint displacement is not representable.');
            [nlow,lowinfo]=original_ldl(A,lower);
            [nhigh,highinfo]=original_ldl(A,upper);
            resolved=lowinfo.resolved && highinfo.resolved;
            enclosed=resolved && nlow<band && band<=nhigh;
            rows{z}=struct('kind',kind,'N',result.N,'path_index',p, ...
                'kx',kpath(p,1),'ky',kpath(p,2),'band',band,'spaaa_lambda',value, ...
                'halfwidth',delta,'lower_shift',lower,'upper_shift',upper, ...
                'lower_count',nlow,'upper_count',nhigh, ...
                'lower_pivots_resolved',lowinfo.resolved,'upper_pivots_resolved',highinfo.resolved, ...
                'lower_min_abs_pivot_eigenvalue',lowinfo.min_abs_pivot, ...
                'upper_min_abs_pivot_eigenvalue',highinfo.min_abs_pivot, ...
                'lower_pivot_guard',lowinfo.pivot_guard,'upper_pivot_guard',highinfo.pivot_guard, ...
                'lower_realification_even',lowinfo.even_inertia, ...
                'upper_realification_even',highinfo.even_inertia, ...
                'lower_ldl_failure',lowinfo.failure,'upper_ldl_failure',highinfo.failure, ...
                'band_index_enclosed',enclosed,'reference_lambda',ref, ...
                'absolute_reference_difference',abs(value-ref), ...
                'reference_difference_over_halfwidth',abs(value-ref)/delta, ...
                'reference_inside_interval',ref>=lower && ref<=upper);
            if ~enclosed
                partial=struct2table(vertcat(rows{1:z}));
                writetable(partial,fullfile(outdir,[kind '_final_band_enclosures.csv']));
                failure=rows{z}; save(fullfile(outdir,[kind '_failure.mat']),'failure','partial','report');
                error(['Final SP-AAA band enclosure failed at %s k-index %d band %d. ' ...
                    'Evidence saved; tolerance was NOT widened.'],kind,p,band);
            end
        end
        % Save results after each wavevector.
        partial=struct2table(vertcat(rows{1:z}));
        writetable(partial,fullfile(outdir,[kind '_final_band_enclosures.csv']));
        fprintf('[Maxwell final bands] %s path %d/22: eight band indices enclosed.\n',kind,p);
    end
    elapsed=toc(started);
    diagnostics=struct2table(vertcat(rows{:}));
    summary=struct('kind',kind,'N',result.N,'path_points',22,'bands',8, ...
        'band_values_checked',height(diagnostics), ...
        'endpoint_inertia_evaluations',2*height(diagnostics), ...
        'enclosed_values',sum(diagnostics.band_index_enclosed), ...
        'unresolved_endpoints',sum(~diagnostics.lower_pivots_resolved)+sum(~diagnostics.upper_pivots_resolved), ...
        'max_absolute_reference_difference',max(diagnostics.absolute_reference_difference), ...
        'max_reference_difference_over_halfwidth',max(diagnostics.reference_difference_over_halfwidth), ...
        'reference_values_outside_interval',sum(~diagnostics.reference_inside_interval), ...
        'minimum_lower_pivot_to_guard',min(diagnostics.lower_min_abs_pivot_eigenvalue./diagnostics.lower_pivot_guard), ...
        'minimum_upper_pivot_to_guard',min(diagnostics.upper_min_abs_pivot_eigenvalue./diagnostics.upper_pivot_guard), ...
        'validation_seconds',elapsed);
    report.results.(kind)=struct('summary',summary,'diagnostics',diagnostics);
    summaries{c}=summary;
    writetable(struct2table(vertcat(summaries{1:c})),fullfile(outdir,'summary.csv'));
    save(fullfile(outdir,'final_band_validation.mat'),'report');
end
fprintf('All 352 final SP-AAA band values passed original-matrix inertia enclosure.\n');
end

function [count,info]=original_ldl(A,shift)
% Realification duplicates each Hermitian eigenvalue; reject odd negative counts.
count=NaN;
info=struct('resolved',false,'min_abs_pivot',NaN,'pivot_guard',NaN, ...
    'even_inertia',false,'failure','');
try
    A=A-shift*speye(size(A,1));
    complex_case=~isreal(A);
    if complex_case, A=[real(A),-imag(A);imag(A),real(A)]; end
    [~,D,~]=ldl(A,'vector');
    pivot_guard=100*eps(max(1,norm(D,1)));
    minpivot=Inf; nneg=0; j=1;
    while j<=size(D,1)
        if j<size(D,1) && D(j+1,j)~=0
            ev=real(eig(full(D(j:j+1,j:j+1)))); j=j+2;
        else
            ev=real(D(j,j)); j=j+1;
        end
        if any(~isfinite(ev))
            info.failure='nonfinite pivot eigenvalue'; return
        end
        minpivot=min(minpivot,min(abs(ev)));
        nneg=nneg+sum(ev<0);
    end
    info.min_abs_pivot=minpivot; info.pivot_guard=pivot_guard;
    info.even_inertia=~complex_case || mod(nneg,2)==0;
    if ~info.even_inertia
        info.failure='odd realified negative inertia'; return
    end
    if minpivot<=pivot_guard
        info.failure='unresolved pivot magnitude'; return
    end
    if complex_case, count=nneg/2; else, count=nneg; end
    info.resolved=true;
catch exception
    info.failure=[exception.identifier ': ' exception.message];
end
end
