function report = check_dependencies
% Check that the examples use only this repository and base MATLAB.
root = fileparts(mfilename('fullpath'));
addpath(root, genpath(fullfile(root,'src')), fullfile(root,'tests'));
entries = dir(fullfile(root,'*.m'));
paths = arrayfun(@(x) fullfile(x.folder,x.name), entries, ...
    'UniformOutput',false);
[files,products] = matlab.codetools.requiredFilesAndProducts(paths);
relative = cell(size(files));
for j = 1:numel(files)
    if startsWith(lower(files{j}),lower([root filesep]))
        relative{j} = strrep(files{j}(numel(root)+2:end),filesep,'/');
    else
        assert(startsWith(lower(files{j}),lower([matlabroot filesep])), ...
            'Dependency outside this repository: %s',files{j});
        relative{j} = ['MATLAB/' strrep(files{j}(numel(matlabroot)+2:end),filesep,'/')];
    end
end
names = {products.Name};
assert(all(strcmp(names,'MATLAB')), ...
    'An additional MATLAB product is required: %s',strjoin(names,', '));
report = struct('files',{relative},'products',{names},'release',version('-release'));
fprintf('Dependency check passed: %d files; products: %s.\n', ...
    numel(files),strjoin(names,', '));
end
