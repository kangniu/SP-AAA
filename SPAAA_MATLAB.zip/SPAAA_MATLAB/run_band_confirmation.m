function run_band_confirmation(outdir)
% Five serial repetitions with independent checks of all computed bands.
root=fileparts(mfilename('fullpath'));addpath(root);maxNumCompThreads(4);
if nargin<1,outdir=fullfile(root,'runs',['band_confirmation_' datestr(now,'yyyymmdd_HHMMSS')]);end
run_band_cost(struct('Nx',32,'Ny',8,'Lx',1,'bands',8,'nk',2,'m',4),fullfile(outdir,'warmup'));
base=struct('Nx',256,'Ny',16,'Lx',8,'bands',256,'nk',33,'repeats',5, ...
 'm',8,'svd_tol',1e-12,'eigs_tol',1e-8,'guard_fraction',.1, ...
 'initialization','projected','validation_stride',1);
run_band_cost(base,fullfile(outdir,'primary'));
export_prefixes(fullfile(outdir,'primary'),[1 5 9 17 33]);
base.Nx=224;base.Lx=7;base.bands=192;base.nk=17;
run_band_cost(base,fullfile(outdir,'confirmation'));
export_prefixes(fullfile(outdir,'confirmation'),[1 5 9 17]);
end

function export_prefixes(folder,prefixes)
s=load(fullfile(folder,'benchmark.mat'),'result','outputs');rows=struct([]);
methods=["direct_shiftinvert","exact_lowrank","spaaa"];
for rep=1:s.result.cfg.repeats
 for im=1:3
  for k=prefixes
   rows=[rows;struct('repeat',rep,'method',methods(im),'points',k, ...
    'total_seconds',s.outputs{rep,im}.cumulative(k))]; %#ok<AGROW>
  end
 end
end
writetable(struct2table(rows),fullfile(folder,'prefix_runs.csv'));
end
